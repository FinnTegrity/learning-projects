# filename: dss_laptop_ahp.py
# tac gia:
    # Truong Dai Hoc Cong Nghe Thong Tin - Dai Hoc Quoc Gia TP.HCM
    # 23730116 - Le Hai Phuc
    # 23730115 - Nguyen Le Quy Phat
    # 23730064 - Nguyen Thien Tram Anh

import os
import sqlite3
import csv
from typing import Dict, List, Tuple
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import matplotlib
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

DB_PATH = "laptops.db"

# -------------------------------
# AHP WEIGHTS (mặc định từ báo cáo)
# -------------------------------
TOP_WEIGHTS_DEFAULT = {
    "perf": ("Hiệu suất", 0.4715),
    "screen": ("Màn hình", 0.2125),
    "gpu": ("Card đồ hoạ", 0.1357),
    "storage": ("Dung lượng", 0.0630),
    "brand": ("Thương hiệu", 0.0587),
    "price": ("Giá cả", 0.0587),
}

PERF_WEIGHTS_DEFAULT = {
    "cpu_mark": ("CPU", 0.565009),
    "ram_gb": ("RAM", 0.262201),
    "ssd_gb": ("SSD", 0.117504),
    "gpu_perf": ("GPU", 0.055285),
}

SCREEN_WEIGHTS_DEFAULT = {
    "screen_tech": ("Công nghệ màn hình", 0.636986),
    "screen_res": ("Độ phân giải", 0.258285),
    "screen_size": ("Kích thước", 0.104729),
}

GPU_WEIGHTS_DEFAULT = {
    "gpu_brand": ("Thương hiệu driver", 0.6716),
    "gpu_bw": ("Băng thông", 0.2654),
    "vram_gb": ("Bộ nhớ (VRAM)", 0.0629),
}

BRAND_PREF_WEIGHTS = {
    "Apple": 0.502173,
    "Lenovo": 0.265133,
    "Dell": 0.131443,
    "Asus": 0.064668,
    "MSI": 0.036584,
}

PRICE_BUCKET_WEIGHTS = [
    ("<15", 0.057243),
    ("15-20", 0.596932),
    (">20", 0.345825),
]

# -------------------------------
# DB LAYER
# -------------------------------
def get_conn():
    return sqlite3.connect(DB_PATH)

def init_db():
    with get_conn() as con:
        cur = con.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS laptops (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                brand TEXT NOT NULL,
                cpu_mark REAL,
                ram_gb INTEGER,
                ssd_gb INTEGER,
                gpu_brand TEXT,
                gpu_bw REAL,
                vram_gb REAL,
                screen_size REAL,
                screen_res TEXT,
                screen_tech TEXT,
                price_million REAL
            )
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS weights (
                key TEXT PRIMARY KEY,
                value REAL
            )
            """
        )
        # Seed weights if empty
        cur.execute("SELECT COUNT(*) FROM weights")
        if cur.fetchone()[0] == 0:
            for k, (_, w) in TOP_WEIGHTS_DEFAULT.items():
                cur.execute("INSERT INTO weights(key, value) VALUES(?,?)", (f"top:{k}", w))
            for k, (_, w) in PERF_WEIGHTS_DEFAULT.items():
                cur.execute("INSERT INTO weights(key, value) VALUES(?,?)", (f"perf:{k}", w))
            for k, (_, w) in SCREEN_WEIGHTS_DEFAULT.items():
                cur.execute("INSERT INTO weights(key, value) VALUES(?,?)", (f"screen:{k}", w))
            for k, (_, w) in GPU_WEIGHTS_DEFAULT.items():
                cur.execute("INSERT INTO weights(key, value) VALUES(?,?)", (f"gpu:{k}", w))
        con.commit()

# -------------------------------
# SCORING HELPERS
# -------------------------------
def _normalize_linear(items: List[Tuple[int, float]]) -> Dict[int, float]:
    vals = [v for _, v in items if v is not None]
    if not vals:
        return {i: 0.5 for i, _ in items}
    mn, mx = min(vals), max(vals)
    if mn == mx:
        return {i: 0.5 for i, _ in items}
    res = {}
    for i, v in items:
        if v is None:
            res[i] = 0.5
        else:
            res[i] = (v - mn) / (mx - mn)
    return res

def _score_screen_res(res_text: str) -> float:
    mapping = {
        "1366x768": 0.0,
        "1920x1080": 0.5,
        "2256x1504": 0.65,
        "2560x1440": 0.75,
        "2560x1600": 0.8,
        "2880x1800": 0.9,
        "3024x1964": 0.92,
        "3840x2160": 1.0,
    }
    return mapping.get(str(res_text).strip(), 0.6)

def _score_screen_tech(tech: str) -> float:
    t = (tech or "").strip().upper()
    if "OLED" in t: return 1.0
    if "IPS" in t or "PLS" in t or "VA" in t: return 0.8
    if "TN" in t: return 0.3
    return 0.6

def _score_screen_size(inch: float) -> float:
    if inch is None: return 0.5
    if 13.0 <= inch <= 16.0:
        peak = 14.5
        return max(0.0, 1.0 - ((inch - peak) ** 2) / (2.0 ** 2))
    return max(0.0, 0.6 - abs(inch - 14.5) * 0.05)

def _score_brand(brand: str) -> float:
    return BRAND_PREF_WEIGHTS.get((brand or "").strip(), 0.5)

def _score_price(million: float) -> float:
    if million is None: return 0.5
    if million < 15: return PRICE_BUCKET_WEIGHTS[0][1]
    if 15 <= million <= 20: return PRICE_BUCKET_WEIGHTS[1][1]
    return PRICE_BUCKET_WEIGHTS[2][1]

def _score_gpu_brand(gpu_brand: str) -> float:
    b = (gpu_brand or "").strip().upper()
    if "NVIDIA" in b: return 0.9
    if "AMD" in b: return 0.7
    if "APPLE" in b or "M" in b: return 0.8
    if "INTEL" in b: return 0.6
    return 0.6

def fetch_weights(con) -> Dict[str, float]:
    cur = con.cursor()
    cur.execute("SELECT key, value FROM weights")
    return {k: v for k, v in cur.fetchall()}

def update_weight(key: str, value: float):
    value = max(0.0, min(1.0, float(value)))
    with get_conn() as con:
        con.execute("INSERT INTO weights(key, value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))
        con.commit()

def fetch_laptops(con) -> List[dict]:
    cur = con.cursor()
    cur.execute("SELECT id, name, brand, cpu_mark, ram_gb, ssd_gb, gpu_brand, gpu_bw, vram_gb, screen_size, screen_res, screen_tech, price_million FROM laptops")
    cols = [d[0] for d in cur.description]
    return [dict(zip(cols, row)) for row in cur.fetchall()]

def ahp_rank() -> List[Tuple[dict, float, Dict[str, float]]]:
    with get_conn() as con:
        weights = fetch_weights(con)
        rows = fetch_laptops(con)

    if not rows:
        return []

    id_cpu = [(r["id"], r["cpu_mark"]) for r in rows]
    id_ram = [(r["id"], float(r["ram_gb"]) if r["ram_gb"] is not None else None) for r in rows]
    id_ssd = [(r["id"], float(r["ssd_gb"]) if r["ssd_gb"] is not None else None) for r in rows]
    id_gpu_bw = [(r["id"], r["gpu_bw"]) for r in rows]
    id_vram = [(r["id"], r["vram_gb"]) for r in rows]

    norm_cpu = _normalize_linear(id_cpu)
    norm_ram = _normalize_linear(id_ram)
    norm_ssd = _normalize_linear(id_ssd)
    norm_gpu_bw = _normalize_linear(id_gpu_bw)
    norm_vram = _normalize_linear(id_vram)

    result = []
    for r in rows:
        cpu_s = norm_cpu[r["id"]]
        ram_s = norm_ram[r["id"]]
        ssd_s = norm_ssd[r["id"]]
        gpu_s = 0.5

        perf = (
            cpu_s * weights.get("perf:cpu_mark", PERF_WEIGHTS_DEFAULT["cpu_mark"][1]) +
            ram_s * weights.get("perf:ram_gb", PERF_WEIGHTS_DEFAULT["ram_gb"][1]) +
            ssd_s * weights.get("perf:ssd_gb", PERF_WEIGHTS_DEFAULT["ssd_gb"][1]) +
            gpu_s * weights.get("perf:gpu_perf", PERF_WEIGHTS_DEFAULT["gpu_perf"][1])
        )

        gpu_brand_s = _score_gpu_brand(r.get("gpu_brand"))
        gpu_group = (
            gpu_brand_s * weights.get("gpu:gpu_brand", GPU_WEIGHTS_DEFAULT["gpu_brand"][1]) +
            norm_gpu_bw[r["id"]] * weights.get("gpu:gpu_bw", GPU_WEIGHTS_DEFAULT["gpu_bw"][1]) +
            norm_vram[r["id"]] * weights.get("gpu:vram_gb", GPU_WEIGHTS_DEFAULT["vram_gb"][1])
        )

        screen_tech_s = _score_screen_tech(r.get("screen_tech"))
        screen_res_s = _score_screen_res(r.get("screen_res"))
        screen_size_s = _score_screen_size(r.get("screen_size"))
        screen_group = (
            screen_tech_s * weights.get("screen:screen_tech", SCREEN_WEIGHTS_DEFAULT["screen_tech"][1]) +
            screen_res_s * weights.get("screen:screen_res", SCREEN_WEIGHTS_DEFAULT["screen_res"][1]) +
            screen_size_s * weights.get("screen:screen_size", SCREEN_WEIGHTS_DEFAULT["screen_size"][1])
        )

        storage_group = norm_ssd[r["id"]]
        brand_s = _score_brand(r.get("brand"))
        price_s = _score_price(r.get("price_million"))

        total = (
            perf * weights.get("top:perf", TOP_WEIGHTS_DEFAULT["perf"][1]) +
            screen_group * weights.get("top:screen", TOP_WEIGHTS_DEFAULT["screen"][1]) +
            gpu_group * weights.get("top:gpu", TOP_WEIGHTS_DEFAULT["gpu"][1]) +
            storage_group * weights.get("top:storage", TOP_WEIGHTS_DEFAULT["storage"][1]) +
            brand_s * weights.get("top:brand", TOP_WEIGHTS_DEFAULT["brand"][1]) +
            price_s * weights.get("top:price", TOP_WEIGHTS_DEFAULT["price"][1])
        )

        breakdown = {"perf": perf,"screen": screen_group,"gpu": gpu_group,"storage": storage_group,"brand": brand_s,"price": price_s}
        result.append((r, total, breakdown))

    result.sort(key=lambda x: x[1], reverse=True)
    return result

# -------------------------------
# GUI CHÍNH
# -------------------------------
class App(ttk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.master.title("DSS Laptop (AHP)")
        self.master.geometry("1300x860")
        self._apply_bw_theme()

        self.pack(fill="both", expand=True)
        self._build_ui()

    def _apply_bw_theme(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except:
            pass
        style.configure(".", background="#FFFFFF", foreground="#000000")
        style.configure("TLabel", background="#FFFFFF", foreground="#000000")
        style.configure("TFrame", background="#FFFFFF")
        style.configure("TButton", background="#EAEAEA", foreground="#000000", padding=6)
        style.configure("Treeview", background="#FFFFFF", fieldbackground="#FFFFFF", foreground="#000000")
        style.map("TButton", background=[("active", "#DDDDDD")])

    def _build_ui(self):
        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True)

        self.tab_data = ttk.Frame(nb)
        self.tab_weights = ttk.Frame(nb)
        self.tab_rank = ttk.Frame(nb)
        self.tab_chart = ttk.Frame(nb)
        self.tab_quiz = ttk.Frame(nb)

        nb.add(self.tab_data, text="Dữ liệu")
        nb.add(self.tab_weights, text="Trọng số")
        nb.add(self.tab_rank, text="Xếp hạng")
        nb.add(self.tab_chart, text="Biểu đồ")
        nb.add(self.tab_quiz, text="Ứng dụng lựa chọn laptop")

        self._build_tab_data()
        self._build_tab_weights()
        self._build_tab_rank()
        self._build_tab_chart()
        self._build_tab_quiz()

    # ---- Tab: Data
    def _build_tab_data(self):
        top = ttk.Frame(self.tab_data)
        top.pack(fill="x", padx=10, pady=10)

        ttk.Button(top, text="Thêm mẫu", command=self.add_dialog).pack(side="left", padx=5)
        ttk.Button(top, text="Sửa mẫu", command=self.edit_selected).pack(side="left", padx=5)
        ttk.Button(top, text="Xoá mẫu", command=self.delete_selected).pack(side="left", padx=5)
        ttk.Button(top, text="Nhập CSV", command=self.import_csv).pack(side="left", padx=5)
        ttk.Button(top, text="Tải mẫu CSV", command=self.save_csv_template).pack(side="left", padx=5)

        cols = ("id","name","brand","cpu_mark","ram_gb","ssd_gb","gpu_brand","gpu_bw","vram_gb","screen_size","screen_res","screen_tech","price_million")
        self.tree = ttk.Treeview(self.tab_data, columns=cols, show="headings", height=18)
        for c in cols:
            self.tree.heading(c, text=c)
            self.tree.column(c, width=100, anchor="center")
        self.tree.column("name", width=200, anchor="w")
        self.tree.pack(fill="both", expand=True, padx=10, pady=10)
        self.refresh_tree()

    def refresh_tree(self):
        for i in self.tree.get_children():
            self.tree.delete(i)
        with get_conn() as con:
            rows = fetch_laptops(con)
        for r in rows:
            self.tree.insert("", "end", values=tuple(r[c] for c in self.tree["columns"]))

    def add_dialog(self):
        ItemDialog(self.master, on_save=self._insert_row)

    def edit_selected(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Sửa", "Chọn một dòng.")
            return
        vals = self.tree.item(sel[0], "values")
        row = {c: vals[i] for i, c in enumerate(self.tree["columns"])}
        ItemDialog(self.master, row=row, on_save=self._update_row)

    def delete_selected(self):
        sel = self.tree.selection()
        if not sel:
            return
        vals = self.tree.item(sel[0], "values")
        rid = int(vals[0])
        if messagebox.askyesno("Xoá", f"Xoá mẫu ID {rid}?"):
            with get_conn() as con:
                con.execute("DELETE FROM laptops WHERE id=?", (rid,))
                con.commit()
            self.refresh_tree()

    def import_csv(self):
        path = filedialog.askopenfilename(filetypes=[("CSV","*.csv")])
        if not path: return
        with open(path, newline="", encoding="utf-8") as f, get_conn() as con:
            reader = csv.DictReader(f)
            for row in reader:
                con.execute("""
                INSERT INTO laptops(name,brand,cpu_mark,ram_gb,ssd_gb,gpu_brand,gpu_bw,vram_gb,screen_size,screen_res,screen_tech,price_million)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
                """, (
                    row.get("name"), row.get("brand"), _float(row.get("cpu_mark")),
                    _int(row.get("ram_gb")), _int(row.get("ssd_gb")), row.get("gpu_brand"),
                    _float(row.get("gpu_bw")), _float(row.get("vram_gb")), _float(row.get("screen_size")),
                    row.get("screen_res"), row.get("screen_tech"), _float(row.get("price_million"))
                ))
            con.commit()
        self.refresh_tree()
        messagebox.showinfo("CSV", "Đã nhập CSV.")

    def save_csv_template(self):
        path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV","*.csv")], initialfile="laptops_template.csv")
        if not path: return
        headers = ["name","brand","cpu_mark","ram_gb","ssd_gb","gpu_brand","gpu_bw","vram_gb","screen_size","screen_res","screen_tech","price_million"]
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(headers)
        messagebox.showinfo("CSV", f"Đã lưu template: {os.path.basename(path)}")

    def _insert_row(self, rec: dict):
        with get_conn() as con:
            con.execute("""
                INSERT INTO laptops(name,brand,cpu_mark,ram_gb,ssd_gb,gpu_brand,gpu_bw,vram_gb,screen_size,screen_res,screen_tech,price_million)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                rec["name"], rec["brand"], rec["cpu_mark"], rec["ram_gb"], rec["ssd_gb"], rec["gpu_brand"],
                rec["gpu_bw"], rec["vram_gb"], rec["screen_size"], rec["screen_res"], rec["screen_tech"], rec["price_million"]
            ))
            con.commit()
        self.refresh_tree()

    def _update_row(self, rec: dict):
        with get_conn() as con:
            con.execute("""
            UPDATE laptops SET name=?, brand=?, cpu_mark=?, ram_gb=?, ssd_gb=?, gpu_brand=?, gpu_bw=?, vram_gb=?,
                               screen_size=?, screen_res=?, screen_tech=?, price_million=?
            WHERE id=?
            """, (
                rec["name"], rec["brand"], rec["cpu_mark"], rec["ram_gb"], rec["ssd_gb"], rec["gpu_brand"],
                rec["gpu_bw"], rec["vram_gb"], rec["screen_size"], rec["screen_res"], rec["screen_tech"], rec["price_million"],
                rec["id"]
            ))
            con.commit()
        self.refresh_tree()

    # ---- Tab: Weights (Entry left + short Scale right)
    def _build_tab_weights(self):
        frm = ttk.Frame(self.tab_weights)
        frm.pack(fill="both", expand=True, padx=10, pady=10)

        self.weight_vars_num: Dict[str, tk.DoubleVar] = {}
        self.weight_vars_str: Dict[str, tk.StringVar] = {}

        def add_group(title, items, prefix, rowstart):
            ttk.Label(frm, text=title, font=("TkDefaultFont", 12, "bold")).grid(row=rowstart, column=0, sticky="w", pady=(10,6), columnspan=3)
            r = rowstart + 1
            for key, (label, default) in items.items():
                ttk.Label(frm, text=f"• {label}").grid(row=r, column=0, sticky="w", padx=10, pady=4)

                num = tk.DoubleVar(value=default)   # for Scale
                svar = tk.StringVar(value=f"{default:.6f}")  # for Entry
                k = f"{prefix}:{key}"
                self.weight_vars_num[k] = num
                self.weight_vars_str[k] = svar

                # Entry (left)
                e = ttk.Entry(frm, textvariable=svar, width=12)
                e.grid(row=r, column=1, sticky="w", padx=(6,10), pady=4)

                # Short Scale (right)
                sc = ttk.Scale(frm, from_=0.0, to=1.0, orient="horizontal", variable=num,
                               length=180, command=lambda _v, kk=k: self._on_scale_change(kk))
                sc.grid(row=r, column=2, sticky="w", padx=10, pady=4)

                # Bind entry validate
                e.bind("<FocusOut>", lambda _ev, kk=k: self._on_entry_change(kk))
                e.bind("<Return>",   lambda _ev, kk=k: self._on_entry_change(kk))

                r += 1
            return r

        row = 0
        row = add_group("Trọng số cấp cao (Top-level)", TOP_WEIGHTS_DEFAULT, "top", row)
        row = add_group("Nhóm Hiệu suất", PERF_WEIGHTS_DEFAULT, "perf", row)
        row = add_group("Nhóm Màn hình", SCREEN_WEIGHTS_DEFAULT, "screen", row)
        row = add_group("Nhóm Card đồ hoạ", GPU_WEIGHTS_DEFAULT, "gpu", row)

        btnfrm = ttk.Frame(frm)
        btnfrm.grid(row=row, column=0, columnspan=3, pady=12, sticky="e")
        ttk.Button(btnfrm, text="Khôi phục mặc định", command=self.reset_weights).pack(side="left", padx=6)
        ttk.Button(btnfrm, text="Lưu trọng số", command=self.save_weights).pack(side="left", padx=6)

        self.load_weights()

    def _on_scale_change(self, key: str):
        val = self.weight_vars_num[key].get()
        self.weight_vars_str[key].set(f"{float(val):.6f}")

    def _on_entry_change(self, key: str):
        s = self.weight_vars_str[key].get().strip().replace(",", ".")
        try:
            v = float(s)
        except ValueError:
            v = self.weight_vars_num[key].get()
        v = max(0.0, min(1.0, v))
        self.weight_vars_num[key].set(v)
        self.weight_vars_str[key].set(f"{v:.6f}")

    def _autosave_current_weights(self):
        for k in list(self.weight_vars_num.keys()):
            self._on_entry_change(k)
            update_weight(k, self.weight_vars_num[k].get())

    def load_weights(self):
        with get_conn() as con:
            w = fetch_weights(con)
        for k, num in self.weight_vars_num.items():
            if k in w:
                num.set(w[k])
                self.weight_vars_str[k].set(f"{w[k]:.6f}")

    def reset_weights(self):
        for k in list(self.weight_vars_num.keys()):
            group, sub = k.split(":", 1)
            if group == "top":
                v = TOP_WEIGHTS_DEFAULT[sub][1]
            elif group == "perf":
                v = PERF_WEIGHTS_DEFAULT[sub][1]
            elif group == "screen":
                v = SCREEN_WEIGHTS_DEFAULT[sub][1]
            elif group == "gpu":
                v = GPU_WEIGHTS_DEFAULT[sub][1]
            else:
                v = 0.0
            self.weight_vars_num[k].set(v)
            self.weight_vars_str[k].set(f"{v:.6f}")

    def save_weights(self):
        for k in list(self.weight_vars_num.keys()):
            self._on_entry_change(k)
            update_weight(k, self.weight_vars_num[k].get())
        messagebox.showinfo("Trọng số", "Đã lưu trọng số.")

    # ---- Tab: Ranking
    def _build_tab_rank(self):
        top = ttk.Frame(self.tab_rank)
        top.pack(fill="x", padx=10, pady=10)
        ttk.Button(top, text="Tính điểm & Xếp hạng", command=self.calc_rank).pack(side="left", padx=5)

        cols = ("rank","name","brand","score","perf","screen","gpu","storage","brand_s","price_s")
        self.rank_tree = ttk.Treeview(self.tab_rank, columns=cols, show="headings", height=18)
        headers = {
            "rank": "Hạng", "name":"Model", "brand":"Hãng", "score":"Điểm tổng",
            "perf":"Hiệu suất", "screen":"Màn hình", "gpu":"Card", "storage":"Dung lượng",
            "brand_s":"Thương hiệu", "price_s":"Giá"
        }
        for c in cols:
            self.rank_tree.heading(c, text=headers[c])
            self.rank_tree.column(c, width=100, anchor="center")
        self.rank_tree.column("name", width=240, anchor="w")
        self.rank_tree.pack(fill="both", expand=True, padx=10, pady=10)

    def calc_rank(self):
        # Auto-save weights from UI before ranking
        self._autosave_current_weights()
        res = ahp_rank()
        for i in self.rank_tree.get_children():
            self.rank_tree.delete(i)
        for idx, (row, total, bd) in enumerate(res, start=1):
            self.rank_tree.insert("", "end", values=(
                idx, row["name"], row["brand"], round(total,4),
                round(bd["perf"],3), round(bd["screen"],3), round(bd["gpu"],3),
                round(bd["storage"],3), round(bd["brand"],3), round(bd["price"],3)
            ))
        # always refresh chart with latest ranking
        self.plot_top(res)

    # ---- Tab: Chart
    def _build_tab_chart(self):
        cn = ttk.Frame(self.tab_chart)
        cn.pack(fill="both", expand=True, padx=10, pady=10)
        self.fig = Figure(figsize=(8,4), dpi=100)
        self.ax = self.fig.add_subplot(111)
        self.canvas = FigureCanvasTkAgg(self.fig, master=cn)
        self.canvas.get_tk_widget().pack(fill="both", expand=True)

    def plot_top(self, res: List[Tuple[dict, float, Dict[str, float]]], topn: int = 10):
        self.ax.clear()
        if not res:
            self.ax.set_title("Chưa có dữ liệu")
            self.canvas.draw()
            return
        names = [r[0]["name"] for r in res[:topn]]
        scores = [r[1] for r in res[:topn]]
        self.ax.barh(names, scores)
        self.ax.invert_yaxis()
        self.ax.set_xlabel("Điểm tổng (chuẩn hoá theo trọng số)")
        self.ax.set_title(f"Top {min(topn, len(names))} laptop khuyến nghị")
        self.canvas.draw()

    # ---- Tab: Ứng dụng lựa chọn laptop (trắc nghiệm)
    def _build_tab_quiz(self):
        root = ttk.Frame(self.tab_quiz, padding=10)
        root.pack(fill="both", expand=True)
        left = ttk.Frame(root)
        right = ttk.Frame(root)
        left.pack(side="left", fill="y", padx=(0,12))
        right.pack(side="left", fill="both", expand=True)

        # --- Câu hỏi
        q1 = ttk.LabelFrame(left, text="Nhu cầu sử dụng (chọn nhiều)")
        q1.pack(fill="x", pady=6)
        self.need_game = tk.BooleanVar(value=False)
        self.need_design = tk.BooleanVar(value=False)
        self.need_code = tk.BooleanVar(value=True)
        self.need_office = tk.BooleanVar(value=True)
        self.need_video = tk.BooleanVar(value=False)
        ttk.Checkbutton(q1, text="Chơi game", variable=self.need_game).pack(anchor="w")
        ttk.Checkbutton(q1, text="Thiết kế đồ hoạ", variable=self.need_design).pack(anchor="w")
        ttk.Checkbutton(q1, text="Lập trình", variable=self.need_code).pack(anchor="w")
        ttk.Checkbutton(q1, text="Văn phòng", variable=self.need_office).pack(anchor="w")
        ttk.Checkbutton(q1, text="Biên tập video", variable=self.need_video).pack(anchor="w")

        q2 = ttk.LabelFrame(left, text="Hệ điều hành")
        q2.pack(fill="x", pady=6)
        self.os_pref = tk.StringVar(value="Any")
        ttk.Combobox(q2, values=["Any","Windows","macOS"], textvariable=self.os_pref, state="readonly", width=18).pack(fill="x", padx=4, pady=6)

        q3 = ttk.LabelFrame(left, text="Khoảng tiền (triệu VND)")
        q3.pack(fill="x", pady=6)
        self.budget_min = tk.StringVar(value="0")
        self.budget_max = tk.StringVar(value="999")
        row = ttk.Frame(q3); row.pack(fill="x", padx=4, pady=2)
        ttk.Label(row, text="Tối thiểu").pack(side="left")
        ttk.Entry(row, textvariable=self.budget_min, width=8).pack(side="left", padx=(6,12))
        ttk.Label(row, text="Tối đa").pack(side="left")
        ttk.Entry(row, textvariable=self.budget_max, width=8).pack(side="left", padx=6)

        ttk.Button(left, text="Áp dụng preset theo nhu cầu", command=self.apply_preset_from_needs).pack(fill="x", pady=(10,6))
        ttk.Button(left, text="Đề xuất ngay", command=self.recommend_from_quiz).pack(fill="x")

        # --- Tinh chỉnh trọng số (%)
        tune = ttk.LabelFrame(left, text="Tinh chỉnh trọng số (theo %)")
        tune.pack(fill="x", pady=10)
        self.top_vars_pct: Dict[str, tk.DoubleVar] = {}
        keys = [("Hiệu suất","perf"),("Màn hình","screen"),("Card đồ hoạ","gpu"),
                ("Dung lượng","storage"),("Thương hiệu","brand"),("Giá cả","price")]
        for label, key in keys:
            var = tk.DoubleVar(value=TOP_WEIGHTS_DEFAULT[key][1]*100)
            self.top_vars_pct[key] = var
            row = ttk.Frame(tune); row.pack(fill="x", pady=2)
            ttk.Label(row, text=label).pack(side="left")
            s = ttk.Scale(row, from_=0, to=100, orient="horizontal", variable=var, length=160)
            s.pack(side="left", padx=8)
            ttk.Label(row, textvariable=var, width=6).pack(side="left")

        self.sum_label = ttk.Label(tune, text="Tổng: 100%")
        self.sum_label.pack(anchor="e", pady=(4,0))
        self._update_sum_label()

        # --- Kết quả
        title = ttk.Label(right, text="Kết quả gợi ý", font=("TkDefaultFont", 12, "bold"))
        title.pack(anchor="w")
        cols = ("Hạng","Model","Hãng","Điểm","Giá (tr)","CPU","RAM","SSD","GPU Brand","VRAM","Màn hình","Độ phân giải")
        self.quiz_tree = ttk.Treeview(right, columns=cols, show="headings", height=22)
        for c in cols:
            self.quiz_tree.heading(c, text=c)
            self.quiz_tree.column(c, width=100 if c!="Model" else 240, anchor="center")
        self.quiz_tree.pack(fill="both", expand=True, pady=(6,0))

    # ---- Quiz helpers
    def _update_sum_label(self):
        s = sum(v.get() for v in self.top_vars_pct.values())
        self.sum_label.configure(text=f"Tổng: {s:.1f}%")

    def _get_normalized_top_weights_from_pct(self) -> Dict[str, float]:
        s = sum(v.get() for v in self.top_vars_pct.values())
        if s <= 1e-9:
            n = len(self.top_vars_pct)
            return {k: 1.0/n for k in self.top_vars_pct}
        return {k: v.get()/s for k, v in self.top_vars_pct.items()}

    def apply_preset_from_needs(self):
        preset = {"perf":0.40, "screen":0.18, "gpu":0.15, "storage":0.09, "brand":0.08, "price":0.10}
        if self.need_game.get():
            preset["gpu"] += 0.15; preset["perf"] += 0.10; preset["screen"] += 0.05; preset["price"] -= 0.05
        if self.need_design.get():
            preset["gpu"] += 0.10; preset["screen"] += 0.10; preset["perf"] += 0.05
        if self.need_code.get():
            preset["perf"] += 0.10; preset["screen"] += 0.02; preset["price"] += 0.04
        if self.need_office.get():
            preset["price"] += 0.08; preset["brand"] += 0.02; preset["screen"] += 0.02
        if self.need_video.get():
            preset["gpu"] += 0.10; preset["perf"] += 0.05; preset["screen"] += 0.05
        total = sum(max(0.0, v) for v in preset.values())
        if total <= 0: total = 1.0
        for k in preset:
            preset[k] = max(0.0, preset[k]) / total
        for k, var in self.top_vars_pct.items():
            var.set(preset[k]*100)
        self._update_sum_label()
        messagebox.showinfo("Preset", "Đã áp dụng preset theo nhu cầu. Bạn có thể tinh chỉnh thêm bằng thanh gạt.")

    def recommend_from_quiz(self):
        os_pref = self.os_pref.get()
        try:
            minb = float(self.budget_min.get())
            maxb = float(self.budget_max.get())
        except:
            messagebox.showerror("Lỗi", "Khoảng tiền không hợp lệ.")
            return
        if minb < 0 or maxb <= 0 or minb > maxb:
            messagebox.showerror("Lỗi", "Khoảng tiền không hợp lệ.")
            return

        with get_conn() as con:
            rows = fetch_laptops(con)

        filt = []
        for r in rows:
            if os_pref == "macOS" and r["brand"] != "Apple":
                continue
            if os_pref == "Windows" and r["brand"] == "Apple":
                continue
            price = r.get("price_million") or 0
            if not (minb <= price <= maxb):
                continue
            filt.append(r)

        if not filt:
            self.quiz_tree.delete(*self.quiz_tree.get_children())
            messagebox.showinfo("Kết quả", "Không có mẫu nào phù hợp. Hãy nới điều kiện hoặc nhập thêm dữ liệu.")
            return

        id_cpu = [(r["id"], r["cpu_mark"]) for r in filt]
        id_ram = [(r["id"], float(r["ram_gb"]) if r["ram_gb"] is not None else None) for r in filt]
        id_ssd = [(r["id"], float(r["ssd_gb"]) if r["ssd_gb"] is not None else None) for r in filt]
        id_gpu_bw = [(r["id"], r["gpu_bw"]) for r in filt]
        id_vram = [(r["id"], r["vram_gb"]) for r in filt]
        norm_cpu = _normalize_linear(id_cpu)
        norm_ram = _normalize_linear(id_ram)
        norm_ssd = _normalize_linear(id_ssd)
        norm_gpu_bw = _normalize_linear(id_gpu_bw)
        norm_vram = _normalize_linear(id_vram)

        scores = []
        for r in filt:
            cpu_s = norm_cpu[r["id"]]; ram_s = norm_ram[r["id"]]; ssd_s = norm_ssd[r["id"]]
            perf = (cpu_s * PERF_WEIGHTS_DEFAULT["cpu_mark"][1] +
                    ram_s * PERF_WEIGHTS_DEFAULT["ram_gb"][1] +
                    ssd_s * PERF_WEIGHTS_DEFAULT["ssd_gb"][1] +
                    0.5 * PERF_WEIGHTS_DEFAULT["gpu_perf"][1])
            gpu_brand_s = 0.9 if str(r.get("gpu_brand","")).upper().find("NVIDIA")>=0 else 0.6
            gpu_group = (gpu_brand_s * GPU_WEIGHTS_DEFAULT["gpu_brand"][1] +
                         norm_gpu_bw[r["id"]] * GPU_WEIGHTS_DEFAULT["gpu_bw"][1] +
                         norm_vram[r["id"]] * GPU_WEIGHTS_DEFAULT["vram_gb"][1])
            screen_group = (
                _score_screen_tech(r.get("screen_tech")) * SCREEN_WEIGHTS_DEFAULT["screen_tech"][1] +
                _score_screen_res(r.get("screen_res")) * SCREEN_WEIGHTS_DEFAULT["screen_res"][1] +
                _score_screen_size(r.get("screen_size")) * SCREEN_WEIGHTS_DEFAULT["screen_size"][1]
            )
            storage = norm_ssd[r["id"]]
            brand_s = _score_brand(r.get("brand"))
            price_s = _score_price(r.get("price_million"))
            scores.append((r, perf, screen_group, gpu_group, storage, brand_s, price_s))

        top_w = self._get_normalized_top_weights_from_pct()
        ranked = []
        for (r, perf, screen, gpu, storage, brand, price) in scores:
            total = (perf * top_w["perf"] + screen * top_w["screen"] + gpu * top_w["gpu"] +
                     storage * top_w["storage"] + brand * top_w["brand"] + price * top_w["price"])
            ranked.append((total, r, perf, screen, gpu, storage, brand, price))
        ranked.sort(key=lambda x: x[0], reverse=True)

        self.quiz_tree.delete(*self.quiz_tree.get_children())
        for i, (tot, r, perf, screen, gpu, storage, brand, price) in enumerate(ranked, start=1):
            self.quiz_tree.insert("", "end", values=(
                i, r["name"], r["brand"], round(tot,4), r.get("price_million"),
                r.get("cpu_mark"), r.get("ram_gb"), r.get("ssd_gb"),
                r.get("gpu_brand"), r.get("vram_gb"),
                r.get("screen_tech"), r.get("screen_res")
            ))

# -------------------------------
# Item Dialog
# -------------------------------
def _int(x):
    try: return int(x) if x is not None and str(x) != "" else None
    except: return None

def _float(x):
    try: return float(x) if x is not None and str(x) != "" else None
    except: return None

class ItemDialog(tk.Toplevel):
    FIELDS = [
        ("name","Tên model"),
        ("brand","Hãng (Apple/Lenovo/Dell/Asus/MSI/khác)"),
        ("cpu_mark","CPU Mark (số, cao hơn tốt hơn)"),
        ("ram_gb","RAM (GB)"),
        ("ssd_gb","SSD (GB)"),
        ("gpu_brand","GPU Brand (NVIDIA/AMD/Intel/Apple)"),
        ("gpu_bw","GPU BW (GB/s)"),
        ("vram_gb","VRAM (GB)"),
        ("screen_size","Màn hình (inch)"),
        ("screen_res","Độ phân giải (vd 1920x1080, 2560x1600)"),
        ("screen_tech","Công nghệ (IPS/OLED/TN)"),
        ("price_million","Giá (triệu VND)"),
    ]
    def __init__(self, master, row=None, on_save=None):
        super().__init__(master)
        self.title("Thông tin laptop")
        self.on_save = on_save
        self.vars: Dict[str, tk.StringVar] = {}
        self.resizable(False, False)

        frm = ttk.Frame(self)
        frm.pack(padx=12, pady=12)

        r=0
        if row and "id" in row:
            self.vars["id"] = tk.StringVar(value=str(row["id"]))
        for key, label in self.FIELDS:
            ttk.Label(frm, text=label).grid(row=r, column=0, sticky="w", pady=3)
            val = "" if not row else str(row.get(key,"") or "")
            v = tk.StringVar(value=val)
            self.vars[key] = v
            ttk.Entry(frm, textvariable=v, width=40).grid(row=r, column=1, pady=3, padx=6)
            r+=1

        btnf = ttk.Frame(frm)
        btnf.grid(row=r, column=0, columnspan=2, pady=(10,0))
        ttk.Button(btnf, text="Lưu", command=self._save).pack(side="left", padx=5)
        ttk.Button(btnf, text="Huỷ", command=self.destroy).pack(side="left", padx=5)

        self.grab_set()
        self.focus_set()

    def _save(self):
        rec = {k: v.get() for k, v in self.vars.items()}
        rec["cpu_mark"] = _float(rec.get("cpu_mark"))
        rec["ram_gb"] = _int(rec.get("ram_gb"))
        rec["ssd_gb"] = _int(rec.get("ssd_gb"))
        rec["gpu_bw"] = _float(rec.get("gpu_bw"))
        rec["vram_gb"] = _float(rec.get("vram_gb"))
        rec["screen_size"] = _float(rec.get("screen_size"))
        rec["price_million"] = _float(rec.get("price_million"))
        if self.on_save:
            self.on_save(rec)
        self.destroy()

# -------------------------------
# Seed demo data (10 mẫu)
# -------------------------------
def seed_demo():
    with get_conn() as con:
        cur = con.cursor()
        cur.execute("SELECT COUNT(*) FROM laptops")
        if cur.fetchone()[0] > 0:
            return
        demo = [
            ("MacBook Pro 14 M1 Pro", "Apple", 17000, 16, 512, "Apple", 200, 0, 14.2, "3024x1964", "IPS", 40),
            ("Lenovo ThinkPad X1 Carbon G10", "Lenovo", 15500, 16, 512, "Intel", 100, 0, 14.0, "1920x1200", "IPS", 32),
            ("Dell XPS 15 9520", "Dell", 18000, 32, 1000, "NVIDIA", 224, 6, 15.6, "3840x2160", "OLED", 50),
            ("Asus TUF A15", "Asus", 16000, 16, 512, "NVIDIA", 192, 6, 15.6, "1920x1080", "IPS", 23),
            ("MSI GF63", "MSI", 14500, 16, 512, "NVIDIA", 128, 4, 15.6, "1920x1080", "IPS", 20),
            ("MacBook Air 13 M2", "Apple", 13500, 8, 256, "Apple", 150, 0, 13.6, "2560x1664", "IPS", 24),
            ("Lenovo Legion 5", "Lenovo", 17000, 16, 512, "NVIDIA", 224, 8, 15.6, "1920x1080", "IPS", 28),
            ("Dell Inspiron 14", "Dell", 12000, 8, 256, "Intel", 80, 0, 14.0, "1920x1080", "IPS", 15),
            ("Asus Vivobook Pro 15", "Asus", 16500, 16, 512, "NVIDIA", 200, 6, 15.6, "2560x1440", "OLED", 27),
            ("HP Pavilion 15", "HP", 12500, 16, 512, "Intel", 90, 0, 15.6, "1920x1080", "IPS", 18),
        ]
        cur.executemany("""
        INSERT INTO laptops(name,brand,cpu_mark,ram_gb,ssd_gb,gpu_brand,gpu_bw,vram_gb,screen_size,screen_res,screen_tech,price_million)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
        """, demo)
        con.commit()

# -------------------------------
def main():
    init_db()
    seed_demo()
    root = tk.Tk()
    App(root)
    root.mainloop()

if __name__ == "__main__":
    main()
