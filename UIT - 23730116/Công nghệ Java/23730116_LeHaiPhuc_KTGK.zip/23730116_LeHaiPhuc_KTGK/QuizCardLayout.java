/* KTGK CONG NGHE JAVA
 * LE HAI PHUC
 * 23730116
 */
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays; // them cho Java 8

/*
  Ung dung thi trac nghiem bang CardLayout
  - Dieu huong bang First / <- / -> / Last hoac nut so 1..14
  - O so dang chon vien do; o da tra loi to xam
  - Submit de cham diem va thong ke cau chua tra loi
*/
public class QuizCardLayout extends JFrame {

    // ==== Model du lieu ====
    static class Question {
        final String text;
        final String[] options; // 4 lua chon
        final int correct;      // chi so 0..3

        Question(String text, String a, String b, String c, String d, int correct) {
            this.text = text;
            this.options = new String[]{a, b, c, d};
            this.correct = correct;
        }
    }

    // Panel hien thi 1 cau hoi
    static class QuestionPanel extends JPanel {
        final JLabel lblQ;
        final JRadioButton[] choices = new JRadioButton[4];
        final ButtonGroup group = new ButtonGroup();

        QuestionPanel(Question q, int index) {
            setLayout(new BorderLayout(10, 10));
            setBorder(new CompoundBorder(new EmptyBorder(12, 12, 12, 12),
                    new LineBorder(Color.LIGHT_GRAY)));

            // tieu de cau hoi
            lblQ = new JLabel(String.format("%d) %s", index + 1, q.text));
            lblQ.setFont(lblQ.getFont().deriveFont(Font.BOLD, 18f));
            add(lblQ, BorderLayout.NORTH);

            // 4 lua chon
            JPanel center = new JPanel(new GridLayout(4, 1, 6, 8));
            center.setBorder(new EmptyBorder(8, 16, 8, 8));
            for (int i = 0; i < 4; i++) {
                choices[i] = new JRadioButton((char)('A' + i) + ". " + q.options[i]);
                choices[i].setFont(choices[i].getFont().deriveFont(16f));
                group.add(choices[i]);
                center.add(choices[i]);
            }
            add(center, BorderLayout.CENTER);
        }

        void setSelection(int idx) {
            group.clearSelection();
            if (idx >= 0 && idx < 4) choices[idx].setSelected(true);
        }

        int getSelection() {
            for (int i = 0; i < 4; i++) if (choices[i].isSelected()) return i;
            return -1;
        }
    }

    // ==== Bo cau hoi: 14 cau ve Java (tieng Viet co dau) ====
final List<Question> bank = Arrays.asList(
    new Question("Đâu KHÔNG phải là kiểu nguyên thủy trong Java?",
        "String", "int", "boolean", "double", 0),
    new Question("Cấu trúc nào giữ thứ tự và cho phép trùng lặp?",
        "HashSet", "TreeSet", "ArrayList", "HashMap", 2),
    new Question("Từ khóa chặn kế thừa là?",
        "static", "final", "abstract", "default", 1),
    new Question("Phương thức nào tạo luồng mới?",
        "start()", "run()", "execute()", "begin()", 0),
    new Question("Điều nào đúng về interface?",
        "Interface không thể có phương thức static",
        "Trường của interface mặc định thay đổi được",
        "Từ Java 8 có default method",
        "Có thể khởi tạo trực tiếp bằng new", 2),
    new Question("Khối nào luôn chạy dù có lỗi?",
        "catch", "finally", "throw", "throws", 1),
    new Question("Cú pháp generic nào hợp lệ?",
        "List<String>", "List<int>", "List<>", "List", 0),
    new Question("Hợp đồng equals/hashCode đúng là?",
        "Nếu equals thì hashCode phải bằng nhau",
        "HashCode bằng nhau thì chắc chắn equals",
        "Không có ràng buộc nào",
        "Chỉ override equals() là đủ", 0),
    new Question("Toán tử Stream nào là terminal?",
        "map", "filter", "collect", "peek", 2),
    new Question("'var' nghĩa là gì?",
        "Biến cục bộ suy luận kiểu",
        "Biến kiểu Object",
        "Dùng cho field & tham số",
        "Chỉ cho tham số phương thức", 0),
    new Question("Điều nào đúng về String?",
        "String mutable (thay đổi được)",
        "String ở trên stack",
        "String immutable (bất biến)",
        "String không phải đối tượng", 2),
    new Question("Switch expression dùng mũi tên nào?",
        "->", "=>", ":=", "::", 0),
    new Question("try-with-resources yêu cầu gì?",
        "implements AutoCloseable", "implements Serializable",
        "Phải khai báo final", "Chỉ dùng 1 tài nguyên", 0),
    new Question("Biến cục bộ chưa khởi tạo thì sao?",
        "0", "null", "false", "Lỗi biên dịch", 3)
);


    // ==== Trang thai view ====
    final CardLayout cardLayout = new CardLayout();
    final JPanel cardHolder = new JPanel(cardLayout);
    final QuestionPanel[] panels = new QuestionPanel[bank.size()];
    final int[] answers = new int[bank.size()]; // -1 = chua chon
    int current = 0;

    // Luoi so ben phai
    final JPanel numberGrid = new JPanel(new GridLayout(7, 2, 6, 6)); // 14 nut
    final JButton[] indexButtons = new JButton[bank.size()];
    final Border normalBorder = new LineBorder(Color.DARK_GRAY, 1);
    final Border currentBorder = new LineBorder(Color.RED, 2);

    // Cac nut dieu huong ben duoi
    final JButton btnFirst = new JButton("First");
    final JButton btnPrev  = new JButton("<-");
    final JButton btnNext  = new JButton("->");
    final JButton btnLast  = new JButton("Last");
    final JButton btnSubmit = new JButton("Submit");

    public QuizCardLayout() {
        super("CardLayout Quiz - Java");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Tao cac the cau hoi
        for (int i = 0; i < bank.size(); i++) {
            answers[i] = -1;
            panels[i] = new QuestionPanel(bank.get(i), i);
            final int idx = i;
            // Luu lua chon khi user click
            for (JRadioButton rb : panels[i].choices) {
                rb.addActionListener(e -> {
                    answers[idx] = panels[idx].getSelection();
                    refreshNumberGrid();
                });
            }
            cardHolder.add(panels[i], String.valueOf(i));
        }

        // Luoi nut so 1..14
        numberGrid.setBorder(new CompoundBorder(new EmptyBorder(8, 8, 8, 8),
                new TitledBorder("Danh sách các câu")));
        for (int i = 0; i < bank.size(); i++) {
            final int idx = i;
            indexButtons[i] = new JButton(String.valueOf(i + 1));
            indexButtons[i].setFocusPainted(false);
            indexButtons[i].setBorder(normalBorder);
            indexButtons[i].setOpaque(true);
            indexButtons[i].setBackground(Color.WHITE);
            indexButtons[i].setToolTipText("Chuyen den cau " + (i + 1));
            indexButtons[i].addActionListener(e -> goTo(idx));
            numberGrid.add(indexButtons[i]);
        }

        // Thanh dieu huong
        JPanel nav = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 8));
        nav.add(btnFirst);
        nav.add(btnPrev);
        nav.add(btnNext);
        nav.add(btnLast);
        nav.add(btnSubmit);

        btnFirst.addActionListener(e -> goTo(0));
        btnLast.addActionListener(e -> goTo(bank.size() - 1));
        btnPrev.addActionListener(e -> goTo(Math.max(0, current - 1)));
        btnNext.addActionListener(e -> goTo(Math.min(bank.size() - 1, current + 1)));
        btnSubmit.addActionListener(e -> submit());

        // Bo cuc chinh: trai (card), phai (luoi so), duoi (nav)
        JPanel main = new JPanel(new BorderLayout(8, 8));
        main.setBorder(new EmptyBorder(8, 8, 8, 8));

        JPanel left = new JPanel(new BorderLayout());
        left.add(cardHolder, BorderLayout.CENTER);
        left.setPreferredSize(new Dimension(520, 360));

        JPanel right = new JPanel(new BorderLayout());
        right.add(numberGrid, BorderLayout.CENTER);
        right.setPreferredSize(new Dimension(180, 360));

        main.add(left, BorderLayout.CENTER);
        main.add(right, BorderLayout.EAST);
        main.add(nav, BorderLayout.SOUTH);

        setContentPane(main);
        pack();
        setLocationRelativeTo(null);

        goTo(0); // hien cau dau
    }

    // Di chuyen den cau i
    private void goTo(int i) {
        current = i;
        cardLayout.show(cardHolder, String.valueOf(i));
        panels[i].setSelection(answers[i]); // dong bo chon
        refreshNumberGrid();
    }

    // Cap nhat vien mau va mau nen o so
    private void refreshNumberGrid() {
        for (int i = 0; i < indexButtons.length; i++) {
            JButton b = indexButtons[i];
            b.setBorder(i == current ? currentBorder : normalBorder);
            boolean answered = answers[i] >= 0;
            b.setBackground(answered ? new Color(230, 230, 230) : Color.WHITE);
            b.setToolTipText((answered ? "Da tra loi" : "Chua tra loi") +
                    " - chuyen den cau " + (i + 1));
        }
    }

    // Cham diem va hien ket qua
    private void submit() {
        int unanswered = 0, correct = 0;
        java.util.List<Integer> blank = new ArrayList<>();
        for (int i = 0; i < bank.size(); i++) {
            if (answers[i] == -1) { unanswered++; blank.add(i + 1); }
            if (answers[i] == bank.get(i).correct) correct++;
        }
        StringBuilder msg = new StringBuilder();
        msg.append("Dung: ").append(correct).append("/").append(bank.size());
        msg.append("\nSai : ").append(bank.size() - correct - unanswered);
        msg.append("\nChua tra loi: ").append(unanswered);
        if (unanswered > 0) msg.append("\nCac cau chua tra loi: ").append(blank);
        JOptionPane.showMessageDialog(this, msg.toString(),
                "Ket qua", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        // Dat Look and Feel he thong (neu co)
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new QuizCardLayout().setVisible(true));
    }
}
