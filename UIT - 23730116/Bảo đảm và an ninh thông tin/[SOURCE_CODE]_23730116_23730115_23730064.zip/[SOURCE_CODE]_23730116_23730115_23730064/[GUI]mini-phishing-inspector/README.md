
# Mini Phishing Inspector — Demo (GUI)

- Không cần thư viện ngoài. Chạy GUI:
```
python inspector_gui.py
```
- Tabs: Summary / Indicators / Warnings / Headers / Body/URLs
- Menu: Open files/folder, Export CSV; Scan selected/all; Clear results.

