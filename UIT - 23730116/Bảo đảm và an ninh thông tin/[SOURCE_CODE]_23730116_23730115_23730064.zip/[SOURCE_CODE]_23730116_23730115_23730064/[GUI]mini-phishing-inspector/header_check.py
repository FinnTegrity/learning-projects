
# -*- coding: utf-8 -*-
from email.utils import parseaddr
import re, json, os

def _domain_from_addr(addr: str):
    name, email = parseaddr(addr or "")
    if "@" in email:
        return email.split("@", 1)[1].strip().lower()
    return ""

def _read_config_brands():
    here = os.path.dirname(__file__)
    path = os.path.join(here, "config", "brands.json")
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def _auth_from_headers(msg):
    lines = []
    for k in msg.keys():
        if k.lower() in ("authentication-results","received-spf"):
            lines.extend(msg.get_all(k, []))
    text = " ".join(lines).lower()
    res = {"spf":"unknown","dkim":"unknown","dmarc":"unknown"}
    m = re.search(r"spf\s*=\s*([a-z\-]+)", text);   res["spf"]   = m.group(1) if m else res["spf"]
    m = re.search(r"dkim\s*=\s*([a-z\-]+)", text);  res["dkim"]  = m.group(1) if m else res["dkim"]
    m = re.search(r"dmarc\s*=\s*([a-z\-]+)", text); res["dmarc"] = m.group(1) if m else res["dmarc"]
    return res, ("Authentication-Results: " + " ".join(lines)) if lines else ""

def analyze_headers(msg):
    indicators, warnings, score, tags = [], [], 0, set(["Delivery"])

    from_h = msg.get("From",""); reply_h = msg.get("Reply-To",""); ret_h = msg.get("Return-Path","")
    from_d = _domain_from_addr(from_h); reply_d = _domain_from_addr(reply_h); ret_d = _domain_from_addr(ret_h)

    indicators.append(("From", from_h))
    if reply_h: indicators.append(("Reply-To", reply_h))
    if ret_h:   indicators.append(("Return-Path", ret_h))

    if reply_d and from_d and reply_d != from_d:
        warnings.append(f"Reply-To khác miền với From ({reply_d} ≠ {from_d})"); score += 1
    if ret_d and from_d and ret_d != from_d:
        warnings.append(f"Return-Path khác miền với From ({ret_d} ≠ {from_d})"); score += 1

    auth, raw = _auth_from_headers(msg)
    if raw: indicators.append(("Auth-Results", auth))

    if auth.get("spf") in {"fail","softfail","none"} or auth.get("dmarc") in {"fail","softfail","none"}:
        warnings.append("Xác thực SPF/DMARC không đạt (fail/softfail/none)"); score += 2

    brands = _read_config_brands()
    display = parseaddr(from_h)[0].lower()
    if display:
        for brand, domains in brands.items():
            if brand in display:
                ok = any(d in from_d for d in domains)
                if not ok:
                    warnings.append(f'Hiển thị "{display}" gợi thương hiệu "{brand}" nhưng miền gửi là {from_d}'); score += 1
                break

    return {"indicators":indicators, "warnings":warnings, "score":score, "tags":sorted(list(tags))}
