
# -*- coding: utf-8 -*-
import os, zipfile, io

HIGH_RISK = {".exe",".js",".vbs",".scr",".bat",".cmd",".ps1",".apk",".jar",".dll",".msi",".docm",".xlsm",".iso",".lnk"}

def _walk_attachments(msg):
    atts = []
    for part in msg.walk():
        if part.get_content_disposition() == "attachment":
            atts.append(part)
    return atts

def analyze_attachments(msg):
    indicators, warnings, score, tags = [], [], 0, set(["Execution"])
    for part in _walk_attachments(msg):
        fname = part.get_filename() or "unknown"
        ctype = part.get_content_type()
        indicators.append(("Attachment", {"filename": fname, "mime": ctype}))
        ext = os.path.splitext(fname)[1].lower()
        if ext in HIGH_RISK:
            warnings.append(f"Đuôi tệp rủi ro cao: {ext}"); score += 2
        if ext == ".zip":
            try:
                payload = part.get_payload(decode=True)
                with zipfile.ZipFile(io.BytesIO(payload)) as zf:
                    names = zf.namelist()[:20]
                    if any(os.path.splitext(n)[1].lower() in HIGH_RISK for n in names):
                        warnings.append("Tệp .zip chứa tệp thực thi/script rủi ro"); score += 2
            except Exception:
                pass
    return {"indicators":indicators, "warnings":warnings, "score":score, "tags":sorted(list(tags))}
