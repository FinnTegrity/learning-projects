
# -*- coding: utf-8 -*-
import re, json, os, ipaddress
from urllib.parse import urlparse

SHORTENERS = {"bit.ly","tinyurl.com","t.co","goo.gl","is.gd","buff.ly","ow.ly","bitly.com","rebrand.ly","cutt.ly","rb.gy"}
UNUSUAL_TLDS = {"zip","mov","country","gq","tk"}

def _read_config_brands():
    here = os.path.dirname(__file__)
    path = os.path.join(here, "config", "brands.json")
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def _safe_parse(url):
    url = re.sub(r'^hxxp(s?)://', r'https\\1://', url, flags=re.I)
    return urlparse(url)

def _extract_urls(text):
    urls = set()
    for href, label in re.findall(r'<a\\b[^>]*href=["\\\']([^"\\\']+)["\\\'][^>]*>(.*?)</a>', text or "", flags=re.I|re.S):
        urls.add(("html", href.strip(), re.sub(r"<.*?>", "", label).strip()))
    for m in re.finditer(r'\\b(?:https?://|hxxps?://|www\\.)[^\\s<>()"]+', text or "", flags=re.I):
        u = m.group(0)
        if not u.lower().startswith(("http://","https://","hxxp://","hxxps://")):
            u = "http://" + u
        urls.add(("text", u.strip(), ""))
    return list(urls)

def _hostname(netloc):
    return netloc.split("@")[-1].split(":")[0].lower()

def _sld(host):
    parts = host.split(".")
    return parts[-2] if len(parts)>=2 else host

def _lev(a, b):
    m, n = len(a), len(b)
    dp = [[0]*(n+1) for _ in range(m+1)]
    for i in range(m+1): dp[i][0] = i
    for j in range(n+1): dp[0][j] = j
    for i in range(1,m+1):
        for j in range(1,n+1):
            c = 0 if a[i-1]==b[j-1] else 1
            dp[i][j] = min(dp[i-1][j]+1, dp[i][j-1]+1, dp[i-1][j-1]+c)
    return dp[m][n]

def analyze_links(text_html):
    indicators, warnings, score, tags = [], [], 0, set(["Delivery","Lure"])
    brands = _read_config_brands()

    for kind, url, label in _extract_urls(text_html or ""):
        p = _safe_parse(url); host = _hostname(p.netloc)
        if not host: continue
        indicators.append(("URL", {"url": url, "label": label}))

        if "xn--" in host or any(ord(ch)>127 for ch in host):
            warnings.append(f"Hostname chứa IDN/Punycode/Unicode: {host}"); score += 2
        if host in SHORTENERS:
            warnings.append(f"URL sử dụng shortener: {host}"); score += 1
        try:
            ipaddress.ip_address(host); warnings.append(f"URL dùng địa chỉ IP: {host}"); score += 1
        except ValueError:
            pass

        tld = host.split(".")[-1] if "." in host else ""
        if tld in UNUSUAL_TLDS:
            warnings.append(f"TLD bất thường: .{tld}"); score += 1

        if label:
            m = re.search(r'([a-z0-9\\-]+\\.[a-z\\.]{2,})', label, flags=re.I)
            label_dom = m.group(1).lower() if m else None
            if label_dom and (label_dom not in host and host not in (label_dom or "")):
                warnings.append(f"Anchor text '{label}' không khớp domain link {host}"); score += 2

        sld = _sld(host)
        best_brand, best_dist = None, 10**9
        for brand, domains in brands.items():
            for d in domains:
                dist = _lev(sld, _sld(d))
                if dist < best_dist:
                    best_brand, best_dist = brand, dist
        if best_dist in (1,2) and best_brand:
            warnings.append(f"Tên miền giống thương hiệu '{best_brand}' (Levenshtein={best_dist})"); score += 2

        if re.search(r"\\b(khẩn|xác minh ngay|48 giờ|24 giờ|trúng thưởng|bị khóa)\\b", (text_html or "").lower()):
            warnings.append("Ngôn ngữ thúc giục/đe dọa trong nội dung"); score += 1

    return {"indicators":indicators, "warnings":warnings, "score":score, "tags":sorted(list(tags))}
