# -*- coding: utf-8 -*-
from email import policy
from email.parser import BytesParser
from email.message import EmailMessage
from pathlib import Path
import re

from header_check import analyze_headers
from link_inspector import analyze_links
from attachment_policy import analyze_attachments

def _risk_level(score:int):
    if score >= 5: return "HIGH"
    if score >= 3: return "MEDIUM"
    return "LOW"

def _get_body(msg: EmailMessage) -> str:
    part = msg.get_body(preferencelist=('html','plain'))
    if not part:
        try:
            return msg.get_content()
        except Exception:
            return ""
    text = part.get_content()
    # Make a light text version for GUI: strip basic tags
    text_no_tags = re.sub(r"<\s*br\s*/?>", "\n", text, flags=re.I)
    text_no_tags = re.sub(r"<.*?>", "", text_no_tags, flags=re.S)
    return text_no_tags.strip()

def analyze_eml(path: str) -> dict:
    p = Path(path)
    msg = BytesParser(policy=policy.default).parsebytes(p.read_bytes())

    H = analyze_headers(msg)
    body_raw = _get_body(msg)
    L = analyze_links((msg.get_body(preferencelist=('html','plain')) or msg).get_content() or "")
    A = analyze_attachments(msg)

    score = H["score"] + L["score"] + A["score"]
    level = _risk_level(score)

    urls = []
    for k, v in L.get("indicators", []):
        if k == "URL":
            u = v.get("url") if isinstance(v, dict) else str(v)
            if u: urls.append(u)

    attachments = []
    for k, v in A.get("indicators", []):
        if k == "Attachment":
            name = v.get("filename") if isinstance(v, dict) else str(v)
            if name: attachments.append(name)

    headers = {}
    for hk in ("From","Reply-To","Return-Path","Subject","Date"):
        val = msg.get(hk, "")
        if val: headers[hk] = val
    for k, v in H.get("indicators", []):
        if k == "Auth-Results" and isinstance(v, dict):
            headers["Auth"] = f"spf={v.get('spf','unknown')}, dkim={v.get('dkim','unknown')}, dmarc={v.get('dmarc','unknown')}"

    indicators = []
    for hk in ("From","Reply-To","Return-Path"):
        if hk in headers: indicators.append((hk, headers[hk]))
    if "Auth" in headers: indicators.append(("Auth", headers["Auth"]))
    for u in urls: indicators.append(("URL", u))
    for a in attachments: indicators.append(("Attachment", a))

    warnings = list(H.get("warnings", [])) + list(L.get("warnings", [])) + list(A.get("warnings", []))

    return {
        "file": p.name,
        "level": level,
        "score": score,
        "urls": urls,
        "attachments": attachments,
        "indicators": indicators,
        "warnings": warnings,
        "headers": headers,
        "body": body_raw[:8000],  # cap for GUI
    }
