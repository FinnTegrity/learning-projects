# -*- coding: utf-8 -*-
import os, sys, csv, webbrowser
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

# Add project dir to sys.path (when user double-clicks GUI file)
BASE = Path(__file__).resolve().parent
if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))

from inspector_core import analyze_eml

SAMPLES_DIR = BASE / "samples"

class InspectorGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Mini Phishing Inspector — GUI")
        self.geometry("1100x680")
        self.reports = {}   # cache: path -> report
        self._build_menu()
        self._build_layout()
        self._load_samples_on_start()

    # ---- UI building ----
    def _build_menu(self):
        menubar = tk.Menu(self)
        m_file = tk.Menu(menubar, tearoff=0)
        m_file.add_command(label="Open .eml files…", command=self.open_files)
        m_file.add_command(label="Open folder…", command=self.open_folder)
        m_file.add_separator()
        m_file.add_command(label="Export CSV…", command=self.export_csv)
        m_file.add_separator()
        m_file.add_command(label="Exit", command=self.destroy)
        menubar.add_cascade(label="File", menu=m_file)

        m_run = tk.Menu(menubar, tearoff=0)
        m_run.add_command(label="Scan selected", command=self.scan_selected)
        m_run.add_command(label="Scan all", command=self.scan_all)
        m_run.add_separator()
        m_run.add_command(label="Clear results", command=self.clear_all)
        menubar.add_cascade(label="Run", menu=m_run)

        self.config(menu=menubar)

    def _build_layout(self):
        root = ttk.Frame(self, padding=8)
        root.pack(fill="both", expand=True)

        # Left: file list
        left = ttk.Frame(root)
        left.pack(side="left", fill="y")

        ttk.Label(left, text="Danh sách EML").pack(anchor="w")
        self.tree = ttk.Treeview(left, columns=("risk","score","path"), show="headings", height=26)
        self.tree.heading("risk", text="RISK")
        self.tree.heading("score", text="SCORE")
        self.tree.heading("path", text="PATH")
        self.tree.column("risk", width=80, anchor="center")
        self.tree.column("score", width=60, anchor="center")
        self.tree.column("path", width=360, anchor="w")
        self.tree.pack(fill="y", expand=False)
        self.tree.bind("<<TreeviewSelect>>", self.on_select)

        # Right: Notebook tabs
        right = ttk.Frame(root)
        right.pack(side="left", fill="both", expand=True, padx=(10,0))

        self.nb = ttk.Notebook(right)
        self.tab_summary = ttk.Frame(self.nb)
        self.tab_indic = ttk.Frame(self.nb)
        self.tab_warns = ttk.Frame(self.nb)
        self.tab_hdrs = ttk.Frame(self.nb)
        self.tab_body = ttk.Frame(self.nb)

        self.nb.add(self.tab_summary, text="Summary")
        self.nb.add(self.tab_indic, text="Indicators")
        self.nb.add(self.tab_warns, text="Warnings")
        self.nb.add(self.tab_hdrs, text="Headers")
        self.nb.add(self.tab_body, text="Body / URLs")
        self.nb.pack(fill="both", expand=True)

        # Summary widgets
        self.summary_txt = tk.Text(self.tab_summary, wrap="word", height=20)
        self.summary_txt.pack(fill="both", expand=True)

        # Indicators
        self.indic_txt = tk.Text(self.tab_indic, wrap="word")
        self.indic_txt.pack(fill="both", expand=True)

        # Warnings
        self.warns_list = tk.Listbox(self.tab_warns)
        self.warns_list.pack(fill="both", expand=True)

        # Headers
        self.headers_txt = tk.Text(self.tab_hdrs, wrap="word")
        self.headers_txt.pack(fill="both", expand=True)

        # Body/URLs
        body_top = ttk.Frame(self.tab_body)
        body_top.pack(fill="x")
        ttk.Button(body_top, text="Mở URL đã chọn", command=self._open_selected_url).pack(side="right")
        ttk.Label(body_top, text="URLs:").pack(side="left")

        self.urls_list = tk.Listbox(self.tab_body, height=6)
        self.urls_list.pack(fill="x")
        self.body_txt = tk.Text(self.tab_body, wrap="word", height=16)
        self.body_txt.pack(fill="both", expand=True)

    # ---- Helpers ----
    def _insert_or_update_row(self, path: Path, rep=None):
        iid = str(path)
        if rep is not None:
            self.reports[iid] = rep
        # set default display values
        risk = rep["level"] if rep else ""
        score = rep["score"] if rep else ""
        if self.tree.exists(iid):
            self.tree.item(iid, values=(risk, score, iid))
        else:
            self.tree.insert("", "end", iid=iid, values=(risk, score, iid))

    def _color_row(self, iid: str):
        # Coloring via tags
        self.tree.tag_configure("HIGH", background="#FFEEEE")
        self.tree.tag_configure("MEDIUM", background="#FFF7E6")
        self.tree.tag_configure("LOW", background="#EEFFEE")
        vals = self.tree.item(iid, "values")
        level = vals[0] if vals else ""
        self.tree.item(iid, tags=(level,))

    def _load_samples_on_start(self):
        if SAMPLES_DIR.exists():
            for p in sorted(SAMPLES_DIR.glob("*.eml")):
                self._insert_or_update_row(p)

    def _get_selected_paths(self):
        sels = self.tree.selection()
        return [Path(self.tree.item(i, "values")[2]) for i in sels]

    def _render_report(self, rep: dict):
        # Summary
        s = []
        s.append(f"File: {rep['file']}")
        s.append(f"Risk: {rep['level']} (score={rep['score']})")
        s.append(f"URLs: {len(rep['urls'])} | Attachments: {len(rep['attachments'])}")
        s.append(f"Warnings: {len(rep['warnings'])}")
        self.summary_txt.delete("1.0","end")
        self.summary_txt.insert("1.0", "\n".join(s))

        # Indicators
        self.indic_txt.delete("1.0","end")
        for k, v in rep["indicators"]:
            self.indic_txt.insert("end", f"- {k}: {v}\n")

        # Warnings
        self.warns_list.delete(0, "end")
        for w in rep["warnings"]:
            self.warns_list.insert("end", f"• {w}")

        # Headers
        self.headers_txt.delete("1.0","end")
        for k in ["From","Reply-To","Return-Path","Subject","Date","Auth"]:
            if k in rep["headers"]:
                self.headers_txt.insert("end", f"{k}: {rep['headers'][k]}\n")

        # URLs + Body
        self.urls_list.delete(0,"end")
        for u in rep["urls"]:
            self.urls_list.insert("end", u)
        self.body_txt.delete("1.0","end")
        self.body_txt.insert("1.0", rep.get("body",""))

        # Switch to Summary
        self.nb.select(self.tab_summary)

    # ---- Menu commands ----
    def open_files(self):
        paths = filedialog.askopenfilenames(title="Chọn .eml", filetypes=[("Email files","*.eml")])
        for p in paths:
            self._insert_or_update_row(Path(p))

    def open_folder(self):
        d = filedialog.askdirectory(title="Chọn thư mục chứa .eml")
        if not d: return
        for p in sorted(Path(d).glob("*.eml")):
            self._insert_or_update_row(p)

    def export_csv(self):
        if not self.reports:
            messagebox.showinfo("Info","Chưa có report. Hãy Scan trước.")
            return
        save = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV","*.csv")])
        if not save: return
        with open(save, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["file","risk","score","urls_count","attachments_count","warnings_count"])
            for path, rep in self.reports.items():
                w.writerow([rep["file"], rep["level"], rep["score"], len(rep["urls"]), len(rep["attachments"]), len(rep["warnings"])])
        messagebox.showinfo("Export CSV", f"Đã lưu: {save}")

    def scan_selected(self):
        paths = self._get_selected_paths()
        if not paths:
            messagebox.showinfo("Info","Hãy chọn ít nhất một file trong danh sách.")
            return
        for p in paths:
            try:
                rep = analyze_eml(str(p))
                self._insert_or_update_row(p, rep)
                self._color_row(str(p))
            except Exception as e:
                messagebox.showerror("Lỗi phân tích", f"{p.name}: {e}")
        if paths:
            self.on_select(None)

    def scan_all(self):
        all_iids = self.tree.get_children()
        for iid in all_iids:
            p = Path(self.tree.item(iid, "values")[2])
            try:
                rep = analyze_eml(str(p))
                self._insert_or_update_row(p, rep)
                self._color_row(iid)
            except Exception as e:
                messagebox.showerror("Lỗi phân tích", f"{p.name}: {e}")
        if all_iids:
            self.tree.selection_set(all_iids[0])
            self.on_select(None)

    def clear_all(self):
        self.reports.clear()
        for iid in self.tree.get_children():
            self.tree.item(iid, values=("", "", self.tree.item(iid, "values")[2]))
            self.tree.item(iid, tags=())

    def _open_selected_url(self):
        sel = self.urls_list.curselection()
        if not sel: return
        url = self.urls_list.get(sel[0])
        try:
            webbrowser.open(url)
        except Exception:
            messagebox.showerror("Lỗi", f"Không mở được URL: {url}")

    # ---- Events ----
    def on_select(self, event):
        sels = self.tree.selection()
        if not sels: return
        iid = sels[0]
        path = Path(self.tree.item(iid, "values")[2])
        rep = self.reports.get(str(path))
        if not rep:
            try:
                rep = analyze_eml(str(path))
                self._insert_or_update_row(path, rep)
                self._color_row(iid)
            except Exception as e:
                messagebox.showerror("Lỗi phân tích", f"{path.name}: {e}")
                return
        self._render_report(rep)

if __name__ == "__main__":
    InspectorGUI().mainloop()
