
from typing import Dict, Any, List
import os
from utils import ext_risk

def analyze_attachments(msg) -> Dict[str, Any]:
    indicators: List[str] = []
    warnings: List[str] = []
    score = 0
    tags = set()

    for part in msg.iter_attachments():
        fname = part.get_filename() or "(không tên)"
        ctype = part.get_content_type()
        indicators.append(f'Attachment: {fname} ({ctype})')
        ext = os.path.splitext(fname)[1].lower().strip('.')
        r = ext_risk(ext)
        if r == 2:
            warnings.append(f'Phát hiện đuôi rủi ro cao: .{ext} (khả năng thực thi/macro)')
            score += 2
            tags.add('Execution')
        elif r == 1:
            warnings.append(f'Đuôi rủi ro trung bình: .{ext} (cần kiểm tra thêm)')
            score += 1
            tags.add('Execution')

    return {
        "indicators": indicators,
        "warnings": warnings,
        "score": score,
        "tags": sorted(tags),
    }
