
import re, html
from typing import Dict, Any, List, Tuple
from utils import hostname_from_url, is_punycode, has_unicode_lookalike, looks_like_brand, is_shortener, is_ip_host

A_TAG_RE = re.compile(r'<a\s+[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', re.I|re.S)
URL_RE = re.compile(r'(?:(?:https?|hxxps?)://[^\s"\'<>]+)', re.I)

def extract_links(payload: str) -> List[Tuple[str,str]]:
    links = []
    for href, text in A_TAG_RE.findall(payload or ""):
        links.append((html.unescape(text.strip()), href.strip()))
    # Also add bare URLs (no text)
    for url in URL_RE.findall(payload or ""):
        links.append(("", url.strip()))
    return links

def analyze_links(payload: str, claimed_domain: str = "") -> Dict[str, Any]:
    indicators: List[str] = []
    warnings: List[str] = []
    score = 0
    tags = set()
    links = extract_links(payload or "")

    claimed_domain = (claimed_domain or "").lower()

    for i,(text, href) in enumerate(links, 1):
        host = hostname_from_url(href)
        if not host: 
            continue
        indicators.append(f'Link#{i}: text="{text}" href="{href}"')

        # text vs href mismatch (only if text looks like a domain/brand)
        if text:
            m = re.search(r'([a-z0-9][a-z0-9\-\.]+\.[a-z]{2,})', text, re.I)
            if m:
                t_host = m.group(1).lower()
                if t_host not in host:
                    warnings.append(f'Text≠Href: text chứa "{t_host}" nhưng href trỏ đến "{host}"')
                    score += 2
                    tags.update(['Delivery','Lure'])

        # If mail claims a brand domain, but link host doesn't contain it → warn
        if claimed_domain and claimed_domain not in host:
            warnings.append(f'Host liên kết ({host}) KHÔNG thuộc miền người gửi ({claimed_domain})')
            score += 2
            tags.update(['Delivery','Lure'])

        # punycode/unicode
        if is_punycode(host) or has_unicode_lookalike(host):
            warnings.append(f'Host có dấu hiệu IDN/Punycode/Unicode: {host}')
            score += 2
            tags.update(['Delivery','Lure'])

        # brand lookalike (rough)
        if looks_like_brand(host):
            warnings.append(f'Tên miền có nét giống thương hiệu phổ biến: {host}')
            score += 2
            tags.update(['Delivery','Lure'])

        # shortener / IP-host
        if is_shortener(host):
            warnings.append(f'Link dùng shortener: {host}')
            score += 1
            tags.update(['Delivery','Lure'])
        if is_ip_host(host):
            warnings.append(f'Link trỏ IP trực tiếp: {host}')
            score += 1
            tags.update(['Delivery','Lure'])

        # Suspicious path keywords
        if re.search(r'/login|/verify|/update|/reset', href, re.I):
            warnings.append('Đường dẫn chứa từ khoá nhạy cảm (login/verify/update/reset)')
            score += 1
            tags.update(['Lure'])

    return {
        "indicators": indicators,
        "warnings": warnings,
        "score": score,
        "tags": sorted(tags),
        "total_links": len(links)
    }
