
from typing import Dict, Any, List

LEVELS = [(5, "HIGH"), (3, "MEDIUM"), (0, "LOW")]

def combine(*parts: Dict[str, Any]) -> Dict[str, Any]:
    indicators: List[str] = []
    warnings: List[str] = []
    score = 0
    tags = set()
    for p in parts:
        indicators.extend(p.get("indicators", []))
        warnings.extend(p.get("warnings", []))
        score += p.get("score", 0)
        tags.update(p.get("tags", []))

    for th, name in LEVELS:
        if score >= th:
            level = name
            break

    return {
        "indicators": indicators,
        "warnings": warnings,
        "score": score,
        "level": level,
        "tags": sorted(tags),
    }
