
import sys, json, re
from email import policy
from email.parser import BytesParser
from header_check import analyze_headers
from link_inspector import analyze_links
from attachment_policy import analyze_attachments
from scorer import combine

def read_msg(path: str):
    with open(path, 'rb') as f:
        return BytesParser(policy=policy.default).parse(f)

def read_body(msg):
    if msg.is_multipart():
        for part in msg.walk():
            ctype = part.get_content_type()
            if ctype in ('text/html','text/plain'):
                try:
                    return part.get_content()
                except: 
                    pass
        return ""
    else:
        try:
            return msg.get_content()
        except:
            return ""

def claimed_domain_from_from_header(from_h: str) -> str:
    if not from_h: return ""
    m = re.search(r'@([a-z0-9\.\-]+\.[a-z]{2,})', from_h, re.I)
    return m.group(1).lower() if m else ""

def report(path: str, as_json=False):
    msg = read_msg(path)
    body = read_body(msg)
    from_h = msg.get('From') or ""
    claimed_domain = claimed_domain_from_from_header(from_h)

    h = analyze_headers(msg)
    l = analyze_links(body, claimed_domain=claimed_domain)
    a = analyze_attachments(msg)
    allr = combine(h,l,a)

    if as_json:
        print(json.dumps({"file": path, "header": h, "links": l, "attach": a, "final": allr}, ensure_ascii=False, indent=2))
    else:
        print(f"=== PHISHING INSPECTOR REPORT: {path} ===")
        print("[Indicators]")
        for x in h["indicators"] + l["indicators"] + a["indicators"]:
            print(" -", x)
        print("[Warnings]")
        for w in h["warnings"] + l["warnings"] + a["warnings"]:
            print(" -", w)
        print(f"[Score] {allr['score']}  [Level] {allr['level']}  [Tags] {', '.join(allr['tags'])}")
        print()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python cli.py <eml-file> [--json]")
        sys.exit(1)
    as_json = '--json' in sys.argv
    for p in sys.argv[1:]:
        if p == '--json': continue
        report(p, as_json=as_json)
