
from email import policy
from email.parser import BytesParser
import re
from typing import Dict, Any, List
from utils import extract_domain

def analyze_headers(msg) -> Dict[str, Any]:
    indicators: List[str] = []
    warnings: List[str] = []
    score = 0
    tags = set()

    def get(h):
        v = msg.get(h)
        return v if v else ""

    from_h = get('From')
    reply_to = get('Reply-To')
    return_path = msg.get('Return-Path') or msg.get('Sender') or ""
    authres = get('Authentication-Results') or get('Received-SPF') or ""

    indicators.append(f'From: {from_h}')
    if reply_to: indicators.append(f'Reply-To: {reply_to}')
    if return_path: indicators.append(f'Return-Path/Sender: {return_path}')
    if authres: indicators.append(f'AuthRes: {authres}')

    # Domain comparisons
    d_from = extract_domain(from_h)
    d_reply = extract_domain(reply_to)
    d_rp = extract_domain(return_path)

    if d_reply and d_from and d_reply.split('@')[-1] != d_from.split('@')[-1]:
        warnings.append(f'Reply-To khác miền với From ({d_reply} ≠ {d_from})')
        score += 1
        tags.add('Delivery')

    if d_rp and d_from and d_rp.split('@')[-1] != d_from.split('@')[-1]:
        warnings.append(f'Return-Path/Sender khác miền với From ({d_rp} ≠ {d_from})')
        score += 1
        tags.add('Delivery')

    # SPF/DKIM/DMARC parsing (rough)
    ar = authres.lower()
    if ar:
        spf = re.search(r'spf\s*=\s*(pass|fail|softfail|none|neutral)', ar)
        dkim = re.search(r'dkim\s*=\s*(pass|fail|none|neutral)', ar)
        dmarc = re.search(r'dmarc\s*=\s*(pass|fail|none|quarantine|reject|neutral)', ar)
        def bump(what, m):
            nonlocal score
            if m and m.group(1) in ('fail','softfail','none','neutral'):
                warnings.append(f'{what.upper()} không đạt/không có ({m.group(1)})')
                score += 2
                tags.add('Delivery')
        bump('spf', spf)
        bump('dkim', dkim)
        if dmarc and dmarc.group(1) in ('reject','quarantine'):
            warnings.append(f'DMARC policy gợi ý {dmarc.group(1)} (theo header)')
            score += 1
            tags.add('Delivery')
        elif dmarc and dmarc.group(1) in ('none','neutral'):
            warnings.append('DMARC none/neutral (không cưỡng chế)')
            score += 1
            tags.add('Delivery')
    else:
        warnings.append('Không có Authentication-Results/Received-SPF trong header')
        score += 1
        tags.add('Delivery')

    return {
        "indicators": indicators,
        "warnings": warnings,
        "score": score,
        "tags": sorted(tags),
    }
