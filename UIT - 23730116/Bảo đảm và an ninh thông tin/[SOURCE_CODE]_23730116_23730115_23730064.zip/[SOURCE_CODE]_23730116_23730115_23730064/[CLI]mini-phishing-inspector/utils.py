
import re
import idna

SHORTENERS = {
    "bit.ly","t.co","goo.gl","tinyurl.com","ow.ly","is.gd","buff.ly","cutt.ly","t.ly","rebrand.ly",
    "rb.gy","s.id","shorturl.at"
}

BRANDS = {
    "google.com","paypal.com","microsoft.com","apple.com","amazon.com","vietcombank.com.vn","facebook.com","github.com"
}

def extract_domain(addr: str) -> str:
    """Extract the domain part from an email address or URL-ish string."""
    if not addr:
        return ""
    # from email style: "Name <user@domain>"
    m = re.search(r'@([^>]+)>?$', addr)
    if m:
        return m.group(1).strip().lower()
    # or maybe it's just a domain
    addr = addr.strip().lower()
    # remove angle brackets
    addr = addr.strip('<>')
    return addr

def normalize_hostname(host: str) -> str:
    if not host:
        return ""
    host = host.strip().lower()
    # strip brackets and scheme
    host = re.sub(r'^\[?https?://', '', host)
    host = host.strip('[]/')
    # remove port
    host = host.split(':')[0]
    return host

def hostname_from_url(url: str) -> str:
    if not url:
        return ""
    m = re.match(r'^\s*(?:https?|hxxps?)://([^/]+)', url.strip(), re.I)
    if m:
        return normalize_hostname(m.group(1))
    # raw host or IP
    return normalize_hostname(url)

def is_punycode(host: str) -> bool:
    return host.startswith('xn--') or any(part.startswith('xn--') for part in host.split('.'))

def has_unicode_lookalike(host: str) -> bool:
    # If it contains non-ascii letters, flag; deeper homograph detection is complex
    try:
        host.encode('ascii')
        return False
    except UnicodeEncodeError:
        return True

def levenshtein(a: str, b: str) -> int:
    a, b = a.lower(), b.lower()
    dp = list(range(len(b)+1))
    for i, ca in enumerate(a, 1):
        prev = dp[0]
        dp[0] = i
        for j, cb in enumerate(b, 1):
            cur = dp[j]
            cost = 0 if ca == cb else 1
            dp[j] = min(dp[j]+1, dp[j-1]+1, prev+cost)
            prev = cur
    return dp[-1]

def looks_like_brand(host: str) -> bool:
    # Compare SLD of host to SLD of known brands
    host = normalize_hostname(host)
    sld = host.split('.')[-3] if host.count('.')>=2 else host.split('.')[0]
    for brand in BRANDS:
        b_sld = brand.split('.')[-3] if brand.count('.')>=2 else brand.split('.')[0]
        dist = levenshtein(sld, b_sld)
        if dist <= 2 and sld != b_sld:
            return True
    return False

def is_shortener(host: str) -> bool:
    host = normalize_hostname(host)
    return host in SHORTENERS

def is_ip_host(host: str) -> bool:
    return bool(re.match(r'^\d{1,3}(?:\.\d{1,3}){3}$', host))

def ext_risk(ext: str) -> int:
    ext = ext.lower().strip('.')
    high = {'exe','js','vbs','scr','bat','cmd','ps1','apk','jar','dll','msi','docm','xlsm','iso'}
    med  = {'zip','rar','pdf'}
    if ext in high: return 2
    if ext in med: return 1
    return 0
