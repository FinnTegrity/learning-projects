# Hướng Dẫn Khởi Chạy Dự Án GIS Weather

Tài liệu này hướng dẫn cách cài đặt và chạy hệ thống GIS Weather (bao gồm Frontend, Backend và Database PostgreSQL/PostGIS) lần đầu tiên.

---

## 📋 Yêu cầu hệ thống
Trước khi bắt đầu, hãy chắc chắn máy tính của bạn đã cài đặt các công cụ sau:
*   [Node.js](https://nodejs.org/) (Khuyến nghị bản LTS mới nhất)
*   [Docker Desktop](https://www.docker.com/products/docker-desktop/) (Để chạy Database PostgreSQL/PostGIS)

---

## 🚀 Các bước khởi chạy dự án

### Bước 1: Khởi động Database bằng Docker
Mở terminal tại thư mục gốc của dự án và khởi động container cơ sở dữ liệu:
```bash
docker compose up -d
```
*Lưu ý: Docker sẽ tải và khởi động một cơ sở dữ liệu PostgreSQL tích hợp sẵn PostGIS tại cổng `5432`.*

### Bước 2: Cấu hình và chạy Backend
1. Di chuyển vào thư mục backend:
   ```bash
   cd backend
   ```
2. Tạo file `.env` tại thư mục `backend/` với nội dung cấu hình kết nối database (đã được tạo sẵn mặc định):
   ```env
   PORT=5000
   DB_HOST=localhost
   DB_PORT=5432
   DB_NAME=weather_gis_db
   DB_USER=gis_user
   DB_PASSWORD=gis_password_2026
   JWT_SECRET=doan_gis_secret_2026
   VISUAL_CROSSING_KEY=9EB9KS2T8YDNR7XRSZXB8LUDU
   ```
3. Cài đặt các thư viện phụ thuộc:
   ```bash
   npm install
   ```
4. Khởi động server backend dưới dạng development:
   ```bash
   npm run dev
   ```
   Server Backend sẽ hoạt động tại địa chỉ: `http://localhost:5000`

### Bước 3: Cài đặt và chạy Frontend
1. Mở một terminal mới và di chuyển vào thư mục frontend:
   ```bash
   cd frontend
   ```
2. Cài đặt các thư viện phụ thuộc:
   ```bash
   npm install
   ```
3. Khởi động ứng dụng frontend:
   ```bash
   npm run dev
   ```
   Ứng dụng Frontend sẽ hoạt động tại địa chỉ: `http://localhost:5173`

### Bước 4: Đồng bộ dữ liệu thời tiết (Weather Sync)
Sau khi Backend đã hoạt động, bạn cần gọi API để thực hiện đồng bộ dữ liệu thời tiết từ OpenMeteo về Database.

Mở một terminal mới (hoặc sử dụng các công cụ Client API như Postman) và thực hiện gửi yêu cầu POST:

*   **Nếu sử dụng Git Bash / Linux / macOS:**
    ```bash
    curl -X POST http://localhost:5000/api/weather/sync
    ```
*   **Nếu sử dụng PowerShell (Windows):**
    ```powershell
    curl.exe -X POST http://localhost:5000/api/weather/sync
    # Hoặc:
    Invoke-RestMethod -Method Post -Uri http://localhost:5000/api/weather/sync
    ```

Khi thành công, hệ thống sẽ trả về phản hồi: `{"message": "Đồng bộ thành công!"}`.

---

## 🔑 Tài khoản đăng nhập hệ thống

Hệ thống hỗ trợ phân quyền rõ ràng với các tài khoản mẫu sau (mật khẩu chung: `123456`):

1. **Quản trị cấp cao (Super Admin):**
   * **Username:** `superadmin` | **Role:** `admin`
2. **Quản trị viên (Admin):**
   * **Username:** `admin` | **Role:** `admin`
3. **Nhà phân tích (Analyst):**
   * **Username:** `analyst` | **Role:** `analyst`
4. **Nhà phân tích nghiệp vụ (Phân tích):**
   * **Username:** `phantich` | **Role:** `analyst`
5. **Người dùng thông thường (User):**
   * **Username:** `user` | **Role:** `user`

---

## ⚡ Các tính năng nổi bật & Tối ưu kỹ thuật

1. **Tối ưu hóa thuật toán nội suy IDW**:
   * Áp dụng tính toán tối ưu song song và sử dụng Sequelize `bulkCreate` thay vì ghi từng bản ghi riêng lẻ.
   * Giảm thời gian xử lý lưới không gian **1.635 ô lưới** tại TP.HCM từ **>8.5 giây xuống dưới 100ms** (gấp ~85 lần).
   * Cơ chế tự động tính toán lại lưới nội suy ngay khi thay đổi thời điểm trên trục thời gian tại tab Lưới nội suy.

2. **Cơ sở dữ liệu không gian PostGIS**:
   * Tự động xác định tâm hành chính của **168 xã/phường** thuộc TP.HCM để làm vị trí cắm trạm quan trắc thời tiết.
   * Tạo lưới không gian tự động thông qua PostGIS bounding box bao phủ toàn bộ phạm vi địa giới TP.HCM.

3. **Ghi nhật ký thay đổi dữ liệu (Audit Logging)**:
   * Mọi hành động chỉnh sửa, thêm mới thông tin thời tiết hay trạm đo của quản trị viên đều được hệ thống tự động ghi lại tại bảng `DataChangeLogs` để phục vụ giám sát.

