const bcrypt = require('bcryptjs');
const db = require('./src/models/index');
const { sequelize } = db;

async function run() {
  try {
    await sequelize.authenticate();
    console.log('Database connected.');

    // 1. Remove user1 account
    await sequelize.query('DELETE FROM "USERS" WHERE ten_dang_nhap = \'user1\'');
    console.log('Removed user1 account.');

    const salt = await bcrypt.genSalt(10);
    const hashPassword = await bcrypt.hash('123456', salt);

    // 2. Add superadmin if not exists
    const [superadminCheck] = await sequelize.query('SELECT COUNT(*) AS count FROM "USERS" WHERE ten_dang_nhap = \'superadmin\'');
    if (parseInt(superadminCheck[0].count, 10) === 0) {
      await sequelize.query(`
        INSERT INTO "USERS" (ten_dang_nhap, mat_khau_hash, vai_tro, "createdAt", "updatedAt") VALUES 
        ('superadmin', :hashPassword, 'admin', NOW(), NOW())
      `, { replacements: { hashPassword } });
      console.log('Added superadmin account.');
    }

    // 3. Add phantich if not exists
    const [phantichCheck] = await sequelize.query('SELECT COUNT(*) AS count FROM "USERS" WHERE ten_dang_nhap = \'phantich\'');
    if (parseInt(phantichCheck[0].count, 10) === 0) {
      await sequelize.query(`
        INSERT INTO "USERS" (ten_dang_nhap, mat_khau_hash, vai_tro, "createdAt", "updatedAt") VALUES 
        ('phantich', :hashPassword, 'analyst', NOW(), NOW())
      `, { replacements: { hashPassword } });
      console.log('Added phantich account.');
    }

    // 4. Add user if not exists
    const [userCheck] = await sequelize.query('SELECT COUNT(*) AS count FROM "USERS" WHERE ten_dang_nhap = \'user\'');
    if (parseInt(userCheck[0].count, 10) === 0) {
      await sequelize.query(`
        INSERT INTO "USERS" (ten_dang_nhap, mat_khau_hash, vai_tro, "createdAt", "updatedAt") VALUES 
        ('user', :hashPassword, 'user', NOW(), NOW())
      `, { replacements: { hashPassword } });
      console.log('Added user account.');
    }

    process.exit(0);
  } catch (error) {
    console.error('Error:', error);
    process.exit(1);
  }
}

run();
