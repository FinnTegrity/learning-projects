const sequelize = require('./src/config/db');

async function testSeeder() {
  try {
    await sequelize.authenticate();
    console.log('Database connected.');

    const [bboxQuery] = await sequelize.query(`
      SELECT 
        MIN(ST_XMin(geom)) as min_lng, 
        MAX(ST_XMax(geom)) as max_lng, 
        MIN(ST_YMin(geom)) as min_lat, 
        MAX(ST_YMax(geom)) as max_lat 
      FROM "ADMIN_BOUNDARIES"
    `);
    const { min_lng, max_lng, min_lat, max_lat } = bboxQuery[0];

    const step = 0.02;
    let count = 0;

    const startTime = Date.now();
    for (let lng = min_lng; lng < max_lng; lng += step) {
      for (let lat = min_lat; lat < max_lat; lat += step) {
        const matchingBoundary = await sequelize.query(`
          SELECT id_ranhgioi 
          FROM "ADMIN_BOUNDARIES" 
          WHERE ST_Intersects(geom, ST_MakeEnvelope(:lng1, :lat1, :lng2, :lat2, 4326))
          LIMIT 1;
        `, {
          replacements: { 
            lng1: lng, 
            lat1: lat, 
            lng2: lng + step, 
            lat2: lat + step 
          },
          type: sequelize.QueryTypes.SELECT
        });

        if (matchingBoundary && matchingBoundary.length > 0) {
          count++;
        }
      }
    }

    console.log(`With step ${step}, we would create ${count} grid cells. Time taken: ${Date.now() - startTime}ms`);
    process.exit(0);
  } catch (error) {
    console.error('Error:', error);
    process.exit(1);
  }
}

testSeeder();
