const db = require('./src/models/index');
const { Location, HourlyWeather } = db;

async function test() {
  try {
    await db.sequelize.authenticate();
    const stations = await Location.findAll({
      where: { is_active: true },
      include: [{
        model: HourlyWeather,
        required: true,
        limit: 1
      }],
      limit: 1
    });

    if (stations.length > 0) {
      console.log('Keys of station object:', Object.keys(stations[0].toJSON()));
      console.log('Association data:', stations[0].toJSON());
    } else {
      console.log('No stations with hourly weather found.');
    }
    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

test();
