const db = require('./src/models/index');
const { GridCell, GridTimeValue, HourlyWeather, Location, User, AdminBoundary, sequelize } = db;

const seedBoundaries = require('./src/utils/boundarySeeder');
const seedLocations = require('./src/utils/seeder');
const seedUsers = require('./src/utils/userSeeder');
const seedGridCells = require('./src/utils/gridSeeder');
const { syncWeatherFromOpenMeteo } = require('./src/services/syncDataService');
const { runIDWInterpolation } = require('./src/services/interpolationService');

async function fullReset() {
  try {
    await sequelize.authenticate();
    console.log('Database connected.');

    // 1. Truncate tables with CASCADE
    console.log('Truncating weather and grid tables...');
    await sequelize.query('TRUNCATE TABLE "GRID_TIME_VALUES", "GRID_CELLS", "HOURLY_WEATHER", "LOCATIONS", "USERS", "DATA_CHANGE_LOG" RESTART IDENTITY CASCADE;');
    console.log('Truncated successfully.');

    // 2. Run boundary seeder (only if empty)
    const boundariesCount = await AdminBoundary.count();
    if (boundariesCount === 0) {
      console.log('Seeding administrative boundaries...');
      await seedBoundaries();
    } else {
      console.log(`📌 Found ${boundariesCount} administrative boundaries in database.`);
    }

    // 3. Seed locations (weather stations)
    console.log('Seeding weather stations (LOCATIONS)...');
    await seedLocations();

    // 4. Seed users
    console.log('Seeding users (USERS)...');
    await seedUsers();

    // 5. Seed grid cells
    console.log('Seeding high-resolution grid cells (GRID_CELLS)...');
    await seedGridCells();

    // 6. Sync weather data
    console.log('Syncing weather data from OpenMeteo / Offline backup...');
    await syncWeatherFromOpenMeteo();

    // 7. Find all distinct weather timestamps synced
    const timestamps = await HourlyWeather.findAll({
      attributes: [[sequelize.fn('DISTINCT', sequelize.col('thoi_gian')), 'thoi_gian']],
      raw: true
    });
    console.log(`Found ${timestamps.length} distinct timestamps to interpolate.`);

    // 8. Run IDW interpolation for each timestamp
    let done = 0;
    for (const t of timestamps) {
      console.log(`Running IDW interpolation for ${t.thoi_gian}...`);
      const result = await runIDWInterpolation(t.thoi_gian);
      if (result.success) {
        done++;
      } else {
        console.error(`IDW failed for ${t.thoi_gian}: ${result.message}`);
      }
    }
    console.log(`Successfully interpolated IDW for ${done}/${timestamps.length} timestamps.`);
    console.log('🎉 Full database seeding and initial IDW computation completed successfully!');
    process.exit(0);
  } catch (error) {
    console.error('Error resetting database:', error);
    process.exit(1);
  }
}

fullReset();
