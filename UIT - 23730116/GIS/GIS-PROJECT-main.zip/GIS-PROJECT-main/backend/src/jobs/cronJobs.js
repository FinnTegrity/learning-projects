const cron = require('node-cron');
const axios = require('axios');
const { aggregateDailyWeather } = require('../services/aggregationService');

const startCronJobs = () => {
  console.log('⏱️ Hệ thống Background Jobs đã được kích hoạt.');

  // JOB 1: TỰ ĐỘNG ĐỒNG BỘ MỖI GIỜ (Chạy vào phút thứ 0 của mỗi giờ)
  // Ví dụ: 1:00, 2:00, 3:00...
  cron.schedule('0 * * * *', async () => {
    console.log('⏰ [Cron Job] Đang chạy tự động đồng bộ API Open-Meteo...');
    try {
      // Gọi thẳng vào API đồng bộ (Local) của hệ thống
      await axios.post('http://localhost:5000/api/weather/sync');
      console.log('✅ [Cron Job] Tự động đồng bộ thành công!');
    } catch (error) {
      console.error('❌ [Cron Job] Lỗi đồng bộ tự động (Có thể do Rate Limit):', error.message);
    }
  });

  // JOB 2: TỔNG HỢP DỮ LIỆU NGÀY - UC04 (Chạy vào 23:59 mỗi ngày)
  cron.schedule('59 23 * * *', async () => {
    console.log('⏰ [Cron Job] Kích hoạt tiến trình tổng hợp số liệu ngày...');
    await aggregateDailyWeather();
  });
};

module.exports = startCronJobs;