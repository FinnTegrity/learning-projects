const express = require('express');
const cors = require('cors');
const db = require('./models/index');
require('dotenv').config();

const seedLocations = require('./utils/seeder');
const seedBoundaries = require('./utils/boundarySeeder'); 
const seedUsers = require('./utils/userSeeder');
const seedGridCells = require('./utils/gridSeeder');
const startCronJobs = require('./jobs/cronJobs');
const { syncWeatherFromOpenMeteo } = require('./services/syncDataService');

const apiRoutes = require('./routes/api');
const authRoutes = require('./routes/auth');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

app.use('/api', apiRoutes);
app.use('/api/auth', authRoutes);

const startServer = async () => {
  try {
    await db.sequelize.authenticate();
    console.log('✅ Kết nối thành công tới Database PostgreSQL/PostGIS trong Docker!');
    
    await db.sequelize.query('CREATE EXTENSION IF NOT EXISTS postgis;');
    await db.sequelize.sync({ alter: true });
    console.log('📊 Khởi tạo cấu trúc các bảng dữ liệu thành công!');
    
    await seedBoundaries();
    await seedLocations();
    await seedUsers();
    await seedGridCells();

    // Tự động chạy nội suy không gian ô lưới lần đầu
    try {
      const { runIDWInterpolation } = require('./services/interpolationService');
      const latestWeather = await db.HourlyWeather.findOne({ order: [['thoi_gian', 'DESC']] });
      if (latestWeather) {
        console.log('🔄 Đang tự động chạy nội suy không gian IDW cho ô lưới...');
        const result = await runIDWInterpolation(latestWeather.thoi_gian);
        console.log('✅ Kết quả nội suy ban đầu:', result.message);
      }
    } catch (interpErr) {
      console.error('❌ Lỗi chạy nội suy không gian ban đầu:', interpErr.message);
    }

    // Tự động đồng bộ thời tiết lần đầu nếu cơ sở dữ liệu trống hoặc thiếu dữ liệu lịch sử
    try {
      const weatherCount = await db.HourlyWeather.count();
      const locationsCount = await db.Location.count();
      const minRequired = locationsCount * 336; // Yêu cầu tối thiểu 14 ngày lịch sử cho mô hình phân tích
      
      if (weatherCount < minRequired) {
        console.log('🔄 Cơ sở dữ liệu thời tiết rỗng hoặc thiếu dữ liệu lịch sử. Tiến hành đồng bộ...');
        // Chạy bất đồng bộ để tránh chặn tiến trình khởi động server
        syncWeatherFromOpenMeteo()
          .then(() => console.log('✅ Đồng bộ dữ liệu ban đầu hoàn tất!'))
          .catch(err => console.error('❌ Lỗi khi đồng bộ dữ liệu ban đầu:', err.message));
      } else {
        console.log('📌 Đã có dữ liệu thời tiết cũ trong database. Bỏ qua bước đồng bộ lúc khởi động.');
      }
    } catch (dbError) {
      console.error('❌ Lỗi kiểm tra dữ liệu thời tiết lúc khởi động:', dbError.message);
    }

    startCronJobs();

    app.listen(PORT, () => {
      console.log(`🚀 Server Backend đang chạy tại: http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('❌ Thất bại! Không thể kết nối hoặc khởi tạo hệ thống:', error);
    process.exit(1);
  }
};

startServer();