const { Sequelize } = require('sequelize');
require('dotenv').config();

// Khởi tạo instance Sequelize từ các biến môi trường trong file .env
const sequelize = new Sequelize(
  process.env.DB_NAME,
  process.env.DB_USER,
  process.env.DB_PASSWORD,
  {
    host: process.env.DB_HOST,
    port: process.env.DB_PORT,
    dialect: 'postgres',
    logging: false, // Tắt log các câu lệnh SQL thô ra terminal cho đỡ rối mắt
    define: {
      timestamps: true, // Tự động thêm cột createdAt và updatedAt cho các bảng
      freezeTableName: true // Giữ nguyên tên bảng, không tự động chuyển sang số nhiều
    }
  }
);

module.exports = sequelize;