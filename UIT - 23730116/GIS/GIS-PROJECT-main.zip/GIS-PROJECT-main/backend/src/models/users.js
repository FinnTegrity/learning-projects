const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const User = sequelize.define('USERS', {
  id_nguoidung: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  ten_dang_nhap: { type: DataTypes.STRING(50), allowNull: false, unique: true },
  mat_khau_hash: { type: DataTypes.STRING(255), allowNull: false },
  vai_tro: { type: DataTypes.STRING(20), allowNull: false, defaultValue: 'user' }, // admin, analyst, user
  email: { type: DataTypes.STRING(100), allowNull: true },
  trang_thai: { type: DataTypes.BOOLEAN, defaultValue: true },
  ngay_tao: { type: DataTypes.DATE, defaultValue: DataTypes.NOW }
});

module.exports = User;