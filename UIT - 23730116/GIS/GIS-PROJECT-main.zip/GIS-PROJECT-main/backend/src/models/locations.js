const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const Location = sequelize.define('LOCATIONS', {
  id_diadiem: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  ten_khuvuc: {
    type: DataTypes.STRING(150), // Đã sửa: Dùng STRING thay vì VARCHAR
    allowNull: false,
  },
  vi_do: {
    type: DataTypes.DECIMAL(9, 6),
    allowNull: false,
  },
  kinh_do: {
    type: DataTypes.DECIMAL(9, 6),
    allowNull: false,
  },
  // Thuộc tính không gian lưu tọa độ Point cho GIS
  geom: {
    type: DataTypes.GEOMETRY('POINT', 4326),
    allowNull: false,
  },
  id_ranhgioi: { type: DataTypes.INTEGER, allowNull: true },
  mo_ta: { type: DataTypes.TEXT, allowNull: true },
  is_active: {
    type: DataTypes.BOOLEAN,
    defaultValue: true,
  }
}, {
  indexes: [
    {
      name: 'idx_locations_geom_gist',
      using: 'gist',
      fields: ['geom']
    }
  ]
});

module.exports = Location;