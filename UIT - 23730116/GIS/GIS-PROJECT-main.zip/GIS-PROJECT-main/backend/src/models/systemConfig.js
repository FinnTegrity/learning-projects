const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const SystemConfig = sequelize.define('SYSTEM_CONFIG', {
  id_cauhinh: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  khoa_cauhinh: { type: DataTypes.STRING(100), allowNull: false, unique: true },
  gia_tri: { type: DataTypes.TEXT, allowNull: false },
  mo_ta: { type: DataTypes.TEXT },
  cap_nhat_luc: { type: DataTypes.DATE, defaultValue: DataTypes.NOW }
});

module.exports = SystemConfig;