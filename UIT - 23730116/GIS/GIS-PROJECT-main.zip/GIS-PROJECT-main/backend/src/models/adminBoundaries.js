const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const AdminBoundary = sequelize.define('ADMIN_BOUNDARIES', {
  id_ranhgioi: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  ten_donvi: { type: DataTypes.STRING(150), allowNull: false },
  cap_hanhchinh: { type: DataTypes.STRING(50), allowNull: false },
  geom: { type: DataTypes.GEOMETRY('MULTIPOLYGON', 4326), allowNull: false }
}, {
  indexes: [
    {
      name: 'idx_admin_boundaries_geom_gist',
      using: 'gist',
      fields: ['geom']
    }
  ]
});

module.exports = AdminBoundary;