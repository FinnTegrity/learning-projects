const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const UserFavoriteLocation = sequelize.define('USER_FAVORITE_LOCATIONS', {
  id_nguoidung: { type: DataTypes.INTEGER, primaryKey: true },
  id_diadiem: { type: DataTypes.INTEGER, primaryKey: true },
  ngay_tao: { type: DataTypes.DATE, defaultValue: DataTypes.NOW }
});

module.exports = UserFavoriteLocation;