const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const GridCell = sequelize.define('GRID_CELLS', {
  id_oluoi: { type: DataTypes.BIGINT, primaryKey: true, autoIncrement: true },
  id_ranhgioi: { type: DataTypes.INTEGER, allowNull: false },
  geom: { type: DataTypes.GEOMETRY('POLYGON', 4326), allowNull: false },
  tam_vi_do: { type: DataTypes.DECIMAL(9, 6), allowNull: false },
  tam_kinh_do: { type: DataTypes.DECIMAL(9, 6), allowNull: false },
  do_phan_giai: { type: DataTypes.DECIMAL(8, 3), allowNull: true }
}, {
  timestamps: true,
  indexes: [
    {
      name: 'idx_grid_cells_geom_gist',
      using: 'gist',
      fields: ['geom']
    }
  ]
});

module.exports = GridCell;
