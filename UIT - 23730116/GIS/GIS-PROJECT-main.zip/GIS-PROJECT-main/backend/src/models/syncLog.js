const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const SyncLog = sequelize.define('SYNC_LOG', {
  id_log: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  bat_dau_luc: { type: DataTypes.DATE, allowNull: false },
  ket_thuc_luc: { type: DataTypes.DATE },
  trang_thai: { type: DataTypes.STRING(50), allowNull: false },
  so_ban_ghi: { type: DataTypes.INTEGER, defaultValue: 0 },
  thong_bao_loi: { type: DataTypes.TEXT },
  nguon_du_lieu: { type: DataTypes.STRING(40) }
});

module.exports = SyncLog;