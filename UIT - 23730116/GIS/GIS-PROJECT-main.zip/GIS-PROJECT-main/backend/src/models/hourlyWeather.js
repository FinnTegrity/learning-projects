const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');
const Location = require('./locations');

const HourlyWeather = sequelize.define('HOURLY_WEATHER', {
  id_thoitietgio: { type: DataTypes.BIGINT, primaryKey: true, autoIncrement: true },
  id_diadiem: { type: DataTypes.INTEGER, allowNull: false },
  thoi_gian: { type: DataTypes.DATE, allowNull: false },
  nhiet_do: { type: DataTypes.DECIMAL(5, 2) },
  nhiet_do_cam_nhan: { type: DataTypes.DECIMAL(5, 2) },
  do_am: { 
    type: DataTypes.SMALLINT,
    validate: { min: 0, max: 100 }
  }, // 0-100
  luong_mua: { 
    type: DataTypes.DECIMAL(7, 2), 
    defaultValue: 0,
    validate: { min: 0 }
  },
  ap_suat: { 
    type: DataTypes.DECIMAL(7, 2),
    validate: { min: 0 }
  },
  do_phu_may: { 
    type: DataTypes.SMALLINT,
    validate: { min: 0, max: 100 }
  }, // 0-100
  toc_do_gio: { 
    type: DataTypes.DECIMAL(6, 2),
    validate: { min: 0 }
  },
  huong_gio: { 
    type: DataTypes.SMALLINT,
    validate: { min: 0, max: 360 }
  }, // 0-360
  gio_giat: { 
    type: DataTypes.DECIMAL(6, 2),
    validate: { min: 0 }
  },
  nguon_du_lieu: { type: DataTypes.STRING(40), allowNull: false },
  cap_nhat_luc: { type: DataTypes.DATE, allowNull: false, defaultValue: DataTypes.NOW }
}, {
  indexes: [
    { name: 'idx_hourly_unique', unique: true, fields: ['id_diadiem', 'thoi_gian', 'nguon_du_lieu'] }
  ]
});

// Thiết lập mối quan hệ: Một địa điểm có nhiều bản ghi thời tiết theo giờ
Location.hasMany(HourlyWeather, { foreignKey: 'id_diadiem' });
HourlyWeather.belongsTo(Location, { foreignKey: 'id_diadiem' });

module.exports = HourlyWeather;