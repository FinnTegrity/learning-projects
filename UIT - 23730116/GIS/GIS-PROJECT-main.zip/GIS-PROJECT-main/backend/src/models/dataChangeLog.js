const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const DataChangeLog = sequelize.define('DATA_CHANGE_LOG', {
  id_thaydoi: { type: DataTypes.BIGINT, primaryKey: true, autoIncrement: true },
  id_nguoidung: { type: DataTypes.INTEGER, allowNull: false },
  bang_du_lieu: { type: DataTypes.STRING(80), allowNull: false },
  id_ban_ghi: { type: DataTypes.BIGINT, allowNull: false },
  loai_thao_tac: { type: DataTypes.STRING(20), allowNull: false }, // 'INSERT', 'UPDATE', 'DELETE'
  gia_tri_cu: { type: DataTypes.JSONB, allowNull: true },
  gia_tri_moi: { type: DataTypes.JSONB, allowNull: true },
  thoi_gian: { type: DataTypes.DATE, allowNull: false, defaultValue: DataTypes.NOW }
}, {
  timestamps: false
});

module.exports = DataChangeLog;
