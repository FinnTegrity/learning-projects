const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const DailyWeather = sequelize.define('DAILY_WEATHER', {
  id_thoitietngay: { type: DataTypes.BIGINT, primaryKey: true, autoIncrement: true },
  id_diadiem: { type: DataTypes.INTEGER, allowNull: false },
  ngay_ghi_nhan: { type: DataTypes.DATEONLY, allowNull: false },
  nhiet_do_max: { type: DataTypes.DECIMAL(5, 2) },
  nhiet_do_min: { type: DataTypes.DECIMAL(5, 2) },
  nhiet_do_tb: { type: DataTypes.DECIMAL(5, 2) },
  tong_luong_mua: { 
    type: DataTypes.DECIMAL(7, 2), 
    defaultValue: 0,
    validate: { min: 0 }
  },
  so_gio_mua: { type: DataTypes.DECIMAL(5, 2) },
  binh_minh: { type: DataTypes.TIME },
  hoang_hon: { type: DataTypes.TIME },
  toc_do_gio_max: { 
    type: DataTypes.DECIMAL(6, 2),
    validate: { min: 0 }
  },
  huong_gio_chinh: { 
    type: DataTypes.SMALLINT,
    validate: { min: 0, max: 360 }
  },
  nguon_du_lieu: { type: DataTypes.STRING(40), allowNull: false }
}, {
  indexes: [
    { name: 'idx_daily_unique', unique: true, fields: ['id_diadiem', 'ngay_ghi_nhan', 'nguon_du_lieu'] }
  ]
});

module.exports = DailyWeather;