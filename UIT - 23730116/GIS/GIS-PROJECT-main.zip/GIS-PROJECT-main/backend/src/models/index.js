const sequelize = require('../config/db');

const User = require('./users');
const AdminBoundary = require('./adminBoundaries');
const Location = require('./locations');
const HourlyWeather = require('./hourlyWeather');
const DailyWeather = require('./dailyWeather');
const ForecastData = require('./forecastData');
const UserFavoriteLocation = require('./userFavoriteLocations');
const SystemConfig = require('./systemConfig');
const SyncLog = require('./syncLog');
const GridCell = require('./gridCells');
const GridTimeValue = require('./gridTimeValues');
const DataChangeLog = require('./dataChangeLog');

// 1. Quan hệ ADMIN_BOUNDARIES (1) - (N) LOCATIONS
AdminBoundary.hasMany(Location, { foreignKey: 'id_ranhgioi' });
Location.belongsTo(AdminBoundary, { foreignKey: 'id_ranhgioi' });

// 2. Quan hệ LOCATIONS (1) - (N) Thời tiết và Dự báo
Location.hasMany(HourlyWeather, { foreignKey: 'id_diadiem' });
HourlyWeather.belongsTo(Location, { foreignKey: 'id_diadiem' });

// 3. Quan hệ ADMIN_BOUNDARIES (1) - (N) GRID_CELLS
AdminBoundary.hasMany(GridCell, { foreignKey: 'id_ranhgioi' });
GridCell.belongsTo(AdminBoundary, { foreignKey: 'id_ranhgioi' });

// 4. Quan hệ GRID_CELLS (1) - (N) GRID_TIME_VALUES
GridCell.hasMany(GridTimeValue, { foreignKey: 'id_oluoi' });
GridTimeValue.belongsTo(GridCell, { foreignKey: 'id_oluoi' });

// 5. Quan hệ USERS (1) - (N) DATA_CHANGE_LOG
User.hasMany(DataChangeLog, { foreignKey: 'id_nguoidung' });
DataChangeLog.belongsTo(User, { foreignKey: 'id_nguoidung' });

Location.hasMany(DailyWeather, { foreignKey: 'id_diadiem' });
DailyWeather.belongsTo(Location, { foreignKey: 'id_diadiem' });

Location.hasMany(ForecastData, { foreignKey: 'id_diadiem' });
ForecastData.belongsTo(Location, { foreignKey: 'id_diadiem' });

// 6. Quan hệ USERS (N) - (N) LOCATIONS qua bảng trung gian
User.belongsToMany(Location, { through: UserFavoriteLocation, foreignKey: 'id_nguoidung' });
Location.belongsToMany(User, { through: UserFavoriteLocation, foreignKey: 'id_diadiem' });

module.exports = {
  sequelize,
  User, AdminBoundary, Location, HourlyWeather, 
  DailyWeather, ForecastData, UserFavoriteLocation, 
  SystemConfig, SyncLog, GridCell, GridTimeValue, DataChangeLog
};