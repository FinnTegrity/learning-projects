const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const ForecastData = sequelize.define('FORECAST_DATA', {
  id_dubao: { type: DataTypes.BIGINT, primaryKey: true, autoIncrement: true },
  id_diadiem: { type: DataTypes.INTEGER, allowNull: false },
  thoi_gian_tao: { type: DataTypes.DATE, allowNull: false, defaultValue: DataTypes.NOW },
  thoi_gian_dubao: { type: DataTypes.DATE, allowNull: false },
  nguon_dubao: { type: DataTypes.STRING(40), allowNull: false }, // 'open_meteo' hoặc 'local_baseline'
  phuong_phap: { type: DataTypes.STRING(60), allowNull: false },
  nhiet_do_dubao: { type: DataTypes.DECIMAL(5, 2) },
  do_am_dubao: { 
    type: DataTypes.DECIMAL(5, 2),
    validate: { min: 0, max: 100 }
  },
  luong_mua_dubao: { 
    type: DataTypes.DECIMAL(7, 2),
    validate: { min: 0 }
  },
  toc_do_gio_dubao: { 
    type: DataTypes.DECIMAL(6, 2),
    validate: { min: 0 }
  }
}, {
  indexes: [
    { name: 'idx_forecast_unique', unique: true, fields: ['id_diadiem', 'thoi_gian_tao', 'thoi_gian_dubao', 'nguon_dubao', 'phuong_phap'] }
  ]
});

module.exports = ForecastData;