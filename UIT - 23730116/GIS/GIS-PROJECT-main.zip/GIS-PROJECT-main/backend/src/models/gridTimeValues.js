const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const GridTimeValue = sequelize.define('GRID_TIME_VALUES', {
  id_giatri: { type: DataTypes.BIGINT, primaryKey: true, autoIncrement: true },
  id_oluoi: { type: DataTypes.BIGINT, allowNull: false },
  thoi_gian: { type: DataTypes.DATE, allowNull: false },
  bien_thoitiet: { type: DataTypes.STRING(40), allowNull: false },
  gia_tri: { type: DataTypes.DECIMAL(10, 3), allowNull: false },
  z_scaled: { type: DataTypes.DECIMAL(10, 3), allowNull: true },
  phuong_phap_suy_dien: { type: DataTypes.STRING(40), allowNull: true }
}, {
  timestamps: true,
  indexes: [
    {
      name: 'idx_grid_time_values_unique',
      unique: true,
      fields: ['id_oluoi', 'thoi_gian', 'bien_thoitiet']
    },
    {
      name: 'idx_grid_time_values_time',
      fields: ['thoi_gian']
    }
  ]
});

module.exports = GridTimeValue;
