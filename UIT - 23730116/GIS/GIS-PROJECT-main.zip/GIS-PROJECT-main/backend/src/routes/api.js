const express = require('express');
const router = express.Router();
const { getWeatherMapData, getGridMapData } = require('../controllers/mapController');
const { generateForecast, getComparisonData } = require('../controllers/analyticsController');
const { getAdministrativeBoundaries } = require('../controllers/boundaryController');
const { syncWeatherFromOpenMeteo } = require('../services/syncDataService');
const { aggregateDailyWeather } = require('../services/aggregationService'); 

router.get('/map/weather', getWeatherMapData);
router.get('/map/grid', getGridMapData);
router.get('/map/boundaries', getAdministrativeBoundaries);

const { authenticateToken, requireRole } = require('../utils/authMiddleware');
const adminController = require('../controllers/adminController');

// 👉 API lấy dữ liệu ban đầu
router.get('/analytics/comparison/:id', getComparisonData);

// 👉 API Chạy mô hình chuẩn Sơ đồ trình tự (Gộp xử lý + trả Data)
router.post('/analytics/generate-forecast/:id', generateForecast);

router.post('/weather/sync', async (req, res) => {
  try {
    await syncWeatherFromOpenMeteo();
    res.json({ message: 'Đồng bộ thành công!' });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

router.post('/weather/aggregate', async (req, res) => {
  try {
    await aggregateDailyWeather();
    res.json({ message: 'Tổng hợp dữ liệu ngày thành công!' });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

// ==========================================
// 🛡️ ADMIN CRUD ENDPOINTS
// ==========================================

// Locations CRUD
router.get('/admin/locations', authenticateToken, requireRole(['admin']), adminController.getLocations);
router.post('/admin/locations', authenticateToken, requireRole(['admin']), adminController.createLocation);
router.put('/admin/locations/:id', authenticateToken, requireRole(['admin']), adminController.updateLocation);
router.delete('/admin/locations/:id', authenticateToken, requireRole(['admin']), adminController.deleteLocation);

// Users CRUD
router.get('/admin/users', authenticateToken, requireRole(['admin']), adminController.getUsers);
router.post('/admin/users', authenticateToken, requireRole(['admin']), adminController.createUser);
router.put('/admin/users/:id', authenticateToken, requireRole(['admin']), adminController.updateUser);
router.delete('/admin/users/:id', authenticateToken, requireRole(['admin']), adminController.deleteUser);

// System Config CRUD
router.get('/admin/config', authenticateToken, requireRole(['admin']), adminController.getConfigs);
router.post('/admin/config', authenticateToken, requireRole(['admin']), adminController.createConfig);
router.put('/admin/config/:id', authenticateToken, requireRole(['admin']), adminController.updateConfig);
router.delete('/admin/config/:id', authenticateToken, requireRole(['admin']), adminController.deleteConfig);

// Sync Logs
router.get('/admin/sync-logs', authenticateToken, requireRole(['admin']), adminController.getSyncLogs);

// Weather CRUD Endpoints
router.get('/admin/weather', authenticateToken, requireRole(['admin']), adminController.getWeatherRecords);
router.post('/admin/weather', authenticateToken, requireRole(['admin']), adminController.createWeatherRecord);
router.put('/admin/weather/:id', authenticateToken, requireRole(['admin']), adminController.updateWeatherRecord);
router.delete('/admin/weather/:id', authenticateToken, requireRole(['admin']), adminController.deleteWeatherRecord);

// Data Change Logs
router.get('/admin/change-logs', authenticateToken, requireRole(['admin']), adminController.getChangeLogs);

// Spatial Interpolation Trigger
router.post('/admin/interpolate', authenticateToken, requireRole(['admin']), async (req, res) => {
  try {
    const { targetTime } = req.body;
    const { runIDWInterpolation } = require('../services/interpolationService');
    const result = await runIDWInterpolation(targetTime);
    if (result.success) {
      res.json(result);
    } else {
      res.status(400).json(result);
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;