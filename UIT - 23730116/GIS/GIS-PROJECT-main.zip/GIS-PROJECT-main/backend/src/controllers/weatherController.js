const HourlyWeather = require('../models/hourlyWeather');

const getWeatherHistory = async (req, res) => {
  try {
    const { id_diadiem } = req.params;

    // Truy vấn dữ liệu thời tiết theo giờ của địa điểm, sắp xếp thời gian tăng dần (ASC) để vẽ biểu đồ
    const history = await HourlyWeather.findAll({
      where: { id_diadiem },
      order: [['thoi_gian', 'ASC']],
      limit: 24 // Lấy dữ liệu 24 tiếng gần nhất
    });

    res.json(history);
  } catch (error) {
    console.error('❌ Lỗi khi lấy lịch sử thời tiết:', error);
    res.status(500).json({ message: 'Lỗi hệ thống khi tải chuỗi thời gian.' });
  }
};

module.exports = { getWeatherHistory };