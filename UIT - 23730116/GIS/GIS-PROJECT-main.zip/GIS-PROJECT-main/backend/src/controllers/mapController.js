const { Op } = require('sequelize');
const Location = require('../models/locations');
const HourlyWeather = require('../models/hourlyWeather');
const SyncLog = require('../models/syncLog');
const sequelize = require('../config/db');

const getWeatherMapData = async (req, res) => {
  try {
    const targetTime = req.query.targetTime ? new Date(req.query.targetTime) : new Date();

    // Lấy nguồn dữ liệu từ lần đồng bộ thành công gần nhất
    const latestLog = await SyncLog.findOne({
      where: { trang_thai: 'Thành công' },
      order: [['bat_dau_luc', 'DESC']]
    });
    const activeSource = latestLog ? latestLog.nguon_du_lieu : 'open_meteo';

    const { minLat, minLng, maxLat, maxLng, bbox } = req.query;
    const whereClause = { is_active: true };

    let bounds = null;
    if (bbox) {
      const parts = bbox.split(',').map(Number);
      if (parts.length === 4 && parts.every(p => !isNaN(p))) {
        bounds = { minLng: parts[0], minLat: parts[1], maxLng: parts[2], maxLat: parts[3] };
      }
    } else if (minLat && minLng && maxLat && maxLng) {
      bounds = {
        minLng: parseFloat(minLng),
        minLat: parseFloat(minLat),
        maxLng: parseFloat(maxLng),
        maxLat: parseFloat(maxLat)
      };
    }

    if (bounds && !isNaN(bounds.minLng) && !isNaN(bounds.minLat) && !isNaN(bounds.maxLng) && !isNaN(bounds.maxLat)) {
      whereClause.geom = sequelize.where(
        sequelize.fn('ST_Within',
          sequelize.col('geom'),
          sequelize.fn('ST_MakeEnvelope',
            bounds.minLng,
            bounds.minLat,
            bounds.maxLng,
            bounds.maxLat,
            4326
          )
        ),
        true
      );
    }

    const locations = await Location.findAll({
      where: whereClause,
      include: [{
        model: HourlyWeather,
        required: false,
        separate: true,
        limit: 1,    
        where: {
          thoi_gian: {
            [Op.lte]: targetTime 
          },
          nguon_du_lieu: activeSource 
        },
        order: [['thoi_gian', 'DESC']]
      }]
    });

    // Chuẩn hóa tập kết quả thành định dạng GeoJSON FeatureCollection
    const geoJsonFeatures = locations.map(loc => {
      const latestWeather = loc.HOURLY_WEATHERs && loc.HOURLY_WEATHERs[0];
      
      // Calculate a composite index (Thom's Discomfort Index)
      let compositeIndex = null;
      if (latestWeather && latestWeather.nhiet_do !== null && latestWeather.do_am !== null) {
        const T = parseFloat(latestWeather.nhiet_do);
        const R = parseFloat(latestWeather.do_am);
        // Thom's Discomfort Index (DI)
        compositeIndex = T - 0.55 * (1 - 0.01 * R) * (T - 14);
      }

      return {
        type: 'Feature',
        geometry: loc.geom, 
        properties: {
          id_diadiem: loc.id_diadiem,
          ten_khuvuc: loc.ten_khuvuc,
          vi_do: loc.vi_do,
          kinh_do: loc.kinh_do,
          thoi_gian_cap_nhat: latestWeather ? latestWeather.thoi_gian : null,
          nhiet_do: latestWeather ? parseFloat(latestWeather.nhiet_do).toFixed(1) : null,
          do_am: latestWeather ? latestWeather.do_am : null,
          luong_mua: latestWeather ? parseFloat(latestWeather.luong_mua) : 0,
          ap_suat: latestWeather ? parseFloat(latestWeather.ap_suat) : null,
          toc_do_gio: latestWeather ? parseFloat(latestWeather.toc_do_gio) : null,
          huong_gio: latestWeather ? latestWeather.huong_gio : null,
          do_phu_may: latestWeather ? latestWeather.do_phu_may : null,
          composite_index: compositeIndex ? parseFloat(compositeIndex.toFixed(1)) : null
        }
      };
    });

    res.json({
      type: 'FeatureCollection',
      features: geoJsonFeatures
    });

  } catch (error) {
    console.error('❌ Lỗi khi lấy dữ liệu bản đồ GeoJSON:', error);
    res.status(500).json({ message: 'Lỗi hệ thống khi xử lý dữ liệu không gian.' });
  }
};

const getGridMapData = async (req, res) => {
  try {
    const targetTime = req.query.targetTime ? new Date(req.query.targetTime) : new Date();
    const { GridCell, GridTimeValue } = require('../models/index');
    const { runIDWInterpolation } = require('../services/interpolationService');

    // 1. Kiểm tra xem đã có dữ liệu ô lưới cho mốc thời gian này chưa
    let values = await GridTimeValue.findAll({
      where: { thoi_gian: targetTime }
    });

    // 2. Nếu chưa có, tiến hành chạy nội suy IDW tự động on-the-fly cho mốc thời gian này
    if (values.length === 0) {
      console.log(`🔄 Không tìm thấy dữ liệu ô lưới cho mốc ${targetTime.toLocaleString('vi-VN')}. Tự động chạy nội suy IDW on-the-fly...`);
      const interpResult = await runIDWInterpolation(targetTime);
      if (interpResult.success && interpResult.thoi_gian) {
        // Tải lại các giá trị vừa được nội suy xong từ DB
        values = await GridTimeValue.findAll({
          where: { thoi_gian: interpResult.thoi_gian }
        });
      }
    }

    const resolvedTime = values.length > 0 ? values[0].thoi_gian : targetTime;

    // 3. Gom nhóm giá trị nội suy theo id_oluoi
    let gridValuesMap = {};
    values.forEach(v => {
      if (!gridValuesMap[v.id_oluoi]) gridValuesMap[v.id_oluoi] = {};
      gridValuesMap[v.id_oluoi][v.bien_thoitiet] = parseFloat(v.gia_tri);
    });

    // 4. Lấy danh sách ô lưới
    const cells = await GridCell.findAll();

    // 4. Định dạng thành GeoJSON Features
    const geoJsonFeatures = cells.map(cell => {
      const vals = gridValuesMap[cell.id_oluoi] || {};
      return {
        type: 'Feature',
        geometry: cell.geom,
        properties: {
          id_oluoi: cell.id_oluoi,
          id_ranhgioi: cell.id_ranhgioi,
          tam_vi_do: cell.tam_vi_do,
          tam_kinh_do: cell.tam_kinh_do,
          nhiet_do: vals['nhiet_do'] || null,
          do_am: vals['do_am'] || null,
          luong_mua: vals['luong_mua'] || 0,
          composite_index: vals['composite_index'] || null,
          thoi_gian: resolvedTime
        }
      };
    });

    res.json({
      type: 'FeatureCollection',
      features: geoJsonFeatures
    });

  } catch (error) {
    console.error('❌ Lỗi khi lấy dữ liệu bản đồ ô lưới:', error);
    res.status(500).json({ message: 'Lỗi hệ thống khi xử lý dữ liệu ô lưới.' });
  }
};

module.exports = { getWeatherMapData, getGridMapData };