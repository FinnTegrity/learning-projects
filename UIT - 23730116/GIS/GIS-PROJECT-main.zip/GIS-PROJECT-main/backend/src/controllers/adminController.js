const bcrypt = require('bcryptjs');
const db = require('../models/index');
const { User, Location, SystemConfig, SyncLog, AdminBoundary, HourlyWeather, DataChangeLog } = db;

// ==========================================
// 📍 LOCATIONS CRUD
// ==========================================

const getLocations = async (req, res) => {
  try {
    const locations = await Location.findAll({
      order: [['id_diadiem', 'ASC']]
    });
    res.json(locations);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const createLocation = async (req, res) => {
  try {
    const { ten_khuvuc, vi_do, kinh_do, id_ranhgioi, mo_ta, is_active } = req.body;
    if (!ten_khuvuc || !vi_do || !kinh_do) {
      return res.status(400).json({ message: 'Thiếu tên khu vực, vĩ độ hoặc kinh độ.' });
    }

    const geom = { type: 'Point', coordinates: [parseFloat(kinh_do), parseFloat(vi_do)] };

    const newLoc = await Location.create({
      ten_khuvuc,
      vi_do: parseFloat(vi_do),
      kinh_do: parseFloat(kinh_do),
      geom,
      id_ranhgioi: id_ranhgioi ? parseInt(id_ranhgioi) : null,
      mo_ta,
      is_active: is_active !== undefined ? is_active : true
    });

    res.status(201).json(newLoc);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const updateLocation = async (req, res) => {
  try {
    const { id } = req.params;
    const { ten_khuvuc, vi_do, kinh_do, id_ranhgioi, mo_ta, is_active } = req.body;

    const loc = await Location.findByPk(id);
    if (!loc) return res.status(404).json({ message: 'Không tìm thấy địa điểm.' });

    const updateData = {
      ten_khuvuc,
      vi_do: vi_do !== undefined ? parseFloat(vi_do) : loc.vi_do,
      kinh_do: kinh_do !== undefined ? parseFloat(kinh_do) : loc.kinh_do,
      id_ranhgioi: id_ranhgioi !== undefined ? (id_ranhgioi ? parseInt(id_ranhgioi) : null) : loc.id_ranhgioi,
      mo_ta: mo_ta !== undefined ? mo_ta : loc.mo_ta,
      is_active: is_active !== undefined ? is_active : loc.is_active
    };

    if (vi_do !== undefined || kinh_do !== undefined) {
      const lat = vi_do !== undefined ? parseFloat(vi_do) : parseFloat(loc.vi_do);
      const lng = kinh_do !== undefined ? parseFloat(kinh_do) : parseFloat(loc.kinh_do);
      updateData.geom = { type: 'Point', coordinates: [lng, lat] };
    }

    await loc.update(updateData);
    res.json(loc);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const deleteLocation = async (req, res) => {
  try {
    const { id } = req.params;
    const loc = await Location.findByPk(id);
    if (!loc) return res.status(404).json({ message: 'Không tìm thấy địa điểm.' });

    try {
      await loc.destroy();
      res.json({ message: 'Xóa địa điểm thành công!' });
    } catch (err) {
      // Nếu có ràng buộc khóa ngoại, chuyển trạng thái is_active = false
      await loc.update({ is_active: false });
      res.json({ message: 'Địa điểm có liên kết dữ liệu thời tiết. Đã chuyển sang trạng thái ngưng hoạt động.' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// ==========================================
// 👤 USERS CRUD
// ==========================================

const getUsers = async (req, res) => {
  try {
    const users = await User.findAll({
      attributes: { exclude: ['mat_khau_hash'] },
      order: [['id_nguoidung', 'ASC']]
    });
    res.json(users);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const createUser = async (req, res) => {
  try {
    const { ten_dang_nhap, mat_khau, vai_tro, email, trang_thai } = req.body;
    if (!ten_dang_nhap || !mat_khau) {
      return res.status(400).json({ message: 'Thiếu tên đăng nhập hoặc mật khẩu.' });
    }

    const existing = await User.findOne({ where: { ten_dang_nhap } });
    if (existing) return res.status(400).json({ message: 'Tên đăng nhập đã tồn tại.' });

    const salt = await bcrypt.genSalt(10);
    const mat_khau_hash = await bcrypt.hash(mat_khau, salt);

    const newUser = await User.create({
      ten_dang_nhap,
      mat_khau_hash,
      vai_tro: vai_tro || 'user',
      email,
      trang_thai: trang_thai !== undefined ? trang_thai : true
    });

    const userObj = newUser.toJSON();
    delete userObj.mat_khau_hash;
    res.status(201).json(userObj);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const updateUser = async (req, res) => {
  try {
    const { id } = req.params;
    const { ten_dang_nhap, mat_khau, vai_tro, email, trang_thai } = req.body;

    const user = await User.findByPk(id);
    if (!user) return res.status(404).json({ message: 'Không tìm thấy người dùng.' });

    const updateData = {
      ten_dang_nhap: ten_dang_nhap !== undefined ? ten_dang_nhap : user.ten_dang_nhap,
      vai_tro: vai_tro !== undefined ? vai_tro : user.vai_tro,
      email: email !== undefined ? email : user.email,
      trang_thai: trang_thai !== undefined ? trang_thai : user.trang_thai
    };

    if (mat_khau) {
      const salt = await bcrypt.genSalt(10);
      updateData.mat_khau_hash = await bcrypt.hash(mat_khau, salt);
    }

    await user.update(updateData);
    const userObj = user.toJSON();
    delete userObj.mat_khau_hash;
    res.json(userObj);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const deleteUser = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await User.findByPk(id);
    if (!user) return res.status(404).json({ message: 'Không tìm thấy người dùng.' });

    await user.destroy();
    res.json({ message: 'Xóa người dùng thành công!' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// ==========================================
// ⚙️ SYSTEM CONFIG CRUD
// ==========================================

const getConfigs = async (req, res) => {
  try {
    const configs = await SystemConfig.findAll({ order: [['id_cauhinh', 'ASC']] });
    res.json(configs);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const createConfig = async (req, res) => {
  try {
    const { khoa_cauhinh, gia_tri, mo_ta } = req.body;
    if (!khoa_cauhinh || !gia_tri) {
      return res.status(400).json({ message: 'Thiếu khóa hoặc giá trị cấu hình.' });
    }

    const newConf = await SystemConfig.create({ khoa_cauhinh, gia_tri, mo_ta });
    res.status(201).json(newConf);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const updateConfig = async (req, res) => {
  try {
    const { id } = req.params;
    const { khoa_cauhinh, gia_tri, mo_ta } = req.body;

    const conf = await SystemConfig.findByPk(id);
    if (!conf) return res.status(404).json({ message: 'Không tìm thấy cấu hình.' });

    await conf.update({
      khoa_cauhinh: khoa_cauhinh !== undefined ? khoa_cauhinh : conf.khoa_cauhinh,
      gia_tri: gia_tri !== undefined ? gia_tri : conf.gia_tri,
      mo_ta: mo_ta !== undefined ? mo_ta : conf.mo_ta,
      cap_nhat_luc: new Date()
    });
    res.json(conf);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const deleteConfig = async (req, res) => {
  try {
    const { id } = req.params;
    const conf = await SystemConfig.findByPk(id);
    if (!conf) return res.status(404).json({ message: 'Không tìm thấy cấu hình.' });

    await conf.destroy();
    res.json({ message: 'Xóa cấu hình thành công!' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// ==========================================
// 📜 SYNC LOGS
// ==========================================

const getSyncLogs = async (req, res) => {
  try {
    const logs = await SyncLog.findAll({
      order: [['bat_dau_luc', 'DESC']],
      limit: 100
    });
    res.json(logs);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// ==========================================
// 🌦️ HOURLY WEATHER CRUD & LOGGING
// ==========================================

const getWeatherRecords = async (req, res) => {
  try {
    const { limit = 50, offset = 0 } = req.query;
    const records = await HourlyWeather.findAll({
      include: [{ model: Location, attributes: ['ten_khuvuc'] }],
      order: [['thoi_gian', 'DESC']],
      limit: parseInt(limit),
      offset: parseInt(offset)
    });
    res.json(records);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const createWeatherRecord = async (req, res) => {
  try {
    const { id_diadiem, thoi_gian, nhiet_do, do_am, luong_mua, nguon_du_lieu } = req.body;
    if (!id_diadiem || !thoi_gian) {
      return res.status(400).json({ message: 'Thiếu mã địa điểm hoặc thời gian ghi nhận.' });
    }

    const newRecord = await HourlyWeather.create({
      id_diadiem: parseInt(id_diadiem),
      thoi_gian: new Date(thoi_gian),
      nhiet_do: nhiet_do !== undefined ? parseFloat(nhiet_do) : null,
      do_am: do_am !== undefined ? parseInt(do_am) : null,
      luong_mua: luong_mua !== undefined ? parseFloat(luong_mua) : 0,
      nguon_du_lieu: nguon_du_lieu || 'manual',
      cap_nhat_luc: new Date()
    });

    // Ghi nhật ký chỉnh sửa
    await DataChangeLog.create({
      id_nguoidung: req.user.id,
      bang_du_lieu: 'HOURLY_WEATHERS',
      id_ban_ghi: newRecord.id_thoitietgio,
      loai_thao_tac: 'INSERT',
      gia_tri_cu: null,
      gia_tri_moi: newRecord.toJSON(),
      thoi_gian: new Date()
    });

    // Tự động chạy nội suy không gian để cập nhật ô lưới
    try {
      const { runIDWInterpolation } = require('../services/interpolationService');
      await runIDWInterpolation(newRecord.thoi_gian);
    } catch (interpErr) {
      console.error('⚠️ Tự động chạy nội suy IDW khi tạo dữ liệu thất bại:', interpErr.message);
    }

    res.status(201).json(newRecord);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const updateWeatherRecord = async (req, res) => {
  try {
    const { id } = req.params;
    const { nhiet_do, do_am, luong_mua } = req.body;

    const record = await HourlyWeather.findByPk(id);
    if (!record) return res.status(404).json({ message: 'Không tìm thấy bản ghi thời tiết.' });

    const oldValue = record.toJSON();

    await record.update({
      nhiet_do: nhiet_do !== undefined ? parseFloat(nhiet_do) : record.nhiet_do,
      do_am: do_am !== undefined ? parseInt(do_am) : record.do_am,
      luong_mua: luong_mua !== undefined ? parseFloat(luong_mua) : record.luong_mua,
      cap_nhat_luc: new Date()
    });

    // Ghi nhật ký chỉnh sửa
    await DataChangeLog.create({
      id_nguoidung: req.user.id,
      bang_du_lieu: 'HOURLY_WEATHERS',
      id_ban_ghi: record.id_thoitietgio,
      loai_thao_tac: 'UPDATE',
      gia_tri_cu: oldValue,
      gia_tri_moi: record.toJSON(),
      thoi_gian: new Date()
    });

    // Cập nhật nội suy không gian
    try {
      const { runIDWInterpolation } = require('../services/interpolationService');
      await runIDWInterpolation(record.thoi_gian);
    } catch (interpErr) {
      console.error('⚠️ Tự động cập nhật nội suy IDW khi cập nhật dữ liệu thất bại:', interpErr.message);
    }

    res.json(record);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const deleteWeatherRecord = async (req, res) => {
  try {
    const { id } = req.params;
    const record = await HourlyWeather.findByPk(id);
    if (!record) return res.status(404).json({ message: 'Không tìm thấy bản ghi thời tiết.' });

    const oldValue = record.toJSON();
    await record.destroy();

    // Ghi nhật ký chỉnh sửa
    await DataChangeLog.create({
      id_nguoidung: req.user.id,
      bang_du_lieu: 'HOURLY_WEATHERS',
      id_ban_ghi: id,
      loai_thao_tac: 'DELETE',
      gia_tri_cu: oldValue,
      gia_tri_moi: null,
      thoi_gian: new Date()
    });

    // Cập nhật nội suy không gian
    try {
      const { runIDWInterpolation } = require('../services/interpolationService');
      await runIDWInterpolation(record.thoi_gian);
    } catch (interpErr) {
      console.error('⚠️ Tự động cập nhật nội suy IDW khi xóa dữ liệu thất bại:', interpErr.message);
    }

    res.json({ message: 'Xóa bản ghi thời tiết thành công!' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const getChangeLogs = async (req, res) => {
  try {
    const logs = await DataChangeLog.findAll({
      include: [{ model: User, attributes: ['ten_dang_nhap'] }],
      order: [['thoi_gian', 'DESC']],
      limit: 100
    });
    res.json(logs);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

module.exports = {
  getLocations, createLocation, updateLocation, deleteLocation,
  getUsers, createUser, updateUser, deleteUser,
  getConfigs, createConfig, updateConfig, deleteConfig,
  getSyncLogs,
  getWeatherRecords, createWeatherRecord, updateWeatherRecord, deleteWeatherRecord,
  getChangeLogs
};
