const { Op } = require('sequelize');
const db = require('../models/index');
const { HourlyWeather, ForecastData, DailyWeather, SyncLog } = db; 
const { fitAndPredict } = require('../services/forecastService');

const getComparisonData = async (req, res) => {
  const id = req.params.id || req.params.id_diadiem;
  try {
    if (!id) return res.status(400).json({ message: 'Không tìm thấy ID địa điểm yêu cầu.' });
    const currentTime = req.query.clientTime ? new Date(req.query.clientTime) : new Date();

    // Lấy nguồn dữ liệu từ lần đồng bộ thành công gần nhất
    const latestLog = await SyncLog.findOne({
      where: { trang_thai: 'Thành công' },
      order: [['bat_dau_luc', 'DESC']]
    });
    const activeSource = latestLog ? latestLog.nguon_du_lieu : 'open_meteo';

    const history = await HourlyWeather.findAll({ where: { id_diadiem: id, nguon_du_lieu: activeSource, thoi_gian: { [Op.lte]: currentTime } }, order: [['thoi_gian', 'DESC']], limit: 24 });
    history.reverse();
    const openMeteoForecast = await HourlyWeather.findAll({ where: { id_diadiem: id, nguon_du_lieu: activeSource, thoi_gian: { [Op.gt]: currentTime } }, order: [['thoi_gian', 'ASC']], limit: 24 });
    const baselineForecast = await ForecastData.findAll({ where: { id_diadiem: id, thoi_gian_dubao: { [Op.gt]: currentTime } }, order: [['thoi_gian_dubao', 'ASC']], limit: 24 });
    const dailyData = await DailyWeather.findAll({ where: { id_diadiem: id }, order: [['ngay_ghi_nhan', 'DESC']], limit: 7 });

    res.json({ history, openMeteoForecast, forecast: baselineForecast, daily: dailyData });
  } catch (error) {
    console.error('❌ Lỗi tại hàm getComparisonData:', error);
    res.status(500).json({ error: 'Lỗi hệ thống khi lấy chuỗi thời gian so sánh.' });
  }
};

const generateForecast = async (req, res) => {
  const idDiaDiem = req.params.id || req.params.id_diadiem;
  const { bienSo, phuongPhap, clientTime } = req.body;

  try {
    if (!idDiaDiem || !bienSo || !phuongPhap) return res.status(400).json({ message: 'Thiếu tham số bắt buộc.' });
    const currentTime = clientTime ? new Date(clientTime) : new Date();

    // Lấy nguồn dữ liệu từ lần đồng bộ thành công gần nhất
    const latestLog = await SyncLog.findOne({
      where: { trang_thai: 'Thành công' },
      order: [['bat_dau_luc', 'DESC']]
    });
    const activeSource = latestLog ? latestLog.nguon_du_lieu : 'open_meteo';

    const history = await HourlyWeather.findAll({
      where: { id_diadiem: idDiaDiem, nguon_du_lieu: activeSource, thoi_gian: { [Op.lte]: currentTime } },
      order: [['thoi_gian', 'DESC']], limit: 720
    });
    if (history.length < 336) return res.status(400).json({ message: 'Không đủ dữ liệu lịch sử để huấn luyện (yêu cầu tối thiểu 14 ngày tức 336 giờ).' });
    history.reverse();

    const series = history.map(h => parseFloat(h[bienSo]));
    const lastTime = new Date(history[history.length - 1].thoi_gian);

    const { forecastArray, metrics } = fitAndPredict(series, { phuongPhap, windowDays: 14 });

    const forecastPromises = forecastArray.map((val, index) => {
      const forecastTime = new Date(lastTime.getTime() + (index + 1) * 60 * 60 * 1000);
      const updateData = { id_diadiem: idDiaDiem, thoi_gian_dubao: forecastTime, nguon_dubao: 'baseline', phuong_phap: phuongPhap };
      
      if (bienSo === 'nhiet_do') updateData.nhiet_do_dubao = val.toFixed(2);
      if (bienSo === 'do_am') updateData.do_am_dubao = val.toFixed(2);
      
      return ForecastData.upsert(updateData);
    });
    await Promise.all(forecastPromises);

    const history24h = await HourlyWeather.findAll({ where: { id_diadiem: idDiaDiem, nguon_du_lieu: activeSource, thoi_gian: { [Op.lte]: currentTime } }, order: [['thoi_gian', 'DESC']], limit: 24 });
    history24h.reverse();
    const openMeteoForecast = await HourlyWeather.findAll({ where: { id_diadiem: idDiaDiem, nguon_du_lieu: activeSource, thoi_gian: { [Op.gt]: currentTime } }, order: [['thoi_gian', 'ASC']], limit: 24 });
    const baselineForecast = await ForecastData.findAll({ where: { id_diadiem: idDiaDiem, thoi_gian_dubao: { [Op.gt]: currentTime } }, order: [['thoi_gian_dubao', 'ASC']], limit: 24 });
    const dailyData = await DailyWeather.findAll({ where: { id_diadiem: idDiaDiem }, order: [['ngay_ghi_nhan', 'DESC']], limit: 7 });

    const chartData = { history: history24h, openMeteoForecast, forecast: baselineForecast, daily: dailyData, metrics };
    
    res.status(200).json({ message: 'Chạy mô hình thành công!', chartData });

  } catch (error) {
    console.error('❌ Lỗi tại hàm generateForecast:', error); 
    res.status(500).json({ error: error.message });
  }
};

module.exports = { generateForecast, getComparisonData };