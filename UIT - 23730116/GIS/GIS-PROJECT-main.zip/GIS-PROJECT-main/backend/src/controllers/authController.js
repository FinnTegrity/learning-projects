const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../models/index');
const { User, sequelize } = db;

const register = async (req, res) => {
  try {
    const { ten_dang_nhap, mat_khau, email, vai_tro } = req.body;

    const existingUser = await User.findOne({ where: { ten_dang_nhap } });
    if (existingUser) {
      return res.status(400).json({ message: 'Tên đăng nhập đã tồn tại!' });
    }

    const salt = await bcrypt.genSalt(10);
    const mat_khau_hash = await bcrypt.hash(mat_khau, salt);

    const newUser = await User.create({
      ten_dang_nhap,
      mat_khau_hash,
      email,
      vai_tro: vai_tro || 'user'
    });

    res.status(201).json({ 
      message: 'Đăng ký thành công!', 
      user: { id: newUser.id_nguoidung, username: newUser.ten_dang_nhap, role: newUser.vai_tro } 
    });
  } catch (error) {
    console.error('❌ Lỗi đăng ký:', error);
    res.status(500).json({ message: 'Lỗi hệ thống khi đăng ký.' });
  }
};

const JWT_SECRET = process.env.JWT_SECRET || 'doan_gis_secret_2026';

const login = async (req, res) => {
  const { ten_dang_nhap, mat_khau } = req.body;
  try {
    const [users] = await sequelize.query(`SELECT * FROM "USERS" WHERE ten_dang_nhap = :ten_dang_nhap LIMIT 1`, { replacements: { ten_dang_nhap } });
    
    if (users.length === 0) return res.status(401).json({ message: 'Tài khoản không tồn tại!' });
    const user = users[0];

    const isMatch = await bcrypt.compare(mat_khau, user.mat_khau_hash);
    if (!isMatch) return res.status(401).json({ message: 'Sai mật khẩu!' });

    const token = jwt.sign({ id: user.id_nguoidung, role: user.vai_tro }, JWT_SECRET, { expiresIn: '1d' });

    res.json({ message: 'Đăng nhập thành công', token, user: { id: user.id_nguoidung, username: user.ten_dang_nhap, role: user.vai_tro } });
  } catch (error) {
    console.error('Lỗi Login:', error);
    res.status(500).json({ error: 'Lỗi server' });
  }
};

module.exports = { register, login };