const db = require('../models/index');
const { sequelize } = db;

const getAdministrativeBoundaries = async (req, res) => {
  try {
    const query = `
      SELECT json_build_object(
        'type', 'FeatureCollection',
        'features', json_agg(
          json_build_object(
            'type', 'Feature',
            'geometry', ST_AsGeoJSON(geom)::json,
            'properties', json_build_object(
              'id_ranhgioi', id_ranhgioi,
              'ten_donvi', ten_donvi,
              'cap_hanhchinh', cap_hanhchinh
            )
          )
        )
      ) AS geojson
      FROM "ADMIN_BOUNDARIES";
    `;
    
    const [result] = await sequelize.query(query);
    
    if (!result || !result[0] || !result[0].geojson) {
      return res.json({ type: "FeatureCollection", features: [] });
    }

    res.json(result[0].geojson);
  } catch (error) {
    console.error('❌ Lỗi tại hàm getAdministrativeBoundaries:', error);
    res.status(500).json({ error: 'Lỗi hệ thống khi lấy ranh giới hành chính.' });
  }
};

module.exports = { getAdministrativeBoundaries };