const bcrypt = require('bcryptjs');
const db = require('../models/index');
const { sequelize } = db;

const seedUsers = async () => {
  try {
    const [result] = await sequelize.query('SELECT COUNT(*) AS count FROM "USERS"');
    if (parseInt(result[0].count, 10) === 0) {
      console.log('🔒 Đang tạo tài khoản bảo mật bằng Bcrypt...');
      
      const salt = await bcrypt.genSalt(10);
      const hashPassword = await bcrypt.hash('123456', salt);

      await sequelize.query(`
        INSERT INTO "USERS" (ten_dang_nhap, mat_khau_hash, vai_tro, "createdAt", "updatedAt") VALUES 
        ('superadmin', :hashPassword, 'admin', NOW(), NOW()),
        ('admin', :hashPassword, 'admin', NOW(), NOW()),
        ('analyst', :hashPassword, 'analyst', NOW(), NOW()),
        ('phantich', :hashPassword, 'analyst', NOW(), NOW()),
        ('user', :hashPassword, 'user', NOW(), NOW())
      `, { replacements: { hashPassword } });

      console.log('✅ Đã nạp các tài khoản mẫu (Mật khẩu chung: 123456).');
    }
  } catch (error) {
    console.error('❌ Lỗi khi nạp user:', error);
  }
};

module.exports = seedUsers;