const db = require('../models/index');
const { GridCell, AdminBoundary, sequelize } = db;

const seedGridCells = async () => {
  try {
    // 1. Kiểm tra xem đã có dữ liệu ô lưới chưa
    const count = await GridCell.count();
    if (count > 0) {
      console.log(`📌 Đã có ${count} ô lưới trong CSDL. Bỏ qua bước tạo ô lưới.`);
      return;
    }

    console.log('🌐 Đang tạo ô lưới không gian (GRID_CELLS) từ ranh giới hành chính...');
    
    // Lấy bounding box thực tế của tất cả các ranh giới hành chính trong CSDL
    const [bboxQuery] = await sequelize.query(`
      SELECT 
        MIN(ST_XMin(geom)) as min_lng, 
        MAX(ST_XMax(geom)) as max_lng, 
        MIN(ST_YMin(geom)) as min_lat, 
        MAX(ST_YMax(geom)) as max_lat 
      FROM "ADMIN_BOUNDARIES"
    `);
    
    const minLng = parseFloat(bboxQuery[0].min_lng);
    const maxLng = parseFloat(bboxQuery[0].max_lng);
    const minLat = parseFloat(bboxQuery[0].min_lat);
    const maxLat = parseFloat(bboxQuery[0].max_lat);
    
    if (isNaN(minLng) || isNaN(maxLng) || isNaN(minLat) || isNaN(maxLat)) {
      console.error('⚠️ Không tìm thấy tọa độ ranh giới hành chính để tạo lưới.');
      return;
    }

    console.log(`Bounding Box ranh giới: Lng[${minLng} - ${maxLng}], Lat[${minLat} - ${maxLat}]`);

    // Độ phân giải ô lưới: 0.02 độ (khoảng 2.2 km x 2.2 km) cho độ phủ mịn màng và đẹp mắt
    const step = 0.02;
    let createdCount = 0;

    for (let lng = minLng; lng < maxLng; lng += step) {
      for (let lat = minLat; lat < maxLat; lat += step) {
        // Tọa độ tâm ô lưới
        const centroidLat = lat + step / 2;
        const centroidLng = lng + step / 2;

        // Tìm xem ô lưới này có giao cắt (ST_Intersects) với ranh giới hành chính nào không
        const matchingBoundary = await sequelize.query(`
          SELECT id_ranhgioi 
          FROM "ADMIN_BOUNDARIES" 
          WHERE ST_Intersects(geom, ST_MakeEnvelope(:lng1, :lat1, :lng2, :lat2, 4326))
          LIMIT 1;
        `, {
          replacements: { 
            lng1: lng, 
            lat1: lat, 
            lng2: lng + step, 
            lat2: lat + step 
          },
          type: sequelize.QueryTypes.SELECT
        });

        if (matchingBoundary && matchingBoundary.length > 0) {
          const id_ranhgioi = matchingBoundary[0].id_ranhgioi;

          // Tạo đa giác hình học cho ô lưới (Polygon)
          const p1 = [lng, lat];
          const p2 = [lng + step, lat];
          const p3 = [lng + step, lat + step];
          const p4 = [lng, lat + step];
          const p5 = [lng, lat]; // Đóng đa giác

          const geom = {
            type: 'Polygon',
            coordinates: [[p1, p2, p3, p4, p5]]
          };

          await GridCell.create({
            id_ranhgioi,
            geom,
            tam_vi_do: centroidLat,
            tam_kinh_do: centroidLng,
            do_phan_giai: step
          });

          createdCount++;
        }
      }
    }

    console.log(`✅ Khởi tạo thành công ${createdCount} ô lưới không gian!`);
  } catch (error) {
    console.error('❌ Lỗi tạo ô lưới không gian:', error.message);
  }
};

module.exports = seedGridCells;
