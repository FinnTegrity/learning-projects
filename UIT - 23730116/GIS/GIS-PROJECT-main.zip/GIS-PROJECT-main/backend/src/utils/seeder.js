const db = require('../models/index');
const { sequelize } = db;

const seedLocations = async () => {
  try {
    const [locationResult] = await sequelize.query('SELECT COUNT(*) AS count FROM "LOCATIONS"');
    const locationCount = parseInt(locationResult[0].count, 10);

    const [boundaryResult] = await sequelize.query('SELECT COUNT(*) AS count FROM "ADMIN_BOUNDARIES"');
    const boundaryCount = parseInt(boundaryResult[0].count, 10);

    if (locationCount !== boundaryCount || locationCount === 0) {
      console.log('🧹 Đang dọn dẹp các trạm cũ...');
      await sequelize.query('TRUNCATE TABLE "LOCATIONS" RESTART IDENTITY CASCADE;');

      console.log(`📍 Tự động cắm ${boundaryCount} trạm quan trắc tại tâm xã/phường...`);

      const insertQuery = `
        INSERT INTO "LOCATIONS" (ten_khuvuc, vi_do, kinh_do, geom, id_ranhgioi, is_active, "createdAt", "updatedAt")
        SELECT 
          'Trạm ' || cap_hanhchinh || ' ' || ten_donvi,
          ST_Y(ST_Centroid(geom)) AS vi_do,
          ST_X(ST_Centroid(geom)) AS kinh_do,
          ST_Centroid(geom) AS geom,
          id_ranhgioi,
          true,
          NOW(),
          NOW()
        FROM "ADMIN_BOUNDARIES";
      `;

      await sequelize.query(insertQuery);
      console.log(`✅ Đã tái định vị thành công ${boundaryCount} trạm quan trắc tại trung tâm các xã/phường!`);
    } else {
      console.log('📌 Bảng LOCATIONS đã có đủ dữ liệu, bỏ qua bước nạp trạm.');
    }
  } catch (error) {
    console.error('❌ Lỗi khi nạp dữ liệu trạm quan trắc ảo:', error);
  }
};

module.exports = seedLocations;