const fs = require('fs');
const path = require('path');
const db = require('../models/index');
const { AdminBoundary, sequelize } = db;

const seedBoundaries = async () => {
  try {
    console.log('🧹 Đang dọn dẹp dữ liệu ranh giới cũ...');
    await sequelize.query('TRUNCATE TABLE "ADMIN_BOUNDARIES" RESTART IDENTITY CASCADE;');

    console.log('🗺️ Đang đọc file bản đồ mới...');
    const filePath = path.join(__dirname, '../data/hcmc.geojson');
    
    if (!fs.existsSync(filePath)) {
      console.error(`❌ Không tìm thấy file tại: ${filePath}`);
      return;
    }

    const rawData = fs.readFileSync(filePath, 'utf8');
    const geoJson = JSON.parse(rawData);
    
    // 👉 Lọc lấy các feature có thông tin xã/phường (ten_xa)
    const hcmcFeatures = geoJson.features.filter(
      feature => feature.properties && feature.properties.ten_xa
    );
    
    if (hcmcFeatures.length === 0) {
      console.error('❌ Không tìm thấy dữ liệu xã/phường trong file. Hãy kiểm tra lại định dạng!');
      return;
    }

    console.log(`📡 Tìm thấy ${hcmcFeatures.length} xã/phường thuộc HCMC. Đang nạp vào PostGIS...`);

    let successCount = 0;
    let failCount = 0;

    for (const feature of hcmcFeatures) {
      try {
        const ten_donvi = feature.properties.ten_xa || 'Xã/Phường';
        const cap_hanhchinh = feature.properties.loai || 'Xã/Phường';
        const geometryString = JSON.stringify(feature.geometry);

        await sequelize.query(`
          INSERT INTO "ADMIN_BOUNDARIES" (ten_donvi, cap_hanhchinh, geom, "createdAt", "updatedAt")
          VALUES (
            :ten_donvi, 
            :cap_hanhchinh, 
            ST_Multi(
              ST_CollectionExtract(
                ST_MakeValid(
                  ST_SetSRID(ST_GeomFromGeoJSON(:geometryString), 4326)
                ), 
                3
              )
            ), 
            NOW(), 
            NOW()
          )
        `, {
          replacements: { ten_donvi, cap_hanhchinh, geometryString }
        });
        
        successCount++;
      } catch (insertError) {
        console.error(`❌ Lỗi nạp [${feature.properties.ten_xa}]:`, insertError.message);
        failCount++;
      }
    }
    
    console.log(`✅ Hoàn tất! Thành công: ${successCount} | Thất bại: ${failCount}`);

  } catch (error) {
    console.error('❌ Lỗi tổng quan khi nạp dữ liệu:', error);
  }
};

module.exports = seedBoundaries;