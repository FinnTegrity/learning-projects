const { Op } = require('sequelize');
const db = require('../models/index');
const { GridCell, GridTimeValue, HourlyWeather, Location, SyncLog } = db;

// Calculate distance between two coordinates using the Haversine formula (in km)
const calculateDistance = (lat1, lon1, lat2, lon2) => {
  const R = 6371; // Earth radius in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
};

// IDW interpolation calculation
const interpolateIDW = (stations, targetLat, targetLng, metric, power = 2) => {
  let sumWeights = 0;
  let sumWeightedValues = 0;

  for (const station of stations) {
    const val = parseFloat(station[metric]);
    if (val === null || val === undefined || isNaN(val)) continue;

    const dist = calculateDistance(station.vi_do, station.kinh_do, targetLat, targetLng);
    
    // If the target point is exactly at the station location
    if (dist < 0.01) return val;

    const weight = 1 / Math.pow(dist, power);
    sumWeights += weight;
    sumWeightedValues += val * weight;
  }

  return sumWeights > 0 ? sumWeightedValues / sumWeights : null;
};

// Main function to run interpolation at a target time
const runIDWInterpolation = async (targetTime) => {
  try {
    const timeObj = targetTime ? new Date(targetTime) : new Date();

    // 1. Get the latest successful sync data source
    const latestLog = await SyncLog.findOne({
      where: { trang_thai: 'Thành công' },
      order: [['bat_dau_luc', 'DESC']]
    });
    const activeSource = latestLog ? latestLog.nguon_du_lieu : 'open_meteo';

    // 2. Fetch all weather data from active stations at the closest time
    const stations = await Location.findAll({
      where: { is_active: true },
      include: [{
        model: HourlyWeather,
        required: true,
        where: {
          thoi_gian: { [Op.lte]: timeObj },
          nguon_du_lieu: activeSource
        },
        order: [['thoi_gian', 'DESC']],
        limit: 1
      }]
    });

    if (stations.length === 0 || !stations[0].HOURLY_WEATHERs || stations[0].HOURLY_WEATHERs.length === 0) {
      return { success: false, message: 'Không tìm thấy dữ liệu trạm đo phù hợp để thực hiện nội suy.' };
    }

    const resolvedTime = stations[0].HOURLY_WEATHERs[0].thoi_gian;
    
    const stationsData = stations.map(s => {
      const w = s.HOURLY_WEATHERs[0];
      if (!w) return null;
      return {
        vi_do: parseFloat(s.vi_do),
        kinh_do: parseFloat(s.kinh_do),
        nhiet_do: w.nhiet_do ? parseFloat(w.nhiet_do) : null,
        do_am: w.do_am ? parseFloat(w.do_am) : null,
        luong_mua: w.luong_mua ? parseFloat(w.luong_mua) : 0
      };
    }).filter(Boolean);

    // 3. Get all grid cells
    const cells = await GridCell.findAll();
    if (cells.length === 0) {
      return { success: false, message: 'Chưa có ô lưới nào trong cơ sở dữ liệu. Hãy chạy seeder ô lưới trước.' };
    }

    const metrics = ['nhiet_do', 'do_am', 'luong_mua'];
    let count = 0;
    const recordsToUpsert = [];

    for (const cell of cells) {
      const lat = parseFloat(cell.tam_vi_do);
      const lng = parseFloat(cell.tam_kinh_do);

      // Perform interpolation for basic metrics
      const gridValues = {};
      for (const m of metrics) {
        const value = interpolateIDW(stationsData, lat, lng, m);
        if (value !== null) {
          gridValues[m] = value;
        }
      }

      // Calculate composite Thom index if we have temperature and humidity
      if (gridValues['nhiet_do'] !== undefined && gridValues['do_am'] !== undefined) {
        const T = gridValues['nhiet_do'];
        const R = gridValues['do_am'];
        gridValues['composite_index'] = T - 0.55 * (1 - 0.01 * R) * (T - 14.0);
      }

      // Save each value to the grid_time_values table
      for (const [m, value] of Object.entries(gridValues)) {
        let z_scaled = 0;
        if (m === 'nhiet_do') z_scaled = value * 0.003;
        else if (m === 'do_am') z_scaled = value * 0.0015;
        else if (m === 'luong_mua') z_scaled = Math.min(value * 0.015, 0.2);
        else if (m === 'composite_index') z_scaled = value * 0.003;

        recordsToUpsert.push({
          id_oluoi: cell.id_oluoi,
          thoi_gian: resolvedTime,
          bien_thoitiet: m,
          gia_tri: parseFloat(value.toFixed(3)),
          z_scaled: parseFloat(z_scaled.toFixed(3)),
          phuong_phap_suy_dien: 'IDW'
        });
        count++;
      }
    }

    if (recordsToUpsert.length > 0) {
      await GridTimeValue.bulkCreate(recordsToUpsert, {
        updateOnDuplicate: ['gia_tri', 'z_scaled', 'phuong_phap_suy_dien', 'updatedAt']
      });
    }

    return { success: true, message: `Nội suy không gian thành công cho ${cells.length} ô lưới tại mốc ${resolvedTime.toLocaleString('vi-VN')}.`, recordsCreated: count, thoi_gian: resolvedTime };
  } catch (err) {
    console.error('❌ Lỗi chạy IDW Interpolation:', err);
    return { success: false, error: err.message };
  }
};

module.exports = { runIDWInterpolation };
