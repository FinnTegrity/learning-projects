const { Op } = require('sequelize');
const db = require('../models/index');
const { HourlyWeather, DailyWeather, sequelize } = db;

const aggregateDailyWeather = async () => {
  try {
    console.log('🔄 Bắt đầu tiến trình tổng hợp dữ liệu ngày (UC04)...');
    
    // Lấy mốc thời gian của ngày hôm nay theo múi giờ Việt Nam (UTC+7)
    const today = new Date();
    const vnTime = new Date(today.getTime() + 7 * 60 * 60 * 1000);
    const y = vnTime.getUTCFullYear();
    const m = vnTime.getUTCMonth();
    const d = vnTime.getUTCDate();

    // Khởi tạo startOfDay và endOfDay theo múi giờ UTC+7 (quy đổi ngược về UTC trước khi truy vấn DB)
    const startOfDay = new Date(Date.UTC(y, m, d, 0, 0, 0, 0) - 7 * 60 * 60 * 1000);
    const endOfDay = new Date(Date.UTC(y, m, d, 23, 59, 59, 999) - 7 * 60 * 60 * 1000);
    const dateString = `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`; // Format: YYYY-MM-DD

    // Sử dụng sức mạnh của CSDL để tính Max, Min, Avg, Sum thay vì dùng vòng lặp JS
    const results = await HourlyWeather.findAll({
      attributes: [
        'id_diadiem',
        'nguon_du_lieu',
        [sequelize.fn('MAX', sequelize.col('nhiet_do')), 'nhiet_do_max'],
        [sequelize.fn('MIN', sequelize.col('nhiet_do')), 'nhiet_do_min'],
        [sequelize.fn('AVG', sequelize.col('nhiet_do')), 'nhiet_do_tb'],
        [sequelize.fn('SUM', sequelize.col('luong_mua')), 'tong_luong_mua'],
        [sequelize.fn('MAX', sequelize.col('toc_do_gio')), 'toc_do_gio_max']
      ],
      where: {
        thoi_gian: {
          [Op.between]: [startOfDay, endOfDay]
        }
      },
      group: ['id_diadiem', 'nguon_du_lieu']
    });

    if (results.length === 0) {
      console.log('⚠️ Không có dữ liệu giờ nào trong ngày để tổng hợp.');
      return;
    }

    // Đổ dữ liệu đã tính toán vào bảng DAILY_WEATHER
    const dailyPromises = results.map(row => {
      return DailyWeather.upsert({
        id_diadiem: row.id_diadiem,
        ngay_ghi_nhan: dateString,
        nhiet_do_max: parseFloat(row.getDataValue('nhiet_do_max')).toFixed(2),
        nhiet_do_min: parseFloat(row.getDataValue('nhiet_do_min')).toFixed(2),
        nhiet_do_tb: parseFloat(row.getDataValue('nhiet_do_tb')).toFixed(2),
        tong_luong_mua: parseFloat(row.getDataValue('tong_luong_mua')).toFixed(2),
        toc_do_gio_max: parseFloat(row.getDataValue('toc_do_gio_max')).toFixed(2),
        nguon_du_lieu: row.nguon_du_lieu
      });
    });

    await Promise.all(dailyPromises);
    console.log(`✅ Đã tổng hợp và lưu thành công thời tiết ngày ${dateString}!`);
  } catch (error) {
    console.error('❌ Lỗi khi chạy tiến trình tổng hợp ngày:', error);
  }
};

module.exports = { aggregateDailyWeather };