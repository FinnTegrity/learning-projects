const calculateSeasonalMA = (dataArray, windowDays = 14) => {
  const forecast = [];
  const n = dataArray.length;
  for (let i = 0; i < 24; i++) {
    let sum = 0, count = 0;
    for (let d = 1; d <= windowDays; d++) {
      const pastIndex = n - (d * 24) + i; 
      if (pastIndex >= 0 && dataArray[pastIndex] !== null) {
        sum += dataArray[pastIndex];
        count++;
      }
    }
    forecast.push(count > 0 ? sum / count : dataArray[n - 1]);
  }
  return forecast;
};

const calculateSeasonalLR = (dataArray, windowDays = 14) => {
  const forecast = [];
  const n = dataArray.length;
  for (let i = 0; i < 24; i++) {
    const y = [];
    for (let d = windowDays; d >= 1; d--) {
      const pastIndex = n - (d * 24) + i;
      if (pastIndex >= 0 && dataArray[pastIndex] !== null) y.push(dataArray[pastIndex]);
    }
    const len = y.length;
    if (len < 2) {
      forecast.push(y[y.length - 1] || dataArray[n - 1]);
      continue;
    }
    let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
    for (let j = 0; j < len; j++) {
      sumX += j; sumY += y[j]; sumXY += j * y[j]; sumX2 += j * j;
    }
    const m = (len * sumXY - sumX * sumY) / (len * sumX2 - sumX * sumX);
    const b = (sumY - m * sumX) / len;
    forecast.push(m * len + b);
  }
  return forecast;
};

const fitAndPredict = (series, params) => {
  const { phuongPhap, windowDays = 14 } = params;
  
  // Chạy mô hình dự báo tương lai
  let forecastArray = [];
  if (phuongPhap === 'linearRegression') forecastArray = calculateSeasonalLR(series, windowDays);
  else forecastArray = calculateSeasonalMA(series, windowDays);

  // Tính toán sai số mô hình (Metrics) bằng cách lấy 24h quá khứ làm tập Validation
  const validationSeries = series.slice(0, -24);
  const actualLast24h = series.slice(-24);
  let validationForecast = [];
  
  if (phuongPhap === 'linearRegression') validationForecast = calculateSeasonalLR(validationSeries, windowDays);
  else validationForecast = calculateSeasonalMA(validationSeries, windowDays);

  let mae = 0, rmse = 0, count = 0;
  for (let i = 0; i < 24; i++) {
    if (actualLast24h[i] != null && validationForecast[i] != null) {
      let diff = actualLast24h[i] - validationForecast[i];
      mae += Math.abs(diff);
      rmse += diff * diff;
      count++;
    }
  }

  const metrics = {
    mae: count > 0 ? parseFloat((mae / count).toFixed(2)) : 0,
    rmse: count > 0 ? parseFloat(Math.sqrt(rmse / count).toFixed(2)) : 0
  };

  return { forecastArray, metrics };
};

module.exports = { fitAndPredict };