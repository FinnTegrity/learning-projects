const sequelize = require('./src/config/db');

async function check() {
  try {
    await sequelize.authenticate();
    console.log('Database connected.');

    const logs = await sequelize.query('SELECT * FROM "DATA_CHANGE_LOG"', {
      type: sequelize.QueryTypes.SELECT
    });
    console.log('Data change logs:', logs);

    process.exit(0);
  } catch (error) {
    console.error('Error running check:', error);
    process.exit(1);
  }
}

check();
