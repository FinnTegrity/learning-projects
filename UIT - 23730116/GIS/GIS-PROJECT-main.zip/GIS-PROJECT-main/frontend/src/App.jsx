import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import WeatherMap from './components/Map/WeatherMap';
import AdminDashboard from './pages/Admin/Dashboard';

const AdminRoute = ({ children }) => {
  const savedUser = localStorage.getItem('gis_user');
  if (!savedUser) return <Navigate to="/" />;
  
  const user = JSON.parse(savedUser);
  if (user.role !== 'admin') return <Navigate to="/" />;
  
  return children;
};

function App() {
  return (
    <Router>
      <Routes>
        {/* Public Route */}
        <Route path="/" element={<WeatherMap />} />
        
        {/* Protected Route (Admin Only) */}
        <Route 
          path="/admin" 
          element={
            <AdminRoute>
              <AdminDashboard />
            </AdminRoute>
          } 
        />
      </Routes>
    </Router>
  );
}

export default App;