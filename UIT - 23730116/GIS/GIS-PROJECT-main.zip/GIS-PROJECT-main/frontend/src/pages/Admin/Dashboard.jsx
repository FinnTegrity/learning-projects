import { Users, Loader2, Map, MapPin, Settings, RefreshCw, Edit, Trash2, Plus, X, Clock, Cloud } from 'lucide-react';
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const AdminDashboard = () => {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem('gis_user'));
  const token = localStorage.getItem('gis_token');

  // Kiểm tra phân quyền admin
  useEffect(() => {
    if (!token || !user || user.role !== 'admin') {
      alert('Bạn không có quyền truy cập trang quản trị!');
      navigate('/');
    }
  }, [token, user, navigate]);

  // State quản lý tab và dữ liệu
  const [activeTab, setActiveTab] = useState('locations'); // 'locations' | 'users' | 'logs' | 'configs' | 'changelogs'
  const [loading, setLoading] = useState(false);
  const [locations, setLocations] = useState([]);
  const [users, setUsers] = useState([]);
  const [configs, setConfigs] = useState([]);
  const [logs, setLogs] = useState([]);
  const [changelogs, setChangelogs] = useState([]);
  const [weatherRecords, setWeatherRecords] = useState([]);
  const [latestSyncStatus, setLatestSyncStatus] = useState('Chưa rõ');
  const [latestSyncSource, setLatestSyncSource] = useState('');

  // State quản lý Modal/Form CRUD
  const [showModal, setShowModal] = useState(false);
  const [modalType, setModalType] = useState('add'); // 'add' | 'edit'
  const [selectedItem, setSelectedItem] = useState(null);

  // Form inputs cho Địa điểm (Locations)
  const [locForm, setLocForm] = useState({
    ten_khuvuc: '',
    vi_do: '',
    kinh_do: '',
    id_ranhgioi: '',
    mo_ta: '',
    is_active: true
  });

  // Form inputs cho Người dùng (Users)
  const [userForm, setUserForm] = useState({
    ten_dang_nhap: '',
    mat_khau: '',
    vai_tro: 'user',
    email: '',
    trang_thai: true
  });

  // Form inputs cho Cấu hình (SystemConfig)
  const [configForm, setConfigForm] = useState({
    khoa_cauhinh: '',
    gia_tri: '',
    mo_ta: ''
  });

  // Form inputs cho Thời tiết (HourlyWeather)
  const [weatherForm, setWeatherForm] = useState({
    id_diadiem: '',
    thoi_gian: '',
    nhiet_do: '',
    do_am: '',
    luong_mua: '',
    nguon_du_lieu: 'manual'
  });

  // Cấu hình headers cho axios
  const axiosConfig = {
    headers: { Authorization: `Bearer ${token}` }
  };

  // Hàm tải dữ liệu tùy thuộc vào tab đang active
  const fetchData = async () => {
    setLoading(true);
    try {
      if (activeTab === 'locations') {
        const res = await axios.get('http://localhost:5000/api/admin/locations', axiosConfig);
        setLocations(res.data);
      } else if (activeTab === 'users') {
        const res = await axios.get('http://localhost:5000/api/admin/users', axiosConfig);
        setUsers(res.data);
      } else if (activeTab === 'configs') {
        const res = await axios.get('http://localhost:5000/api/admin/config', axiosConfig);
        setConfigs(res.data);
      } else if (activeTab === 'logs') {
        const res = await axios.get('http://localhost:5000/api/admin/sync-logs', axiosConfig);
        setLogs(res.data);
      } else if (activeTab === 'changelogs') {
        const res = await axios.get('http://localhost:5000/api/admin/change-logs', axiosConfig);
        setChangelogs(res.data);
      } else if (activeTab === 'weather') {
        const res = await axios.get('http://localhost:5000/api/admin/weather', axiosConfig);
        setWeatherRecords(res.data);
        // Load locations for the dropdown
        const locRes = await axios.get('http://localhost:5000/api/admin/locations', axiosConfig);
        setLocations(locRes.data);
      }
    } catch (error) {
      console.error('Lỗi tải dữ liệu admin:', error);
      alert('Không thể tải dữ liệu, vui lòng đăng nhập lại.');
    } finally {
      setLoading(false);
    }
  };

  // Lấy trạng thái đồng bộ thời tiết mới nhất
  const fetchLatestSyncStatus = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/admin/sync-logs', axiosConfig);
      if (res.data && res.data.length > 0) {
        setLatestSyncStatus(res.data[0].trang_thai);
        setLatestSyncSource(res.data[0].nguon_du_lieu);
      }
    } catch (error) {
      console.error('Lỗi tải trạng thái đồng bộ:', error);
    }
  };

  useEffect(() => {
    if (token) {
      fetchData();
      fetchLatestSyncStatus();
    }
  }, [activeTab]);

  // Xử lý đăng xuất
  const handleLogout = () => {
    localStorage.removeItem('gis_token');
    localStorage.removeItem('gis_user');
    navigate('/');
  };

  // Kích hoạt đồng bộ thời tiết thủ công
  const handleTriggerSync = async () => {
    if (!window.confirm('Bạn có muốn kích hoạt đồng bộ dữ liệu thời tiết thủ công ngay lập tức không?')) return;
    setLoading(true);
    try {
      await axios.post('http://localhost:5000/api/weather/sync', {}, axiosConfig);
      alert('Đồng bộ dữ liệu thành công!');
      fetchData();
      fetchLatestSyncStatus();
    } catch (error) {
      alert('Đồng bộ thất bại: ' + (error.response?.data?.error || error.message));
      fetchLatestSyncStatus();
    } finally {
      setLoading(false);
    }
  };

  // Mở modal Thêm mới
  const openAddModal = () => {
    setModalType('add');
    setSelectedItem(null);
    if (activeTab === 'locations') {
      setLocForm({ ten_khuvuc: '', vi_do: '', kinh_do: '', id_ranhgioi: '', mo_ta: '', is_active: true });
    } else if (activeTab === 'users') {
      setUserForm({ ten_dang_nhap: '', mat_khau: '', vai_tro: 'user', email: '', trang_thai: true });
    } else if (activeTab === 'configs') {
      setConfigForm({ khoa_cauhinh: '', gia_tri: '', mo_ta: '' });
    } else if (activeTab === 'weather') {
      // Set default datetime to local time string matching HTML input format
      const now = new Date();
      now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
      const localStr = now.toISOString().slice(0, 16);
      
      setWeatherForm({
        id_diadiem: locations[0]?.id_diadiem || '',
        thoi_gian: localStr,
        nhiet_do: '27',
        do_am: '80',
        luong_mua: '0',
        nguon_du_lieu: 'manual'
      });
    }
    setShowModal(true);
  };

  // Mở modal Chỉnh sửa
  const openEditModal = (item) => {
    setModalType('edit');
    setSelectedItem(item);
    if (activeTab === 'locations') {
      setLocForm({
        ten_khuvuc: item.ten_khuvuc,
        vi_do: item.vi_do,
        kinh_do: item.kinh_do,
        id_ranhgioi: item.id_ranhgioi || '',
        mo_ta: item.mo_ta || '',
        is_active: item.is_active
      });
    } else if (activeTab === 'users') {
      setUserForm({
        ten_dang_nhap: item.ten_dang_nhap,
        mat_khau: '', // Không tải mật khẩu lên để bảo mật
        vai_tro: item.vai_tro,
        email: item.email || '',
        trang_thai: item.trang_thai
      });
    } else if (activeTab === 'configs') {
      setConfigForm({
        khoa_cauhinh: item.khoa_cauhinh,
        gia_tri: item.gia_tri,
        mo_ta: item.mo_ta || ''
      });
    } else if (activeTab === 'weather') {
      const formattedTime = item.thoi_gian ? new Date(item.thoi_gian).toISOString().slice(0, 16) : '';
      setWeatherForm({
        id_diadiem: item.id_diadiem,
        thoi_gian: formattedTime,
        nhiet_do: item.nhiet_do !== null && item.nhiet_do !== undefined ? item.nhiet_do : '',
        do_am: item.do_am !== null && item.do_am !== undefined ? item.do_am : '',
        luong_mua: item.luong_mua !== null && item.luong_mua !== undefined ? item.luong_mua : '',
        nguon_du_lieu: item.nguon_du_lieu || 'manual'
      });
    }
    setShowModal(true);
  };

  // Chạy nội suy IDW thủ công
  const handleManualInterpolation = async () => {
    const timeStr = window.prompt("Nhập thời gian chạy nội suy IDW (Định dạng: YYYY-MM-DD HH:mm:ss hoặc để trống để chạy cho giờ hiện tại):", new Date().toISOString().slice(0, 19).replace('T', ' '));
    if (timeStr === null) return;
    
    setLoading(true);
    try {
      const res = await axios.post('http://localhost:5000/api/admin/interpolate', { targetTime: timeStr || undefined }, axiosConfig);
      alert(`Nội suy IDW thành công!\nSố bản ghi được cập nhật: ${res.data.recordsCreated}\nThời gian: ${res.data.thoi_gian ? new Date(res.data.thoi_gian).toLocaleString('vi-VN') : 'Hiện tại'}`);
      fetchData();
    } catch (error) {
      alert('Chạy nội suy IDW thất bại: ' + (error.response?.data?.error || error.message));
    } finally {
      setLoading(false);
    }
  };

  // Gửi Form Thêm/Sửa lên Backend
  const handleSubmitForm = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (activeTab === 'locations') {
        if (modalType === 'add') {
          await axios.post('http://localhost:5000/api/admin/locations', locForm, axiosConfig);
        } else {
          await axios.put(`http://localhost:5000/api/admin/locations/${selectedItem.id_diadiem}`, locForm, axiosConfig);
        }
      } else if (activeTab === 'users') {
        if (modalType === 'add') {
          await axios.post('http://localhost:5000/api/admin/users', userForm, axiosConfig);
        } else {
          await axios.put(`http://localhost:5000/api/admin/users/${selectedItem.id_nguoidung}`, userForm, axiosConfig);
        }
      } else if (activeTab === 'configs') {
        if (modalType === 'add') {
          await axios.post('http://localhost:5000/api/admin/config', configForm, axiosConfig);
        } else {
          await axios.put(`http://localhost:5000/api/admin/config/${selectedItem.id_cauhinh}`, configForm, axiosConfig);
        }
      } else if (activeTab === 'weather') {
        if (modalType === 'add') {
          await axios.post('http://localhost:5000/api/admin/weather', weatherForm, axiosConfig);
        } else {
          await axios.put(`http://localhost:5000/api/admin/weather/${selectedItem.id_thoitietgio}`, weatherForm, axiosConfig);
        }
      }
      alert('Thành công!');
      setShowModal(false);
      fetchData();
    } catch (error) {
      alert('Thất bại: ' + (error.response?.data?.message || error.message));
    } finally {
      setLoading(false);
    }
  };

  // Xóa Phần tử (Delete)
  const handleDeleteItem = async (id) => {
    if (!window.confirm('Bạn có chắc chắn muốn xóa mục này?')) return;
    setLoading(true);
    try {
      if (activeTab === 'locations') {
        const res = await axios.delete(`http://localhost:5000/api/admin/locations/${id}`, axiosConfig);
        alert(res.data.message);
      } else if (activeTab === 'users') {
        await axios.delete(`http://localhost:5000/api/admin/users/${id}`, axiosConfig);
        alert('Xóa người dùng thành công!');
      } else if (activeTab === 'configs') {
        await axios.delete(`http://localhost:5000/api/admin/config/${id}`, axiosConfig);
        alert('Xóa cấu hình thành công!');
      } else if (activeTab === 'weather') {
        await axios.delete(`http://localhost:5000/api/admin/weather/${id}`, axiosConfig);
        alert('Xóa bản ghi thời tiết thành công!');
      }
      fetchData();
    } catch (error) {
      alert('Thất bại: ' + (error.response?.data?.message || error.message));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ display: 'flex', height: '100vh', width: '100vw', fontFamily: 'system-ui, -apple-system, sans-serif', background: '#1e272e', color: '#f5f6fa' }}>
      {/* Sidebar Admin */}
      <div style={{ width: '280px', background: '#2c3e50', color: 'white', padding: '25px 20px', display: 'flex', flexDirection: 'column', borderRight: '1px solid #0F2854' }}>
        <h2 style={{ margin: 0, display: 'flex', alignItems: 'center', gap: '10px', fontSize: '22px' }}>
          GIS Weather Admin
        </h2>
        <div style={{ margin: '15px 0', fontSize: '13px', background: 'rgba(255,255,255,0.05)', padding: '10px', borderRadius: '6px', borderLeft: '4px solid #f1c40f' }}>
          Tài khoản: <b>{user?.username}</b> ({user?.role})
        </div>
        <div style={{ margin: '10px 0 15px 0', fontSize: '13px', background: 'rgba(255,255,255,0.05)', padding: '10px', borderRadius: '6px', borderLeft: `4px solid ${latestSyncStatus === 'Thành công' ? '#27ae60' : '#e74c3c'}` }}>
          Trạng thái đồng bộ: <b style={{ color: latestSyncStatus === 'Thành công' ? '#27ae60' : '#e74c3c' }}>{latestSyncStatus}</b>
          {latestSyncSource && (
            <div style={{ fontSize: '11px', color: '#bdc3c7', marginTop: '4px' }}>
              Nguồn: <span style={{ textTransform: 'capitalize', color: '#f1c40f' }}>{latestSyncSource.replace('_', ' ')}</span>
            </div>
          )}
        </div>
        <hr style={{ borderColor: '#0F2854', width: '100%', marginBottom: '20px' }} />
        
        <ul style={{ listStyle: 'none', padding: 0, margin: 0, gap: '8px', display: 'flex', flexDirection: 'column' }}>
          <li 
            onClick={() => setActiveTab('locations')} 
            style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer', padding: '12px 15px', background: activeTab === 'locations' ? '#0F2854' : 'transparent', borderRadius: '6px', fontWeight: 'bold', fontSize: '14px', color: activeTab === 'locations' ? '#4988C4' : '#bdc3c7', transition: 'all 0.2s' }}
          >
             <MapPin size={18} /> Quản lý Trạm đo
          </li>
          <li 
            onClick={() => setActiveTab('weather')} 
            style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer', padding: '12px 15px', background: activeTab === 'weather' ? '#0F2854' : 'transparent', borderRadius: '6px', fontWeight: 'bold', fontSize: '14px', color: activeTab === 'weather' ? '#4988C4' : '#bdc3c7', transition: 'all 0.2s' }}
          >
             <Cloud size={18} /> Quản lý Thời tiết
          </li>
          <li 
            onClick={() => setActiveTab('users')} 
            style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer', padding: '12px 15px', background: activeTab === 'users' ? '#0F2854' : 'transparent', borderRadius: '6px', fontWeight: 'bold', fontSize: '14px', color: activeTab === 'users' ? '#4988C4' : '#bdc3c7', transition: 'all 0.2s' }}
          >
             <Users size={18} /> Quản lý Người dùng
          </li>
          <li 
            onClick={() => setActiveTab('configs')} 
            style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer', padding: '12px 15px', background: activeTab === 'configs' ? '#0F2854' : 'transparent', borderRadius: '6px', fontWeight: 'bold', fontSize: '14px', color: activeTab === 'configs' ? '#4988C4' : '#bdc3c7', transition: 'all 0.2s' }}
          >
            <Settings size={18} /> Cấu hình Hệ thống
          </li>
          <li 
            onClick={() => setActiveTab('logs')} 
            style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer', padding: '12px 15px', background: activeTab === 'logs' ? '#0F2854' : 'transparent', borderRadius: '6px', fontWeight: 'bold', fontSize: '14px', color: activeTab === 'logs' ? '#4988C4' : '#bdc3c7', transition: 'all 0.2s' }}
          >
            <RefreshCw size={18} /> Nhật ký Đồng bộ
          </li>
          <li 
            onClick={() => setActiveTab('changelogs')} 
            style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer', padding: '12px 15px', background: activeTab === 'changelogs' ? '#0F2854' : 'transparent', borderRadius: '6px', fontWeight: 'bold', fontSize: '14px', color: activeTab === 'changelogs' ? '#4988C4' : '#bdc3c7', transition: 'all 0.2s' }}
          >
            <Clock size={18} /> Vết Thay Đổi Dữ Liệu
          </li>
        </ul>

        <div style={{ marginTop: 'auto', display: 'flex', flexDirection: 'column', gap: '10px' }}>
          <button 
            onClick={handleTriggerSync}
            style={{ 
              width: '100%', 
              padding: '12px', 
              background: latestSyncStatus === 'Thành công' ? '#27ae60' : '#e67e22', 
              color: 'white', 
              border: 'none', 
              borderRadius: '6px', 
              cursor: 'pointer', 
              fontWeight: 'bold', 
              fontSize: '14px', 
              boxShadow: '0 2px 5px rgba(0,0,0,0.2)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '6px',
              transition: 'all 0.3s'
            }}
          >
            <RefreshCw size={14} className={loading ? 'animate-spin' : ''} /> Đồng bộ thời tiết
          </button>
          <button 
            onClick={() => navigate('/')} 
            style={{ width: '100%', padding: '10px', background: '#1C4D8D', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', fontSize: '13px', fontWeight: 'bold', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}
          >
             <Map size={18} /> Quay về Bản đồ
          </button>
          <button 
            onClick={handleLogout} 
            style={{ width: '100%', padding: '10px', background: '#e74c3c', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', fontSize: '13px', fontWeight: 'bold' }}
          >
            Đăng xuất
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div style={{ flex: 1, padding: '35px', overflowY: 'auto', background: '#1e272e' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '25px' }}>
          <h1 style={{ margin: 0, fontSize: '28px', display: 'flex', alignItems: 'center', gap: '10px' }}>
            {activeTab === 'locations' && <><MapPin size={18} /> Quản lý Trạm đo thời tiết</>}
            {activeTab === 'weather' && <><Cloud size={18} /> Quản lý Dữ liệu Thời tiết</>}
            {activeTab === 'users' && <><Users size={18} /> Quản lý Người dùng</>}
            {activeTab === 'configs' && <><Settings size={18} /> Cấu hình Hệ thống</>}
            {activeTab === 'logs' && <><RefreshCw size={18} /> Nhật ký Đồng bộ Dữ liệu</>}
            {activeTab === 'changelogs' && <><Clock size={18} /> Nhật ký Thay Đổi Dữ Liệu</>}
          </h1>
          {activeTab === 'weather' && (
            <div style={{ display: 'flex', gap: '10px' }}>
              <button 
                onClick={handleManualInterpolation}
                style={{ padding: '10px 20px', background: '#e67e22', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold', fontSize: '14px', boxShadow: '0 2px 5px rgba(0,0,0,0.2)', display: 'flex', alignItems: 'center', gap: '6px' }}
              >
                <RefreshCw size={14} /> Chạy Nội Suy IDW
              </button>
              <button 
                onClick={openAddModal}
                style={{ padding: '10px 20px', background: '#27ae60', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold', fontSize: '14px', boxShadow: '0 2px 5px rgba(0,0,0,0.2)' }}
              >
                <Plus size={14} /> Thêm Mới
              </button>
            </div>
          )}
          {activeTab !== 'logs' && activeTab !== 'changelogs' && activeTab !== 'weather' && (
            <button 
              onClick={openAddModal}
              style={{ padding: '10px 20px', background: '#27ae60', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold', fontSize: '14px', boxShadow: '0 2px 5px rgba(0,0,0,0.2)' }}
            >
              <Plus size={14} /> Thêm Mới
            </button>
          )}
        </div>

        {loading && <div style={{ fontSize: '18px', color: '#4988C4', margin: '20px 0' }}> <Loader2 size={18} className='animate-spin' /> Đang tải xử lý dữ liệu...</div>}

        {/* Tab 1: LOCATIONS TABLE */}
        {activeTab === 'locations' && (
          <table style={{ width: '100%', borderCollapse: 'collapse', background: '#2c3e50', borderRadius: '8px', overflow: 'hidden', fontSize: '14px', boxShadow: '0 4px 15px rgba(0,0,0,0.3)' }}>
            <thead>
              <tr style={{ background: '#0F2854', borderBottom: '2px solid #4a5568' }}>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>ID</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Tên Trạm</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Vĩ độ</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Kinh độ</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Ranh giới</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Mô tả</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Trạng thái</th>
                <th style={{ padding: '12px 15px', textAlign: 'center', whiteSpace: 'nowrap' }}>Hành động</th>
              </tr>
            </thead>
            <tbody>
              {locations.map((loc) => (
                <tr key={loc.id_diadiem} style={{ borderBottom: '1px solid #0F2854' }}>
                  <td style={{ padding: '12px 15px' }}>{loc.id_diadiem}</td>
                  <td style={{ padding: '12px 15px', fontWeight: 'bold' }}>{loc.ten_khuvuc}</td>
                  <td style={{ padding: '12px 15px', color: '#f1c40f' }}>{loc.vi_do}</td>
                  <td style={{ padding: '12px 15px', color: '#f1c40f' }}>{loc.kinh_do}</td>
                  <td style={{ padding: '12px 15px' }}>ID: {loc.id_ranhgioi || 'Trống'}</td>
                  <td style={{ padding: '12px 15px', color: '#bdc3c7' }}>{loc.mo_ta || 'Không có mô tả'}</td>
                  <td style={{ padding: '12px 15px' }}>
                    <span style={{ padding: '3px 8px', background: loc.is_active ? '#27ae60' : '#c0392b', borderRadius: '4px', fontSize: '12px' }}>
                      {loc.is_active ? 'Hoạt động' : 'Tạm dừng'}
                    </span>
                  </td>
                  <td style={{ padding: '12px 15px', textAlign: 'center' }}>
                    <button onClick={() => openEditModal(loc)} style={{ padding: '5px 10px', background: '#1C4D8D', border: 'none', color: 'white', borderRadius: '4px', marginRight: '5px', cursor: 'pointer' }}><Edit size={14} /> Sửa</button>
                    <button onClick={() => handleDeleteItem(loc.id_diadiem)} style={{ padding: '5px 10px', background: '#c0392b', border: 'none', color: 'white', borderRadius: '4px', cursor: 'pointer' }}><Trash2 size={14} /> Xóa</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {/* Tab 2: USERS TABLE */}
        {activeTab === 'users' && (
          <table style={{ width: '100%', borderCollapse: 'collapse', background: '#2c3e50', borderRadius: '8px', overflow: 'hidden', fontSize: '14px', boxShadow: '0 4px 15px rgba(0,0,0,0.3)' }}>
            <thead>
              <tr style={{ background: '#0F2854', borderBottom: '2px solid #4a5568' }}>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>ID</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Tên Đăng Nhập</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Vai Trò</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Email</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Trạng thái</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Ngày Tạo</th>
                <th style={{ padding: '12px 15px', textAlign: 'center', whiteSpace: 'nowrap' }}>Hành động</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id_nguoidung} style={{ borderBottom: '1px solid #0F2854' }}>
                  <td style={{ padding: '12px 15px' }}>{u.id_nguoidung}</td>
                  <td style={{ padding: '12px 15px', fontWeight: 'bold' }}>{u.ten_dang_nhap}</td>
                  <td style={{ padding: '12px 15px' }}>
                    <span style={{ padding: '3px 8px', background: u.vai_tro === 'admin' ? '#e74c3c' : u.vai_tro === 'analyst' ? '#9b59b6' : '#1C4D8D', borderRadius: '4px', fontSize: '12px' }}>
                      {u.vai_tro}
                    </span>
                  </td>
                  <td style={{ padding: '12px 15px' }}>{u.email || 'Trống'}</td>
                  <td style={{ padding: '12px 15px' }}>
                    <span style={{ padding: '3px 8px', background: u.trang_thai ? '#27ae60' : '#7f8c8d', borderRadius: '4px', fontSize: '12px' }}>
                      {u.trang_thai ? 'Hoạt động' : 'Bị Khóa'}
                    </span>
                  </td>
                  <td style={{ padding: '12px 15px' }}>{new Date(u.ngay_tao || u.createdAt).toLocaleString('vi-VN')}</td>
                  <td style={{ padding: '12px 15px', textAlign: 'center' }}>
                    <button onClick={() => openEditModal(u)} style={{ padding: '5px 10px', background: '#1C4D8D', border: 'none', color: 'white', borderRadius: '4px', marginRight: '5px', cursor: 'pointer' }}><Edit size={14} /> Sửa</button>
                    <button onClick={() => handleDeleteItem(u.id_nguoidung)} style={{ padding: '5px 10px', background: '#c0392b', border: 'none', color: 'white', borderRadius: '4px', cursor: 'pointer' }}><Trash2 size={14} /> Xóa</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {/* Tab 3: SYSTEM CONFIGS TABLE */}
        {activeTab === 'configs' && (
          <table style={{ width: '100%', borderCollapse: 'collapse', background: '#2c3e50', borderRadius: '8px', overflow: 'hidden', fontSize: '14px', boxShadow: '0 4px 15px rgba(0,0,0,0.3)' }}>
            <thead>
              <tr style={{ background: '#0F2854', borderBottom: '2px solid #4a5568' }}>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>ID</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Khóa Cấu Hình</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Giá Trị</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Mô Tả</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Cập Nhật Lúc</th>
                <th style={{ padding: '12px 15px', textAlign: 'center', whiteSpace: 'nowrap' }}>Hành động</th>
              </tr>
            </thead>
            <tbody>
              {configs.map((c) => (
                <tr key={c.id_cauhinh} style={{ borderBottom: '1px solid #0F2854' }}>
                  <td style={{ padding: '12px 15px' }}>{c.id_cauhinh}</td>
                  <td style={{ padding: '12px 15px', fontWeight: 'bold', color: '#4988C4' }}>{c.khoa_cauhinh}</td>
                  <td style={{ padding: '12px 15px', color: '#f1c40f', maxWidth: '300px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{c.gia_tri}</td>
                  <td style={{ padding: '12px 15px', color: '#bdc3c7' }}>{c.mo_ta || 'Không có mô tả'}</td>
                  <td style={{ padding: '12px 15px' }}>{new Date(c.cap_nhat_luc || c.updatedAt).toLocaleString('vi-VN')}</td>
                  <td style={{ padding: '12px 15px', textAlign: 'center' }}>
                    <button onClick={() => openEditModal(c)} style={{ padding: '5px 10px', background: '#1C4D8D', border: 'none', color: 'white', borderRadius: '4px', marginRight: '5px', cursor: 'pointer' }}><Edit size={14} /> Sửa</button>
                    <button onClick={() => handleDeleteItem(c.id_cauhinh)} style={{ padding: '5px 10px', background: '#c0392b', border: 'none', color: 'white', borderRadius: '4px', cursor: 'pointer' }}><Trash2 size={14} /> Xóa</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {/* Tab 4: SYNC LOGS TABLE */}
        {activeTab === 'logs' && (
          <table style={{ width: '100%', borderCollapse: 'collapse', background: '#2c3e50', borderRadius: '8px', overflow: 'hidden', fontSize: '14px', boxShadow: '0 4px 15px rgba(0,0,0,0.3)' }}>
            <thead>
              <tr style={{ background: '#0F2854', borderBottom: '2px solid #4a5568' }}>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>ID Log</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Bắt đầu</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Kết thúc</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Trạng thái</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Nguồn dữ liệu</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Số bản ghi</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Lỗi thông báo</th>
              </tr>
            </thead>
            <tbody>
              {logs.map((log) => (
                <tr key={log.id_log} style={{ borderBottom: '1px solid #0F2854' }}>
                  <td style={{ padding: '12px 15px' }}>{log.id_log}</td>
                  <td style={{ padding: '12px 15px' }}>{new Date(log.bat_dau_luc).toLocaleString('vi-VN')}</td>
                  <td style={{ padding: '12px 15px' }}>{log.ket_thuc_luc ? new Date(log.ket_thuc_luc).toLocaleString('vi-VN') : 'Đang xử lý'}</td>
                  <td style={{ padding: '12px 15px' }}>
                    <span style={{ padding: '3px 8px', background: log.trang_thai === 'Thành công' ? '#27ae60' : '#c0392b', borderRadius: '4px', fontSize: '12px' }}>
                      {log.trang_thai}
                    </span>
                  </td>
                  <td style={{ padding: '12px 15px', color: '#f1c40f', fontWeight: 'bold', textTransform: 'capitalize' }}>
                    {log.nguon_du_lieu ? log.nguon_du_lieu.replace('_', ' ') : 'N/A'}
                  </td>
                  <td style={{ padding: '12px 15px', color: '#4988C4', fontWeight: 'bold' }}>{log.so_ban_ghi} bản ghi</td>
                  <td style={{ padding: '12px 15px', color: '#e74c3c', fontSize: '12px' }}>{log.thong_bao_loi || 'Không có lỗi'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {/* Tab 1b: WEATHER DATA RECORDS TABLE */}
        {activeTab === 'weather' && (
          <table style={{ width: '100%', borderCollapse: 'collapse', background: '#2c3e50', borderRadius: '8px', overflow: 'hidden', fontSize: '14px', boxShadow: '0 4px 15px rgba(0,0,0,0.3)' }}>
            <thead>
              <tr style={{ background: '#0F2854', borderBottom: '2px solid #4a5568' }}>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>ID</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Trạm đo</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Thời gian</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Nhiệt độ (°C)</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Độ ẩm (%)</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Lượng mưa (mm)</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Nguồn dữ liệu</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', whiteSpace: 'nowrap' }}>Cập nhật lúc</th>
                <th style={{ padding: '12px 15px', textAlign: 'center', whiteSpace: 'nowrap' }}>Hành động</th>
              </tr>
            </thead>
            <tbody>
              {weatherRecords.map((w) => (
                <tr key={w.id_thoitietgio} style={{ borderBottom: '1px solid #0F2854' }}>
                  <td style={{ padding: '12px 15px' }}>{w.id_thoitietgio}</td>
                  <td style={{ padding: '12px 15px', fontWeight: 'bold' }}>{w.LOCATION?.ten_khuvuc || w.Location?.ten_khuvuc || `Trạm #${w.id_diadiem}`}</td>
                  <td style={{ padding: '12px 15px' }}>{new Date(w.thoi_gian).toLocaleString('vi-VN')}</td>
                  <td style={{ padding: '12px 15px', color: '#e74c3c', fontWeight: 'bold' }}>{w.nhiet_do !== null ? `${w.nhiet_do}°C` : 'N/A'}</td>
                  <td style={{ padding: '12px 15px', color: '#3498db' }}>{w.do_am !== null ? `${w.do_am}%` : 'N/A'}</td>
                  <td style={{ padding: '12px 15px', color: '#2ecc71' }}>{w.luong_mua !== null ? `${w.luong_mua} mm` : '0 mm'}</td>
                  <td style={{ padding: '12px 15px' }}>
                    <span style={{ padding: '3px 8px', background: w.nguon_du_lieu === 'open_meteo' ? '#16a085' : '#8e44ad', borderRadius: '4px', fontSize: '12px' }}>
                      {w.nguon_du_lieu}
                    </span>
                  </td>
                  <td style={{ padding: '12px 15px', color: '#bdc3c7' }}>{new Date(w.cap_nhat_luc || w.updatedAt).toLocaleString('vi-VN')}</td>
                  <td style={{ padding: '12px 15px', textAlign: 'center' }}>
                    <button onClick={() => openEditModal(w)} style={{ padding: '5px 10px', background: '#1C4D8D', border: 'none', color: 'white', borderRadius: '4px', marginRight: '5px', cursor: 'pointer' }}><Edit size={14} /> Sửa</button>
                    <button onClick={() => handleDeleteItem(w.id_thoitietgio)} style={{ padding: '5px 10px', background: '#c0392b', border: 'none', color: 'white', borderRadius: '4px', cursor: 'pointer' }}><Trash2 size={14} /> Xóa</button>
                  </td>
                </tr>
              ))}
              {weatherRecords.length === 0 && (
                <tr>
                  <td colSpan="9" style={{ padding: '20px', textAlign: 'center', color: '#bdc3c7' }}>Không tìm thấy dữ liệu thời tiết. Hãy nhấn nút đồng bộ hoặc thêm mới.</td>
                </tr>
              )}
            </tbody>
          </table>
        )}

        {/* Tab 5: CHANGE LOGS TABLE */}
        {activeTab === 'changelogs' && (
          <div style={{ background: '#2c3e50', padding: '20px', borderRadius: '8px', boxShadow: '0 4px 15px rgba(0,0,0,0.3)' }}>
            <h3 style={{ marginTop: 0, color: 'white' }}>Nhật ký thay đổi dữ liệu thời tiết (Data Change Log)</h3>
            <p style={{ color: '#bdc3c7', fontSize: '13px', marginBottom: '15px' }}>
              Hệ thống tự động theo dõi và ghi lại mọi thay đổi thủ công (Insert, Update, Delete) của người quản trị đối với cơ sở dữ liệu thời tiết.
            </p>
            <table style={{ width: '100%', borderCollapse: 'collapse', color: 'white', fontSize: '13px' }}>
              <thead>
                <tr style={{ borderBottom: '2px solid #34495e', textAlign: 'left', background: '#0F2854' }}>
                  <th style={{ padding: '10px 12px', whiteSpace: 'nowrap' }}>ID Log</th>
                  <th style={{ padding: '10px 12px', whiteSpace: 'nowrap' }}>Người sửa</th>
                  <th style={{ padding: '10px 12px', whiteSpace: 'nowrap' }}>Bảng bị tác động</th>
                  <th style={{ padding: '10px 12px', whiteSpace: 'nowrap' }}>ID Bản ghi</th>
                  <th style={{ padding: '10px 12px', whiteSpace: 'nowrap' }}>Thao tác</th>
                  <th style={{ padding: '10px 12px', whiteSpace: 'nowrap' }}>Giá trị cũ</th>
                  <th style={{ padding: '10px 12px', whiteSpace: 'nowrap' }}>Giá trị mới</th>
                  <th style={{ padding: '10px 12px', whiteSpace: 'nowrap' }}>Thời điểm</th>
                </tr>
              </thead>
              <tbody>
                {changelogs.map((log) => (
                  <tr key={log.id_thaydoi} style={{ borderBottom: '1px solid #0F2854' }}>
                    <td style={{ padding: '10px 12px' }}>{log.id_thaydoi}</td>
                    <td style={{ padding: '10px 12px' }}><b>{log.USER?.ten_dang_nhap || log.User?.ten_dang_nhap || 'System'}</b></td>
                    <td style={{ padding: '10px 12px' }}><code>{log.bang_du_lieu}</code></td>
                    <td style={{ padding: '10px 12px' }}>{log.id_ban_ghi}</td>
                    <td style={{ padding: '10px 12px' }}>
                      <span style={{
                        padding: '2px 6px',
                        borderRadius: '3px',
                        fontWeight: 'bold',
                        background: log.loai_thao_tac === 'INSERT' ? '#27ae60' : log.loai_thao_tac === 'UPDATE' ? '#f39c12' : '#e74c3c',
                        color: 'white',
                        fontSize: '11px'
                      }}>
                        {log.loai_thao_tac}
                      </span>
                    </td>
                    <td style={{ padding: '10px 12px' }}>
                      <pre style={{ margin: 0, fontSize: '11px', color: '#bdc3c7', maxWidth: '180px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {log.gia_tri_cu ? JSON.stringify(log.gia_tri_cu) : 'NULL'}
                      </pre>
                    </td>
                    <td style={{ padding: '10px 12px' }}>
                      <pre style={{ margin: 0, fontSize: '11px', color: '#2ecc71', maxWidth: '180px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {log.gia_tri_moi ? JSON.stringify(log.gia_tri_moi) : 'NULL'}
                      </pre>
                    </td>
                    <td style={{ padding: '10px 12px' }}>{new Date(log.thoi_gian).toLocaleString('vi-VN')}</td>
                  </tr>
                ))}
                {changelogs.length === 0 && (
                  <tr>
                    <td colSpan="8" style={{ padding: '20px', textAlign: 'center', color: '#bdc3c7' }}>Chưa có nhật ký thay đổi dữ liệu nào.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* CRUD MODAL FORM POPUP */}
        {showModal && (
          <div style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: 'rgba(0,0,0,0.85)', zIndex: 9999, display: 'flex', justifyContent: 'center', alignItems: 'center', backdropFilter: 'blur(4px)' }}>
            <div style={{ width: '90%', maxWidth: '500px', background: '#2c3e50', borderRadius: '10px', border: '1px solid #0F2854', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
              <div style={{ padding: '15px 20px', background: '#0F2854', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h3 style={{ margin: 0 }}>
                  {modalType === 'add' ? <><Plus size={14} /> Thêm mới</> : <><Edit size={14} /> Cập nhật</>} {activeTab === 'locations' ? 'Địa điểm' : activeTab === 'weather' ? 'Dữ liệu Thời tiết' : activeTab === 'users' ? 'Người dùng' : 'Cấu hình'}
                </h3>
                <span onClick={() => setShowModal(false)} style={{ cursor: 'pointer', color: '#e74c3c', display: 'flex', alignItems: 'center' }}><X size={18} /></span>
              </div>
              
              <form onSubmit={handleSubmitForm} style={{ padding: '20px', display: 'flex', flexDirection: 'column', gap: '15px' }}>
                {/* 1. LOCATIONS FORM */}
                {activeTab === 'locations' && (
                  <>
                    <div>
                      <label style={{ fontSize: '12px', color: '#bdc3c7', display: 'block', marginBottom: '5px' }}>Tên Trạm/Khu vực:</label>
                      <input required type="text" value={locForm.ten_khuvuc} onChange={(e) => setLocForm({...locForm, ten_khuvuc: e.target.value})} style={{ width: '95%', padding: '10px', background: '#1e272e', border: '1px solid #4a5568', color: 'white', borderRadius: '6px' }} />
                    </div>
                    <div style={{ display: 'flex', gap: '10px' }}>
                      <div style={{ flex: 1 }}>
                        <label style={{ fontSize: '12px', color: '#bdc3c7', display: 'block', marginBottom: '5px' }}>Vĩ độ (Latitude):</label>
                        <input required type="number" step="0.000001" value={locForm.vi_do} onChange={(e) => setLocForm({...locForm, vi_do: e.target.value})} style={{ width: '90%', padding: '10px', background: '#1e272e', border: '1px solid #4a5568', color: 'white', borderRadius: '6px' }} />
                      </div>
                      <div style={{ flex: 1 }}>
                        <label style={{ fontSize: '12px', color: '#bdc3c7', display: 'block', marginBottom: '5px' }}>Kinh độ (Longitude):</label>
                        <input required type="number" step="0.000001" value={locForm.kinh_do} onChange={(e) => setLocForm({...locForm, kinh_do: e.target.value})} style={{ width: '90%', padding: '10px', background: '#1e272e', border: '1px solid #4a5568', color: 'white', borderRadius: '6px' }} />
                      </div>
                    </div>
                    <div>
                      <label style={{ fontSize: '12px', color: '#bdc3c7', display: 'block', marginBottom: '5px' }}>ID Ranh giới Quận Huyện (Tùy chọn):</label>
                      <input type="number" value={locForm.id_ranhgioi} onChange={(e) => setLocForm({...locForm, id_ranhgioi: e.target.value})} style={{ width: '95%', padding: '10px', background: '#1e272e', border: '1px solid #4a5568', color: 'white', borderRadius: '6px' }} />
                    </div>
                    <div>
                      <label style={{ fontSize: '12px', color: '#bdc3c7', display: 'block', marginBottom: '5px' }}>Mô tả thêm:</label>
                      <textarea value={locForm.mo_ta} onChange={(e) => setLocForm({...locForm, mo_ta: e.target.value})} style={{ width: '95%', padding: '10px', background: '#1e272e', border: '1px solid #4a5568', color: 'white', borderRadius: '6px', height: '60px' }} />
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <input type="checkbox" checked={locForm.is_active} onChange={(e) => setLocForm({...locForm, is_active: e.target.checked})} style={{ transform: 'scale(1.2)' }} />
                      <label style={{ fontSize: '13px' }}>Hoạt động quan trắc</label>
                    </div>
                  </>
                )}

                {/* 2. USERS FORM */}
                {activeTab === 'users' && (
                  <>
                    <div>
                      <label style={{ fontSize: '12px', color: '#bdc3c7', display: 'block', marginBottom: '5px' }}>Tên đăng nhập:</label>
                      <input required disabled={modalType === 'edit'} type="text" value={userForm.ten_dang_nhap} onChange={(e) => setUserForm({...userForm, ten_dang_nhap: e.target.value})} style={{ width: '95%', padding: '10px', background: '#1e272e', border: '1px solid #4a5568', color: 'white', borderRadius: '6px' }} />
                    </div>
                    <div>
                      <label style={{ fontSize: '12px', color: '#bdc3c7', display: 'block', marginBottom: '5px' }}>Mật khẩu {modalType === 'edit' && '(Bỏ trống nếu không đổi)'}:</label>
                      <input required={modalType === 'add'} type="password" value={userForm.mat_khau} onChange={(e) => setUserForm({...userForm, mat_khau: e.target.value})} style={{ width: '95%', padding: '10px', background: '#1e272e', border: '1px solid #4a5568', color: 'white', borderRadius: '6px' }} />
                    </div>
                    <div>
                      <label style={{ fontSize: '12px', color: '#bdc3c7', display: 'block', marginBottom: '5px' }}>Vai trò phân quyền:</label>
                      <select value={userForm.vai_tro} onChange={(e) => setUserForm({...userForm, vai_tro: e.target.value})} style={{ width: '98%', padding: '10px', background: '#1e272e', border: '1px solid #4a5568', color: 'white', borderRadius: '6px' }}>
                        <option value="user">User (Người dùng công cộng)</option>
                        <option value="analyst">Analyst (Nhà phân tích khí tượng)</option>
                        <option value="admin">Admin (Quản trị viên hệ thống)</option>
                      </select>
                    </div>
                    <div>
                      <label style={{ fontSize: '12px', color: '#bdc3c7', display: 'block', marginBottom: '5px' }}>Email liên hệ:</label>
                      <input type="email" value={userForm.email} onChange={(e) => setUserForm({...userForm, email: e.target.value})} style={{ width: '95%', padding: '10px', background: '#1e272e', border: '1px solid #4a5568', color: 'white', borderRadius: '6px' }} />
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <input type="checkbox" checked={userForm.trang_thai} onChange={(e) => setUserForm({...userForm, trang_thai: e.target.checked})} style={{ transform: 'scale(1.2)' }} />
                      <label style={{ fontSize: '13px' }}>Trạng thái hoạt động</label>
                    </div>
                  </>
                )}

                {/* 3. SYSTEM CONFIGS FORM */}
                {activeTab === 'configs' && (
                  <>
                    <div>
                      <label style={{ fontSize: '12px', color: '#bdc3c7', display: 'block', marginBottom: '5px' }}>Khóa cấu hình (Unique Key):</label>
                      <input required disabled={modalType === 'edit'} type="text" value={configForm.khoa_cauhinh} onChange={(e) => setConfigForm({...configForm, khoa_cauhinh: e.target.value})} style={{ width: '95%', padding: '10px', background: '#1e272e', border: '1px solid #4a5568', color: 'white', borderRadius: '6px' }} />
                    </div>
                    <div>
                      <label style={{ fontSize: '12px', color: '#bdc3c7', display: 'block', marginBottom: '5px' }}>Giá trị cấu hình:</label>
                      <input required type="text" value={configForm.gia_tri} onChange={(e) => setConfigForm({...configForm, gia_tri: e.target.value})} style={{ width: '95%', padding: '10px', background: '#1e272e', border: '1px solid #4a5568', color: 'white', borderRadius: '6px' }} />
                    </div>
                    <div>
                      <label style={{ fontSize: '12px', color: '#bdc3c7', display: 'block', marginBottom: '5px' }}>Mô tả chức năng cấu hình:</label>
                      <textarea value={configForm.mo_ta} onChange={(e) => setConfigForm({...configForm, mo_ta: e.target.value})} style={{ width: '95%', padding: '10px', background: '#1e272e', border: '1px solid #4a5568', color: 'white', borderRadius: '6px', height: '65px' }} />
                    </div>
                  </>
                )}

                {/* 4. WEATHER DATA FORM */}
                {activeTab === 'weather' && (
                  <>
                    <div>
                      <label style={{ fontSize: '12px', color: '#bdc3c7', display: 'block', marginBottom: '5px' }}>Trạm đo thời tiết:</label>
                      <select required disabled={modalType === 'edit'} value={weatherForm.id_diadiem} onChange={(e) => setWeatherForm({...weatherForm, id_diadiem: e.target.value})} style={{ width: '98%', padding: '10px', background: '#1e272e', border: '1px solid #4a5568', color: 'white', borderRadius: '6px' }}>
                        {locations.map((loc) => (
                          <option key={loc.id_diadiem} value={loc.id_diadiem}>{loc.ten_khuvuc} (ID: {loc.id_diadiem})</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label style={{ fontSize: '12px', color: '#bdc3c7', display: 'block', marginBottom: '5px' }}>Thời gian ghi nhận:</label>
                      <input required disabled={modalType === 'edit'} type="datetime-local" value={weatherForm.thoi_gian} onChange={(e) => setWeatherForm({...weatherForm, thoi_gian: e.target.value})} style={{ width: '95%', padding: '10px', background: '#1e272e', border: '1px solid #4a5568', color: 'white', borderRadius: '6px' }} />
                    </div>
                    <div style={{ display: 'flex', gap: '10px' }}>
                      <div style={{ flex: 1 }}>
                        <label style={{ fontSize: '12px', color: '#bdc3c7', display: 'block', marginBottom: '5px' }}>Nhiệt độ (°C):</label>
                        <input required type="number" step="0.1" value={weatherForm.nhiet_do} onChange={(e) => setWeatherForm({...weatherForm, nhiet_do: e.target.value})} style={{ width: '90%', padding: '10px', background: '#1e272e', border: '1px solid #4a5568', color: 'white', borderRadius: '6px' }} />
                      </div>
                      <div style={{ flex: 1 }}>
                        <label style={{ fontSize: '12px', color: '#bdc3c7', display: 'block', marginBottom: '5px' }}>Độ ẩm (%):</label>
                        <input required type="number" min="0" max="100" value={weatherForm.do_am} onChange={(e) => setWeatherForm({...weatherForm, do_am: e.target.value})} style={{ width: '90%', padding: '10px', background: '#1e272e', border: '1px solid #4a5568', color: 'white', borderRadius: '6px' }} />
                      </div>
                    </div>
                    <div>
                      <label style={{ fontSize: '12px', color: '#bdc3c7', display: 'block', marginBottom: '5px' }}>Lượng mưa (mm):</label>
                      <input required type="number" step="0.1" min="0" value={weatherForm.luong_mua} onChange={(e) => setWeatherForm({...weatherForm, luong_mua: e.target.value})} style={{ width: '95%', padding: '10px', background: '#1e272e', border: '1px solid #4a5568', color: 'white', borderRadius: '6px' }} />
                    </div>
                    <div>
                      <label style={{ fontSize: '12px', color: '#bdc3c7', display: 'block', marginBottom: '5px' }}>Nguồn dữ liệu:</label>
                      <input required disabled type="text" value={weatherForm.nguon_du_lieu} style={{ width: '95%', padding: '10px', background: '#2c3e50', border: '1px solid #4a5568', color: '#bdc3c7', borderRadius: '6px' }} />
                    </div>
                  </>
                )}

                <div style={{ display: 'flex', gap: '10px', marginTop: '10px' }}>
                  <button type="submit" style={{ flex: 1, padding: '12px', background: '#27ae60', border: 'none', color: 'white', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold' }}>Gửi thông tin</button>
                  <button type="button" onClick={() => setShowModal(false)} style={{ flex: 1, padding: '12px', background: '#7f8c8d', border: 'none', color: 'white', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold' }}>Hủy bỏ</button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;