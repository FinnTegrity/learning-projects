import { useEffect } from 'react';
import { useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet.heat';

const HeatmapLayer = ({ data, metric }) => {
  const map = useMap();

  useEffect(() => {
    if (!data || !data.features) return;

    const points = data.features
      .map(feature => {
        const [lng, lat] = feature.geometry.coordinates;
        // Đảm bảo ép kiểu số thực, nếu không có dữ liệu thì mặc định bằng 0
        let intensity = parseFloat(feature.properties[metric]) || 0;
        return [lat, lng, intensity];
      })
      // 👉 LỌC BỎ RÁC: Chỉ những điểm có giá trị > 0 mới đưa vào mảng vẽ Heatmap
      .filter(p => p[2] > 0); 

    let gradientConfig = {};
    let maxValue = 1.0;

    if (metric === 'nhiet_do') {
      maxValue = 40; 
      gradientConfig = { 0.5: '#1C4D8D', 0.7: '#f1c40f', 0.85: '#e67e22', 1.0: '#e74c3c' }; 
    } else if (metric === 'do_am') {
      maxValue = 100; 
      gradientConfig = { 0.4: '#e0f7fa', 0.6: '#4988C4', 0.8: '#1C4D8D', 1.0: '#1C4D8D' }; 
    } else if (metric === 'luong_mua') {
      maxValue = 5; // Mưa > 5mm là chạm đỉnh màu tím đậm
      gradientConfig = { 0.1: '#95a5a6', 0.3: '#1C4D8D', 0.6: '#9b59b6', 1.0: '#8e44ad' }; 
    } else if (metric === 'composite_index') {
      maxValue = 35; 
      gradientConfig = { 0.5: '#2ecc71', 0.7: '#f1c40f', 0.85: '#e67e22', 1.0: '#e74c3c' }; 
    }

    const heatLayer = L.heatLayer(points, {
      radius: 45,      
      blur: 30,        
      maxZoom: 11,
      max: maxValue,
      gradient: gradientConfig
    }).addTo(map);

    return () => {
      map.removeLayer(heatLayer);
    };
  }, [map, data, metric]);

  return null;
};

export default HeatmapLayer;