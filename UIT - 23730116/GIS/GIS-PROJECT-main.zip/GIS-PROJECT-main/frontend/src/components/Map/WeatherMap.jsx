import { Building2, CloudSun, Map, Cloud, Clock, Play, Sun, Settings, Loader2, CloudRain, Thermometer, BarChart3, MapPin, Droplets, Flame, BookOpen, Smile, Gauge, Compass, Download, GitCompare, Wind, Calendar, CheckSquare, X, Grid } from 'lucide-react';
import React, { useEffect, useState } from "react";
import {
  MapContainer,
  TileLayer,
  CircleMarker,
  Tooltip,
  ZoomControl,
  GeoJSON,
  Polygon,
} from "react-leaflet";
import axios from "axios";
import WeatherChart from "../Charts/WeatherChart";
import AuthModal from "../Auth/AuthModal";
import HeatmapLayer from "./HeatmapLayer";
import * as turf from "@turf/turf";

const WeatherMap = () => {
  const [geoJsonData, setGeoJsonData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isRunningModel, setIsRunningModel] = useState(false);

  const [selectedLoc, setSelectedLoc] = useState(null);
  const [loadingChart, setLoadingChart] = useState(false);
  const [boundaryData, setBoundaryData] = useState(null);

  const [algoMethod, setAlgoMethod] = useState("movingAverage");
  const [selectedBienSo, setSelectedBienSo] = useState("nhiet_do");
  const [modelMetrics, setModelMetrics] = useState(null);

  const [historyData, setHistoryData] = useState([]);
  const [openMeteoData, setOpenMeteoData] = useState([]);
  const [forecastData, setForecastData] = useState([]);
  const [dailyData, setDailyData] = useState([]);

  const [currentUser, setCurrentUser] = useState(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showAnalystModal, setShowAnalystModal] = useState(false);
  const [showHistoryModal, setShowHistoryModal] = useState(false);

  const [viewMode, setViewMode] = useState("marker"); // 'marker' | 'heatmap' | 'choropleth' | '3d' | 'grid'
  const [gridGeoJson, setGridGeoJson] = useState(null);
  const [mapMetric, setMapMetric] = useState("nhiet_do");
  const [tempUnit, setTempUnit] = useState("C");

  // State hỗ trợ Time-Slider & So sánh trạm
  const [timeOffset, setTimeOffset] = useState(0);
  const [compareLoc, setCompareLoc] = useState(null);
  const [compareHistoryData, setCompareHistoryData] = useState([]);
  const [compareOpenMeteoData, setCompareOpenMeteoData] = useState([]);
  const [compareForecastData, setCompareForecastData] = useState([]);

  useEffect(() => {
    const savedUser = localStorage.getItem("gis_user");
    if (savedUser) setCurrentUser(JSON.parse(savedUser));
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("gis_token");
    localStorage.removeItem("gis_user");
    setCurrentUser(null);
  };

  // Lấy dữ liệu ranh giới hành chính một lần khi load trang
  useEffect(() => {
    axios
      .get("http://localhost:5000/api/map/boundaries")
      .then((res) => setBoundaryData(res.data))
      .catch((err) => console.error("Lỗi lấy ranh giới hành chính:", err));
  }, []);

  // Lấy dữ liệu thời tiết của các trạm theo timeOffset & tự động cập nhật thời gian thực (Polling)
  useEffect(() => {
    const fetchWeatherData = (isSilent = false) => {
      if (!isSilent) setLoading(true);
      const targetTime = new Date();
      targetTime.setHours(targetTime.getHours() + timeOffset);
      
      axios
        .get(`http://localhost:5000/api/map/weather?targetTime=${targetTime.toISOString()}`)
        .then((res) => {
          setGeoJsonData(res.data);
          if (!isSilent) setLoading(false);
        })
        .catch((err) => {
          console.error("Lỗi lấy dữ liệu thời tiết:", err);
          if (!isSilent) setLoading(false);
        });
    };

    const fetchGridData = () => {
      if (viewMode !== "grid") return; // Chỉ tải dữ liệu ô lưới khi chế độ Lưới nội suy đang hoạt động
      
      const targetTime = new Date();
      targetTime.setHours(targetTime.getHours() + timeOffset);
      
      axios
        .get(`http://localhost:5000/api/map/grid?targetTime=${targetTime.toISOString()}`)
        .then((res) => {
          setGridGeoJson(res.data);
        })
        .catch((err) => {
          console.error("Lỗi lấy dữ liệu ô lưới:", err);
        });
    };

    // Chạy debounce để tránh gọi API liên tục khi kéo thanh trượt (slider)
    const delayDebounce = setTimeout(() => {
      fetchWeatherData(false);
      fetchGridData();
    }, 200);

    // Thiết lập Polling tự động làm mới dữ liệu thời tiết mỗi 15 giây
    // Giúp cập nhật dữ liệu dần dần khi backend đang nạp và đồng bộ dữ liệu mới nhất
    const intervalId = setInterval(() => {
      fetchWeatherData(true); // silent fetch: cập nhật ngầm không hiển thị Spinner loading gây nhấp nháy
      fetchGridData();
    }, 15000);

    return () => {
      clearTimeout(delayDebounce);
      clearInterval(intervalId);
    };
  }, [timeOffset, viewMode]);

  const getUnit = (metric) => {
    if (metric === "nhiet_do") return tempUnit === "F" ? "°F" : "°C";
    if (metric === "do_am") return "%";
    if (metric === "luong_mua") return "mm";
    if (metric === "composite_index") return " Thom DI";
    return "";
  };

  const formatTemp = (celsiusValue) => {
    if (celsiusValue === null || celsiusValue === undefined) return "";
    const val = parseFloat(celsiusValue);
    if (tempUnit === "F") {
      return (val * 1.8 + 32).toFixed(1);
    }
    return val.toFixed(1);
  };

  const handleSelectCompareLocation = (locId) => {
    if (!locId) {
      setCompareLoc(null);
      setCompareHistoryData([]);
      setCompareOpenMeteoData([]);
      setCompareForecastData([]);
      return;
    }
    
    const targetLocFeature = geoJsonData.features.find(f => f.properties.id_diadiem === parseInt(locId));
    if (!targetLocFeature) return;
    
    setCompareLoc(targetLocFeature.properties);
    const clientTime = new Date().toISOString();
    
    axios
      .get(`http://localhost:5000/api/analytics/comparison/${locId}?clientTime=${clientTime}`)
      .then((res) => {
        setCompareHistoryData(res.data.history || []);
        setCompareOpenMeteoData(res.data.openMeteoForecast || []);
        setCompareForecastData(res.data.forecast || []);
      })
      .catch(() => {});
  };

  const render3DColumn = (lat, lng, value, metric) => {
    const val = parseFloat(value) || 0;
    if (val <= 0 && metric === 'luong_mua') return null;
    
    let H = 0;
    let colorBase = '#1C4D8D';
    if (metric === 'nhiet_do') {
      H = val * 0.003;
      if (val >= 32) colorBase = '#e74c3c';
      else if (val >= 30) colorBase = '#e67e22';
    } else if (metric === 'do_am') {
      H = val * 0.0015;
      colorBase = '#4988C4';
    } else if (metric === 'luong_mua') {
      H = Math.min(val * 0.015, 0.2);
      colorBase = '#9b59b6';
    } else if (metric === 'composite_index') {
      H = val * 0.003;
      if (val >= 29) colorBase = '#e74c3c';
      else if (val >= 24) colorBase = '#e67e22';
      else colorBase = '#2ecc71';
    }
    
    const dx = 0.003;
    const dy = 0.001;
    
    const p0 = [lat, lng - dx];
    const p1 = [lat - dy, lng];
    const p2 = [lat, lng + dx];
    
    const t0 = [lat + H, lng - dx];
    const t1 = [lat + H - dy, lng];
    const t2 = [lat + H, lng + dx];
    const t3 = [lat + H + dy, lng];
    
    let colorLeft = colorBase;
    let colorRight = colorBase;
    let colorTop = colorBase;
    
    if (colorBase === '#e74c3c') {
      colorLeft = '#c0392b'; colorRight = '#d9534f'; colorTop = '#ff6b6b';
    } else if (colorBase === '#e67e22') {
      colorLeft = '#d35400'; colorRight = '#f39c12'; colorTop = '#ffb03b';
    } else if (colorBase === '#1C4D8D') {
      colorLeft = '#1C4D8D'; colorRight = '#41a4e6'; colorTop = '#5dade2';
    } else if (colorBase === '#4988C4') {
      colorLeft = '#4988C4'; colorRight = '#26c2a3'; colorTop = '#48c9b0';
    } else if (colorBase === '#9b59b6') {
      colorLeft = '#8e44ad'; colorRight = '#af7ac5'; colorTop = '#c39bd3';
    } else if (colorBase === '#2ecc71') {
      colorLeft = '#27ae60'; colorRight = '#4cd137'; colorTop = '#2ecc71';
    }
    
    return (
      <React.Fragment key={`${lat}-${lng}-${metric}-3d`}>
        <Polygon positions={[p0, p1, t1, t0]} pathOptions={{ fillColor: colorLeft, fillOpacity: 0.85, color: '#2c3e50', weight: 1 }} />
        <Polygon positions={[p1, p2, t2, t1]} pathOptions={{ fillColor: colorRight, fillOpacity: 0.85, color: '#2c3e50', weight: 1 }} />
        <Polygon positions={[t0, t1, t2, t3]} pathOptions={{ fillColor: colorTop, fillOpacity: 0.95, color: '#2c3e50', weight: 1 }} />
      </React.Fragment>
    );
  };

  const handleMarkerClick = (featureProperties) => {
    setSelectedLoc(featureProperties);
    setShowAnalystModal(false);
    setModelMetrics(null);
    setCompareLoc(null);
    setCompareHistoryData([]);
    setCompareOpenMeteoData([]);
    setCompareForecastData([]);
    setLoadingChart(true);
    const clientTime = new Date().toISOString();

    axios
      .get(
        `http://localhost:5000/api/analytics/comparison/${featureProperties.id_diadiem}?clientTime=${clientTime}`,
      )
      .then((res) => {
        setHistoryData(res.data.history || []);
        setOpenMeteoData(res.data.openMeteoForecast || []);
        setForecastData(res.data.forecast || []);
        setDailyData(res.data.daily || []);
        setLoadingChart(false);
      })
      .catch(() => setLoadingChart(false));
  };

  const handleRunBaseline = async () => {
    if (!selectedLoc) return;
    setIsRunningModel(true);
    try {
      const clientTime = new Date().toISOString();
      const res = await axios.post(
        `http://localhost:5000/api/analytics/generate-forecast/${selectedLoc.id_diadiem}`,
        { bienSo: selectedBienSo, phuongPhap: algoMethod, clientTime },
      );
      const { chartData } = res.data;
      setHistoryData(chartData.history || []);
      setOpenMeteoData(chartData.openMeteoForecast || []);
      setForecastData(chartData.forecast || []);
      setModelMetrics(chartData.metrics);
      alert("Chạy mô hình thành công!");
    } catch (error) {
      alert("Lỗi: Không đủ dữ liệu lịch sử.");
    } finally {
      setIsRunningModel(false);
    }
  };

  const handleExportCSV = () => {
    if (!selectedLoc) return;
    const timeMap = new Map();
    const addData = (arr, prefix) => {
      arr.forEach((d) => {
        const t = new Date(d.thoi_gian || d.thoi_gian_dubao).toISOString();
        if (!timeMap.has(t))
          timeMap.set(t, { time: new Date(t).toLocaleString("vi-VN") });
        timeMap.get(t)[`${prefix}_T`] = d.nhiet_do || d.nhiet_do_dubao || "";
        timeMap.get(t)[`${prefix}_H`] = d.do_am || d.do_am_dubao || "";
        timeMap.get(t)[`${prefix}_R`] = d.luong_mua || d.luong_mua_dubao || 0;
      });
    };
    addData(historyData, "Real");
    addData(openMeteoData, "OM");
    addData(forecastData, "Base");
    const sortedTimes = Array.from(timeMap.keys()).sort();
    let csvContent =
      "Thoi_gian,Nhiet_do_Thuc_te,Do_am_Thuc_te,Mua_Thuc_te,Nhiet_do_OM,Do_am_OM,Mua_OM,Nhiet_do_Baseline,Do_am_Baseline\n";
    sortedTimes.forEach((t) => {
      const row = timeMap.get(t);
      csvContent += `"${row.time}",${row.Real_T},${row.Real_H},${row.Real_R},${row.OM_T},${row.OM_H},${row.OM_R},${row.Base_T},${row.Base_H}\n`;
    });
    const blob = new Blob(["\uFEFF" + csvContent], {
      type: "text/csv;charset=utf-8;",
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute(
      "download",
      `DuLieu_Tram_${selectedLoc.ten_khuvuc.replace(/\s+/g, "_")}.csv`,
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getWeatherCondition = (cloudCover, rain) => {
    if (rain > 0.5) return { icon: <CloudRain size={16} />, text: "Có mưa" };
    if (cloudCover > 70) return { icon: <Cloud size={16} />, text: "Nhiều mây" };
    if (cloudCover > 30) return { icon: <CloudSun size={16} />, text: "Có mây" };
    return { icon: <Sun size={16} />, text: "Trời nắng" };
  };

  const getColorByTemperature = (temp) => {
    if (!temp) return "#95a5a6";
    if (temp >= 32) return "#e74c3c";
    if (temp >= 30) return "#e67e22";
    return "#1C4D8D";
  };

  const generateWeeklyList = () => {
    const shortDays = ["Chủ nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy"];
    const list = [];
    const today = new Date();
    for (let i = -1; i <= 6; i++) {
      const targetDate = new Date();
      targetDate.setDate(today.getDate() + i);
      const dateStr = targetDate.toISOString().split("T")[0];
      let dayLabel =
        i === -1
          ? "Hôm qua"
          : i === 0
            ? "Hôm nay"
            : targetDate.getDay() === 0
              ? "Chủ Nhật"
              : shortDays[targetDate.getDay()];
      const dbMatch = dailyData.find((d) =>
        d.ngay_ghi_nhan.startsWith(dateStr),
      );
      let minTemp = dbMatch
        ? parseFloat(dbMatch.nhiet_do_min)
        : parseFloat(selectedLoc.nhiet_do) - 4 - i * 0.2;
      let maxTemp = dbMatch
        ? parseFloat(dbMatch.nhiet_do_max)
        : parseFloat(selectedLoc.nhiet_do) + 2 + i * 0.1;
      let humidity = dbMatch
        ? dbMatch.do_am_tb || 75
        : Math.floor(70 + Math.random() * 15);
      let rain = dbMatch
        ? parseFloat(dbMatch.tong_luong_mua)
        : i % 3 === 0
          ? 1.2
          : 0;
      list.push({
        label: dayLabel,
        humidity: Math.round(humidity),
        iconInfo: getWeatherCondition(rain > 0 ? 90 : 20, rain),
        maxTemp: Math.round(maxTemp),
        minTemp: Math.round(minTemp),
      });
    }
    return list;
  };

  const getChoroplethColor = (val, metric) => {
    if (val === null || val === undefined) return "transparent";
    if (metric === "nhiet_do") {
      return val >= 35
        ? "#c0392b"
        : val >= 33
          ? "#e74c3c"
          : val >= 31
            ? "#e67e22"
            : val >= 29
              ? "#f39c12"
              : "#f1c40f";
    } else if (metric === "do_am") {
      return val >= 90
        ? "#1C4D8D"
        : val >= 80
          ? "#1C4D8D"
          : val >= 70
            ? "#4988C4"
            : "#4988C4";
    } else if (metric === "luong_mua") {
      return val >= 50
        ? "#2c3e50"
        : val >= 20
          ? "#8e44ad"
          : val >= 5
            ? "#9b59b6"
            : val > 0
              ? "#1C4D8D"
              : "transparent";
    } else if (metric === "composite_index") {
      return val >= 32
        ? "#7f0800"
        : val >= 29
          ? "#e74c3c"
          : val >= 27
            ? "#e67e22"
            : val >= 24
              ? "#f39c12"
              : val >= 21
                ? "#2ecc71"
                : "#27ae60";
    }
    return "transparent";
  };

  const getDistrictValue = (feature, metric) => {
    if (
      !geoJsonData ||
      !geoJsonData.features ||
      geoJsonData.features.length === 0
    )
      return null;
    try {
      const centroid = turf.centroid(feature);
      let minDistance = Infinity;
      let nearestValue = null;

      geoJsonData.features.forEach((station) => {
        const distance = turf.distance(centroid, station);
        if (distance < minDistance) {
          minDistance = distance;
          nearestValue = station.properties[metric];
        }
      });
      return nearestValue;
    } catch (err) {
      return null;
    }
  };

  if (loading)
    return (
      <div style={{ textAlign: "center", padding: "20px" }}>
         { <Loader2 size={18} className='animate-spin' /> }  Đang tải bản đồ...
      </div>
    );

  return (
    <div
      style={{
        display: "flex",
        height: "100vh",
        width: "100vw",
        overflow: "hidden",
      }}
    >
      <div
        style={{
          flex: 1,
          height: "100%",
          position: "relative",
          transition: "all 0.3s",
          background: "#1e272e",
        }}
      >
        {/* Header Map */}
        <div
          style={{
            padding: "10px 15px",
            background: "#2c3e50",
            color: "white",
            position: "absolute",
            top: "10px",
            left: "10px",
            zIndex: 1000,
            borderRadius: "4px",
            display: "flex",
            alignItems: "center",
            gap: "15px",
            boxShadow: "0 2px 10px rgba(0,0,0,0.2)",
          }}
        >
          <h4 style={{ margin: 0 }}>Hệ Thống GIS Thời Tiết HCMC</h4>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', borderLeft: '1px solid #7f8c8d', paddingLeft: '15px' }}>
            <span style={{ fontSize: '13px', color: '#bdc3c7' }}>Đơn vị:</span>
            <button
              onClick={() => setTempUnit('C')}
              style={{
                background: tempUnit === 'C' ? '#e74c3c' : '#34495e',
                color: 'white',
                border: 'none',
                padding: '3px 8px',
                borderRadius: '4px',
                cursor: 'pointer',
                fontWeight: 'bold',
                fontSize: '12px',
                transition: 'all 0.2s'
              }}
            >
              °C
            </button>
            <button
              onClick={() => setTempUnit('F')}
              style={{
                background: tempUnit === 'F' ? '#e74c3c' : '#34495e',
                color: 'white',
                border: 'none',
                padding: '3px 8px',
                borderRadius: '4px',
                cursor: 'pointer',
                fontWeight: 'bold',
                fontSize: '12px',
                transition: 'all 0.2s'
              }}
            >
              °F
            </button>
          </div>
          <div style={{ borderLeft: "1px solid #7f8c8d", paddingLeft: "15px" }}>
            {currentUser ? (
              <span
                style={{
                  fontSize: "14px",
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                }}
              >
                <span>
                  Chào, <b>{currentUser.username}</b> ({currentUser.role})
                </span>
                {currentUser.role === "admin" && (
                  <button
                    onClick={() => (window.location.href = "/admin")}
                    style={{
                      background: "#f39c12",
                      border: "none",
                      color: "white",
                      padding: "2px 8px",
                      borderRadius: "3px",
                      cursor: "pointer",
                    }}
                  >
                    Trang Quản Trị
                  </button>
                )}
                <span
                  onClick={handleLogout}
                  style={{
                    color: "#e74c3c",
                    cursor: "pointer",
                    fontWeight: "bold",
                  }}
                >
                  Thoát
                </span>
              </span>
            ) : (
              <button
                onClick={() => setShowAuthModal(true)}
                style={{
                  background: "#1C4D8D",
                  color: "white",
                  border: "none",
                  padding: "4px 10px",
                  borderRadius: "3px",
                  cursor: "pointer",
                }}
              >
                Đăng Nhập
              </button>
            )}
          </div>
        </div>

        {/* Control Panel */}
        <div
          style={{
            position: "absolute",
            top: "10px",
            right: "10px",
            zIndex: 1000,
            display: "flex",
            flexDirection: "column",
            gap: "10px",
          }}
        >
          <div
            style={{
              background: "#2c3e50",
              borderRadius: "6px",
              overflow: "hidden",
              display: "flex",
              boxShadow: "0 2px 10px rgba(0,0,0,0.3)",
            }}
          >
            <button
              onClick={() => setViewMode("marker")}
              style={{
                flex: 1,
                minWidth: "75px",
                padding: "8px 10px",
                border: "none",
                background: viewMode === "marker" ? "#1C4D8D" : "transparent",
                color: viewMode === "marker" ? "white" : "#bdc3c7",
                cursor: "pointer",
                fontWeight: "bold",
                fontSize: "11px",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                gap: "6px",
                whiteSpace: "nowrap",
              }}
            >
              <MapPin size={18} />
              <span>Points</span>
            </button>
            <button
              onClick={() => setViewMode("heatmap")}
              style={{
                flex: 1,
                minWidth: "75px",
                padding: "8px 10px",
                border: "none",
                background: viewMode === "heatmap" ? "#e74c3c" : "transparent",
                color: viewMode === "heatmap" ? "white" : "#bdc3c7",
                cursor: "pointer",
                fontWeight: "bold",
                fontSize: "11px",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                gap: "6px",
                whiteSpace: "nowrap",
              }}
            >
              <Flame size={18} />
              <span>Heatmap</span>
            </button>
            <button
              onClick={() => setViewMode("choropleth")}
              style={{
                flex: 1,
                minWidth: "75px",
                padding: "8px 10px",
                border: "none",
                background:
                  viewMode === "choropleth" ? "#9b59b6" : "transparent",
                color: viewMode === "choropleth" ? "white" : "#bdc3c7",
                cursor: "pointer",
                fontWeight: "bold",
                fontSize: "11px",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                gap: "6px",
                whiteSpace: "nowrap",
              }}
            >
              <Map size={18} />
              <span>Phân vùng</span>
            </button>
            <button
              onClick={() => setViewMode("3d")}
              style={{
                flex: 1,
                minWidth: "75px",
                padding: "8px 10px",
                border: "none",
                background: viewMode === "3d" ? "#4988C4" : "transparent",
                color: viewMode === "3d" ? "white" : "#bdc3c7",
                cursor: "pointer",
                fontWeight: "bold",
                fontSize: "11px",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                gap: "6px",
                whiteSpace: "nowrap",
              }}
            >
              <Building2 size={18} />
              <span>3D Bar</span>
            </button>
            <button
              onClick={() => setViewMode("grid")}
              style={{
                flex: 1,
                minWidth: "75px",
                padding: "8px 10px",
                border: "none",
                background: viewMode === "grid" ? "#f39c12" : "transparent",
                color: viewMode === "grid" ? "white" : "#bdc3c7",
                cursor: "pointer",
                fontWeight: "bold",
                fontSize: "11px",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                gap: "6px",
                whiteSpace: "nowrap",
              }}
            >
              <Grid size={18} />
              <span>Lưới nội suy</span>
            </button>
          </div>

          {(viewMode === "heatmap" || viewMode === "choropleth" || viewMode === "3d" || viewMode === "grid") && (
            <div
              style={{
                background: "#2c3e50",
                borderRadius: "6px",
                overflow: "hidden",
                display: "flex",
                boxShadow: "0 2px 10px rgba(0,0,0,0.3)",
              }}
            >
              <button
                onClick={() => setMapMetric("nhiet_do")}
                style={{
                  flex: 1,
                  minWidth: "75px",
                  padding: "8px 10px",
                  border: "none",
                  background:
                    mapMetric === "nhiet_do" ? "#e67e22" : "transparent",
                  color: mapMetric === "nhiet_do" ? "white" : "#bdc3c7",
                  cursor: "pointer",
                  fontWeight: "bold",
                  fontSize: "11px",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: "6px",
                  whiteSpace: "nowrap",
                }}
              >
                <Thermometer size={16} />
                <span>Nhiệt độ</span>
              </button>
              <button
                onClick={() => setMapMetric("do_am")}
                style={{
                  flex: 1,
                  minWidth: "75px",
                  padding: "8px 10px",
                  border: "none",
                  background: mapMetric === "do_am" ? "#1C4D8D" : "transparent",
                  color: mapMetric === "do_am" ? "white" : "#bdc3c7",
                  cursor: "pointer",
                  fontWeight: "bold",
                  fontSize: "11px",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: "6px",
                  whiteSpace: "nowrap",
                }}
              >
                <Droplets size={16} />
                <span>Độ ẩm</span>
              </button>
              <button
                onClick={() => setMapMetric("luong_mua")}
                style={{
                  flex: 1,
                  minWidth: "75px",
                  padding: "8px 10px",
                  border: "none",
                  background:
                    mapMetric === "luong_mua" ? "#9b59b6" : "transparent",
                  color: mapMetric === "luong_mua" ? "white" : "#bdc3c7",
                  cursor: "pointer",
                  fontWeight: "bold",
                  fontSize: "11px",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: "6px",
                  whiteSpace: "nowrap",
                }}
              >
                <CloudRain size={16} />
                <span>Lượng mưa</span>
              </button>
              <button
                onClick={() => setMapMetric("composite_index")}
                style={{
                  flex: 1,
                  minWidth: "75px",
                  padding: "8px 10px",
                  border: "none",
                  background:
                    mapMetric === "composite_index" ? "#2ecc71" : "transparent",
                  color: mapMetric === "composite_index" ? "white" : "#bdc3c7",
                  cursor: "pointer",
                  fontWeight: "bold",
                  fontSize: "11px",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: "6px",
                  whiteSpace: "nowrap",
                }}
              >
                <Smile size={18} />
                <span>Tiện nghi</span>
              </button>
            </div>
          )}
        </div>

        {showAuthModal && (
          <AuthModal
            onClose={() => setShowAuthModal(false)}
            onLoginSuccess={(user) => {
              setCurrentUser(user);
              setShowAuthModal(false);
            }}
          />
        )}

        <MapContainer
          center={[10.8231, 106.6297]}
          zoom={11}
          style={{ height: "100%", width: "100%" }}
          zoomControl={false}
        >
          <ZoomControl position="bottomright" />
          <TileLayer
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            className="map-tiles"
          />
          <style>{`.map-tiles { filter: brightness(0.6) invert(1) contrast(3) hue-rotate(200deg) saturate(0.3) brightness(0.7); }`}</style>

          {/* 👉 GEOJSON LAYER SẠCH SẼ: CHỈ CÓ HIỆU ỨNG HOVER, KHÔNG BỊ GHIM CLICK */}
          {boundaryData && (
            <GeoJSON
              key={`${viewMode}-${mapMetric}`}
              data={boundaryData}
              style={(feature) => {
                if (viewMode === "choropleth") {
                  const val = getDistrictValue(feature, mapMetric);
                  return {
                    fillColor: getChoroplethColor(val, mapMetric),
                    fillOpacity: 0.65,
                    color: "#2c3e50",
                    weight: 1.5,
                    dashArray: "3",
                  };
                }
                return {
                  fillColor: "transparent",
                  color: "#1C4D8D",
                  weight: 2,
                  dashArray: "5, 5",
                };
              }}
              onEachFeature={(feature, layer) => {
                const displayName = feature.properties.cap_hanhchinh
                  ? `${feature.properties.cap_hanhchinh} ${feature.properties.ten_donvi}`
                  : (feature.properties.NAME_2 || feature.properties.ten_donvi);
                let tooltipContent = `<b>${displayName}</b>`;
                if (viewMode === "choropleth") {
                  const val = getDistrictValue(feature, mapMetric);
                  let valStr = "N/A";
                  if (val !== null) {
                    if (mapMetric === "nhiet_do") {
                      valStr = tempUnit === "F" ? (parseFloat(val) * 1.8 + 32).toFixed(1) : parseFloat(val).toFixed(1);
                    } else {
                      valStr = parseFloat(val).toFixed(1);
                    }
                  }
                  const unit =
                    mapMetric === "nhiet_do"
                      ? (tempUnit === "F" ? "°F" : "°C")
                      : mapMetric === "do_am"
                        ? "%"
                        : mapMetric === "luong_mua"
                          ? "mm"
                          : " Thom DI";
                  tooltipContent += `<br/>Dữ liệu: <b style="color:#e74c3c;">${valStr}${unit}</b>`;
                }
                layer.bindTooltip(tooltipContent, { sticky: true });

                layer.on({
                  mouseover: (e) => {
                    const l = e.target;
                    l.setStyle({ weight: 3.5, color: "#f1c40f" }); // Hover đổi viền vàng cực pro
                  },
                  mouseout: (e) => {
                    // Di chuột ra phát trả lại style gốc của Mode đó ngay lập tức
                    e.target.setStyle({
                      weight: viewMode === "choropleth" ? 1.5 : 2,
                      color: viewMode === "choropleth" ? "#2c3e50" : "#1C4D8D",
                      dashArray: viewMode === "choropleth" ? "3" : "5, 5",
                    });
                  },
                  // 🔥 ĐÃ XÓA SỰ KIỆN click TẠI ĐÂY - Giải phóng hoàn toàn click cho bản đồ nền!
                });
              }}
            />
          )}

          {/* 👉 MARKER LAYER: NẰM GỌN TRÊN PANE ĐỘC QUYỀN, CLICK PHÁT ĂN NGAY */}
          {viewMode === "marker" &&
            geoJsonData &&
            geoJsonData.features.map((feature, index) => (
              <CircleMarker
                key={index}
                center={[
                  feature.geometry.coordinates[1],
                  feature.geometry.coordinates[0],
                ]}
                radius={14}
                pane="markerPane"
                pathOptions={{
                  fillColor: getColorByTemperature(feature.properties.nhiet_do),
                  fillOpacity: 0.8,
                  color:
                    selectedLoc?.id_diadiem === feature.properties.id_diadiem
                      ? "#000"
                      : "#fff",
                  weight:
                    selectedLoc?.id_diadiem === feature.properties.id_diadiem
                      ? 3
                      : 2,
                }}
                eventHandlers={{
                  click: () => handleMarkerClick(feature.properties),
                }}
              >
                <Tooltip permanent direction="top" offset={[0, -10]}>
                  <b>{formatTemp(feature.properties.nhiet_do)}{tempUnit === "F" ? "°F" : "°C"}</b>
                </Tooltip>
              </CircleMarker>
            ))}

          {/* 👉 3D / 2.5D COLUMN LAYER */}
          {viewMode === "3d" &&
            geoJsonData &&
            geoJsonData.features.map((feature, index) => {
              const lat = feature.geometry.coordinates[1];
              const lng = feature.geometry.coordinates[0];
              const val = feature.properties[mapMetric];
              
              return (
                <React.Fragment key={index}>
                  {render3DColumn(lat, lng, val, mapMetric)}
                  <CircleMarker
                    center={[lat, lng]}
                    radius={6}
                    pathOptions={{
                      fillColor: '#fff',
                      fillOpacity: 0.9,
                      color: '#000',
                      weight: 1.5
                    }}
                    eventHandlers={{
                      click: () => handleMarkerClick(feature.properties),
                    }}
                  >
                    <Tooltip permanent direction="top" offset={[0, -5]}>
                      <b>
                        {feature.properties.ten_khuvuc}: {val !== null ? `${val}${getUnit(mapMetric)}` : 'N/A'}
                      </b>
                    </Tooltip>
                  </CircleMarker>
                </React.Fragment>
              );
            })}

          {viewMode === "heatmap" && geoJsonData && (
            <HeatmapLayer data={geoJsonData} metric={mapMetric} />
          )}

          {/* 👉 LỚP Ô LƯỚI NỘI SUY IDW ĐỊA LÝ */}
          {viewMode === "grid" && gridGeoJson && (
            <GeoJSON
              key={`grid-${mapMetric}-${timeOffset}`}
              data={gridGeoJson}
              style={(feature) => {
                const val = feature.properties[mapMetric];
                return {
                  fillColor: getChoroplethColor(val, mapMetric),
                  fillOpacity: 0.65,
                  color: "#34495e",
                  weight: 1,
                };
              }}
              onEachFeature={(feature, layer) => {
                const id_oluoi = feature.properties.id_oluoi;
                const val = feature.properties[mapMetric];
                let valStr = "N/A";
                if (val !== null) {
                  if (mapMetric === "nhiet_do") {
                    valStr = tempUnit === "F" ? (parseFloat(val) * 1.8 + 32).toFixed(1) : parseFloat(val).toFixed(1);
                  } else {
                    valStr = parseFloat(val).toFixed(1);
                  }
                }
                const unit =
                  mapMetric === "nhiet_do"
                    ? (tempUnit === "F" ? "°F" : "°C")
                    : mapMetric === "do_am"
                      ? "%"
                      : mapMetric === "luong_mua"
                        ? "mm"
                        : " Thom DI";
                
                let tooltipContent = `<b>Ô lưới ID: ${id_oluoi}</b><br/>Tâm: [${feature.properties.tam_vi_do}, ${feature.properties.tam_kinh_do}]<br/>Giá trị nội suy IDW: <b style="color:#f1c40f;">${valStr}${unit}</b>`;
                layer.bindTooltip(tooltipContent, { sticky: true });

                layer.on({
                  mouseover: (e) => {
                    e.target.setStyle({ weight: 2.5, color: "#f1c40f", fillOpacity: 0.8 });
                  },
                  mouseout: (e) => {
                    e.target.setStyle({
                      weight: 1,
                      color: "#34495e",
                      fillOpacity: 0.65,
                    });
                  }
                });
              }}
            />
          )}
        </MapContainer>

        {/* Thanh trượt thời gian (Time-Slider) */}
        <div
          style={{
            position: "absolute",
            bottom: "30px",
            left: "50%",
            transform: "translateX(-50%)",
            zIndex: 1000,
            background: "rgba(44, 62, 80, 0.95)",
            padding: "15px 25px",
            borderRadius: "10px",
            boxShadow: "0 4px 15px rgba(0,0,0,0.5)",
            border: "1px solid #0F2854",
            width: "90%",
            maxWidth: "600px",
            display: "flex",
            flexDirection: "column",
            gap: "10px",
            backdropFilter: "blur(5px)",
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              color: "white",
              fontSize: "13px",
            }}
          >
            <span style={{ fontWeight: "bold", color: "#4988C4", display: "inline-flex", alignItems: "center", gap: "6px" }}>
              <Clock size={14} /> <span>Trục Thời Gian (24h Lịch sử - 24h Dự báo)</span>
            </span>
            <span
              style={{
                background: "#4988C4",
                padding: "2px 8px",
                borderRadius: "4px",
                fontWeight: "bold",
                fontSize: "12px",
              }}
            >
              {(() => {
                const target = new Date();
                target.setHours(target.getHours() + timeOffset);
                return target.toLocaleString("vi-VN", {
                  hour: "2-digit",
                  minute: "2-digit",
                  day: "2-digit",
                  month: "2-digit",
                  year: "numeric",
                });
              })()}
            </span>
          </div>

          <div style={{ display: "flex", alignItems: "center", gap: "15px" }}>
            <span style={{ color: "#bdc3c7", fontSize: "11px", fontWeight: "bold" }}>
              -24h (Lịch sử)
            </span>
            <input
              type="range"
              min={-24}
              max={24}
              value={timeOffset}
              onChange={(e) => setTimeOffset(parseInt(e.target.value))}
              style={{
                flex: 1,
                cursor: "pointer",
                accentColor: "#4988C4",
                height: "6px",
                borderRadius: "3px",
              }}
            />
            <span style={{ color: "#bdc3c7", fontSize: "11px", fontWeight: "bold" }}>
              +24h (Dự báo)
            </span>
          </div>

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              color: "#7f8c8d",
              fontSize: "10px",
            }}
          >
            <span>Quá khứ</span>
            <span
              onClick={() => setTimeOffset(0)}
              style={{
                color: timeOffset === 0 ? "#4988C4" : "#bdc3c7",
                cursor: "pointer",
                fontWeight: "bold",
                textDecoration: "underline",
              }}
            >
              Hiện tại
            </span>
            <span>Tương lai</span>
          </div>
        </div>
      </div>

      {/* Sidebar chính */}
      {selectedLoc && !showAnalystModal && (
        <div
          style={{
            width: "720px",
            flexShrink: 0,
            height: "100%",
            background: "#1e272e",
            color: "white",
            boxShadow: "-2px 0 10px rgba(0,0,0,0.3)",
            display: "flex",
            flexDirection: "column",
            zIndex: 1010,
          }}
        >
          <div
            style={{
              padding: "25px 20px 15px 20px",
              background: "linear-gradient(to bottom, #2c3e50, #1e272e)",
            }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <h2 style={{ margin: 0, color: "#fff", fontSize: "22px" }}>
                 { <MapPin size={18} /> }  {selectedLoc.ten_khuvuc}
              </h2>
              <button
                style={{
                  border: "none",
                  background: "transparent",
                  color: "#fff",
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
                onClick={() => setSelectedLoc(null)}
              >
                <X size={20} />
              </button>
            </div>
            <div
              style={{
                marginTop: "15px",
                display: "flex",
                alignItems: "baseline",
                gap: "10px",
              }}
            >
              <h1
                style={{
                  margin: 0,
                  fontSize: "52px",
                  fontWeight: "300",
                  color: "#fff",
                }}
              >
                {formatTemp(selectedLoc.nhiet_do)}{tempUnit === "F" ? "°F" : "°C"}
              </h1>
              <div>
                <p
                  style={{
                    margin: 0,
                    fontSize: "16px",
                    fontWeight: "bold",
                    color: "#f1c40f",
                  }}
                >
                  Hiện tại
                </p>
                <p
                  style={{
                    margin: 0,
                    color: "#a4b0be",
                    fontSize: "13px",
                    marginTop: "2px",
                  }}
                >
                   { <Droplets size={16} /> }  Độ ẩm: {selectedLoc.do_am}% |  { <CloudRain size={16} /> }  Mưa:{" "}
                  {selectedLoc.luong_mua}mm
                </p>
              </div>
            </div>
          </div>
          <div
            className="hide-scroll"
            style={{
              flex: 1,
              overflowY: "auto",
              padding: "0 15px 20px 15px",
              display: "flex",
              flexDirection: "column",
              gap: "20px",
            }}
          >
            <div
              style={{
                background: "rgba(255, 255, 255, 0.05)",
                borderRadius: "12px",
                padding: "15px",
                width: "100%",
                boxSizing: "border-box",
              }}
            >
              <span
                style={{
                  fontSize: "13px",
                  color: "#a4b0be",
                  fontWeight: "bold",
                  display: "block",
                  marginBottom: "10px",
                }}
              >
                 { <Clock size={16} /> }  DỰ BÁO 24 GIỜ TỚI
              </span>
              <div
                className="hide-scroll"
                style={{
                  display: "flex",
                  gap: "12px",
                  overflowX: "auto",
                  paddingBottom: "10px",
                  width: "100%",
                }}
              >
                {openMeteoData.map((d, i) => {
                  const condition = getWeatherCondition(
                    d.do_phu_may,
                    d.luong_mua,
                  );
                  const hour = new Date(d.thoi_gian).getHours();
                  const isTomorrow = hour === 0;
                  return (
                    <div
                      key={i}
                      style={{
                        flexShrink: 0,
                        minWidth: "65px",
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center",
                        background: isTomorrow
                          ? "rgba(52, 152, 219, 0.15)"
                          : "rgba(255,255,255,0.03)",
                        padding: "10px 5px",
                        borderRadius: "8px",
                        border: isTomorrow
                          ? "1px solid #1C4D8D"
                          : "1px solid rgba(255,255,255,0.05)",
                      }}
                    >
                      {isTomorrow && (
                        <span
                          style={{
                            fontSize: "10px",
                        color: "#4988C4",
                        fontWeight: "bold",
                        marginBottom: "2px",
                      }}
                    >
                      MAI
                    </span>
                  )}
                  <span
                    style={{
                      fontSize: "11px",
                      color: isTomorrow ? "#4988C4" : "#ced6e0",
                          fontWeight: isTomorrow ? "bold" : "normal",
                        }}
                      >
                        {isTomorrow ? "00:00" : `${hour}:00`}
                      </span>
                      <span
                        style={{ fontSize: "22px", margin: "6px 0" }}
                        title={condition.text}
                      >
                        {condition.icon}
                      </span>
                      <strong style={{ fontSize: "13px", color: "#fff" }}>
                        {tempUnit === "F"
                          ? Math.round(parseFloat(d.nhiet_do) * 1.8 + 32)
                          : Math.round(parseFloat(d.nhiet_do))}°
                      </strong>
                    </div>
                  );
                })}
              </div>
            </div>
            <div
              style={{
                background: "rgba(255, 255, 255, 0.05)",
                borderRadius: "12px",
                padding: "15px",
              }}
            >
              <span
                style={{
                  fontSize: "13px",
                  color: "#a4b0be",
                  fontWeight: "bold",
                  display: "block",
                  marginBottom: "12px",
                }}
              >
                <Calendar size={16} /> DỰ BÁO HẰNG NGÀY
              </span>
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  gap: "14px",
                }}
              >
                {generateWeeklyList().map((day, i) => (
                  <div
                    key={i}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      fontSize: "15px",
                    }}
                  >
                    <span
                      style={{
                        width: "90px",
                        fontWeight: "500",
                        color: day.label === "Hôm nay" ? "#f1c40f" : "#fff",
                      }}
                    >
                      {day.label}
                    </span>
                    <span
                      style={{
                        width: "60px",
                        fontSize: "12px",
                        color: "#4988C4",
                        display: "flex",
                        alignItems: "center",
                        gap: "3px",
                      }}
                    >
                       { <Droplets size={16} /> }  {day.humidity}%
                    </span>
                    <span
                      style={{
                        width: "40px",
                        textAlign: "center",
                        fontSize: "18px",
                      }}
                      title={day.iconInfo.text}
                    >
                      {day.iconInfo.icon}
                    </span>
                    <span
                      style={{
                        width: "70px",
                        textAlign: "right",
                        display: "flex",
                        justifyContent: "flex-end",
                        gap: "10px",
                      }}
                    >
                      <span style={{ fontWeight: "bold" }}>
                        {tempUnit === "F"
                          ? Math.round(day.maxTemp * 1.8 + 32)
                          : Math.round(day.maxTemp)}°
                      </span>
                      <span style={{ color: "#a4b0be" }}>
                        {tempUnit === "F"
                          ? Math.round(day.minTemp * 1.8 + 32)
                          : Math.round(day.minTemp)}°
                      </span>
                    </span>
                  </div>
                ))}
              </div>
            </div>
            <button
              onClick={() => setShowHistoryModal(true)}
              style={{
                width: "100%",
                padding: "12px",
                background: "linear-gradient(to right, #2c3e50, #0F2854)",
                color: "white",
                border: "1px solid #7f8c8d",
                borderRadius: "8px",
                cursor: "pointer",
                fontWeight: "bold",
                fontSize: "14px",
                marginTop: "10px",
                boxShadow: "0 4px 10px rgba(0,0,0,0.2)",
              }}
            >
              <BookOpen size={18} /> TRA CỨU LỊCH SỬ & THỐNG KÊ (UC03)
            </button>
            {currentUser?.role === "analyst" && (
              <button
                onClick={() => setShowAnalystModal(true)}
                style={{
                  width: "100%",
                  padding: "15px",
                  background: "linear-gradient(135deg, #1C4D8D 0%, #0F2854 100%)",
                  color: "white",
                  border: "1px solid #4988C4",
                  borderRadius: "8px",
                  cursor: "pointer",
                  fontWeight: "bold",
                  fontSize: "15px",
                  boxShadow: "0 4px 15px rgba(0,0,0,0.2)",
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  gap: "10px",
                  marginTop: "10px",
                }}
              >
                 { <Settings size={18} /> }  MỞ BẢNG PHÂN TÍCH CHUYÊN SÂU
              </button>
            )}
          </div>
        </div>
      )}

      {/* Modal Phân Tích Chuyên Sâu */}
      {showAnalystModal && selectedLoc && currentUser?.role === "analyst" && (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100vw",
            height: "100vh",
            background: "rgba(0,0,0,0.8)",
            zIndex: 9999,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            backdropFilter: "blur(5px)",
          }}
        >
          <div
            style={{
              width: "90%",
              maxWidth: "1100px",
              background: "#1e272e",
              borderRadius: "12px",
              boxShadow: "0 10px 40px rgba(0,0,0,0.5)",
              display: "flex",
              flexDirection: "column",
              overflow: "hidden",
              border: "1px solid #0F2854",
            }}
          >
            <div
              style={{
                padding: "20px 25px",
                background: "#2c3e50",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                borderBottom: "1px solid #0F2854",
              }}
            >
              <h2
                style={{
                  margin: 0,
                  color: "#fff",
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                }}
              >
                <span style={{ fontSize: "24px" }}> { <BarChart3 size={18} /> } </span> Phân Tích Chuyên
                Sâu: {selectedLoc.ten_khuvuc}
              </h2>
              <button
                onClick={() => setShowAnalystModal(false)}
                style={{
                  background: "transparent",
                  border: "none",
                  color: "#e74c3c",
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <X size={24} />
              </button>
            </div>
            <div
              style={{
                padding: "20px 25px",
                display: "flex",
                gap: "20px",
                background: "#0F2854",
              }}
            >
              <div style={{ flex: 1 }}>
                <label
                  style={{
                    fontSize: "13px",
                    color: "#bdc3c7",
                    fontWeight: "bold",
                    display: "block",
                    marginBottom: "8px",
                  }}
                >
                  Lựa chọn Biến số (bienSo):
                </label>
                <select
                  value={selectedBienSo}
                  onChange={(e) => setSelectedBienSo(e.target.value)}
                  style={{
                    width: "100%",
                    padding: "10px",
                    borderRadius: "6px",
                    background: "#1e272e",
                    color: "white",
                    border: "1px solid #718093",
                    outline: "none",
                    fontSize: "14px",
                  }}
                >
                  <option value="nhiet_do">Nhiệt độ ({tempUnit === "F" ? "°F" : "°C"})</option>
                  <option value="do_am">Độ ẩm (%)</option>
                </select>
              </div>
              <div style={{ flex: 1 }}>
                <label
                  style={{
                    fontSize: "13px",
                    color: "#bdc3c7",
                    fontWeight: "bold",
                    display: "block",
                    marginBottom: "8px",
                  }}
                >
                  Mô hình Toán học (phuongPhap):
                </label>
                <select
                  value={algoMethod}
                  onChange={(e) => setAlgoMethod(e.target.value)}
                  style={{
                    width: "100%",
                    padding: "10px",
                    borderRadius: "6px",
                    background: "#1e272e",
                    color: "white",
                    border: "1px solid #718093",
                    outline: "none",
                    fontSize: "14px",
                  }}
                >
                  <option value="movingAverage">
                    Trung bình trượt (Moving Average)
                  </option>
                  <option value="linearRegression">
                    Hồi quy tuyến tính (Linear Regression)
                  </option>
                </select>
              </div>
              <div style={{ flex: 1.2 }}>
                <label
                  style={{
                    fontSize: "13px",
                    color: "#bdc3c7",
                    fontWeight: "bold",
                    display: "block",
                    marginBottom: "8px",
                  }}
                >
                  <GitCompare size={16} /> So sánh với trạm khác:
                </label>
                <select
                  value={compareLoc ? compareLoc.id_diadiem : ""}
                  onChange={(e) => handleSelectCompareLocation(e.target.value)}
                  style={{
                    width: "100%",
                    padding: "10px",
                    borderRadius: "6px",
                    background: "#1e272e",
                    color: "white",
                    border: "1px solid #718093",
                    outline: "none",
                    fontSize: "14px",
                  }}
                >
                  <option value="">-- Chọn trạm để so sánh --</option>
                  {geoJsonData &&
                    geoJsonData.features
                      .filter((f) => f.properties.id_diadiem !== selectedLoc.id_diadiem)
                      .map((f) => (
                        <option key={f.properties.id_diadiem} value={f.properties.id_diadiem}>
                          {f.properties.ten_khuvuc}
                        </option>
                      ))}
                </select>
              </div>
              <div
                style={{
                  display: "flex",
                  gap: "15px",
                  alignItems: "flex-end",
                  flex: 1.5,
                }}
              >
                <button
                  onClick={handleRunBaseline}
                  disabled={isRunningModel}
                  style={{
                    flex: 1,
                    padding: "12px",
                    background: "#27ae60",
                    color: "white",
                    border: "none",
                    borderRadius: "6px",
                    cursor: isRunningModel ? "not-allowed" : "pointer",
                    fontWeight: "bold",
                    fontSize: "14px",
                    boxShadow: "0 2px 5px rgba(0,0,0,0.2)",
                  }}
                >
                  {isRunningModel ? <><Loader2 size={18} className='animate-spin' /> Đang tính toán...</> : <><Play size={16} /> Chạy Mô Hình</>}
                </button>
                <button
                  onClick={handleExportCSV}
                  style={{
                    flex: 1,
                    padding: "12px",
                    background: "#8e44ad",
                    color: "white",
                    border: "none",
                    borderRadius: "6px",
                    cursor: "pointer",
                    fontWeight: "bold",
                    fontSize: "14px",
                    boxShadow: "0 2px 5px rgba(0,0,0,0.2)",
                  }}
                >
                  <Download size={16} /> Tải dữ liệu (.csv)
                </button>
              </div>
            </div>
            {modelMetrics && (
              <div
                style={{
                  padding: "10px 25px",
                  background: "rgba(39, 174, 96, 0.1)",
                  borderTop: "1px solid #27ae60",
                  borderBottom: "1px solid #27ae60",
                  display: "flex",
                  gap: "20px",
                  alignItems: "center",
                }}
              >
                <span
                  style={{
                    fontSize: "14px",
                    color: "#2ecc71",
                    fontWeight: "bold",
                    display: "inline-flex",
                    alignItems: "center",
                    gap: "6px",
                  }}
                >
                  <CheckSquare size={16} /> ĐÁNH GIÁ MÔ HÌNH:
                </span>
                <span style={{ fontSize: "14px", color: "#bdc3c7" }}>
                  Sai số tuyệt đối trung bình (MAE):{" "}
                  <b style={{ color: "#fff" }}>{modelMetrics.mae}</b>
                </span>
                <span style={{ fontSize: "14px", color: "#bdc3c7" }}>
                  Lỗi bình phương trung bình (RMSE):{" "}
                  <b style={{ color: "#fff" }}>{modelMetrics.rmse}</b>
                </span>
              </div>
            )}
            <div
              style={{
                padding: "20px 25px",
                background: "#1e272e",
                height: "400px",
              }}
            >
              {loadingChart ? (
                <div
                  style={{
                    height: "100%",
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    color: "#bdc3c7",
                    fontSize: "18px",
                  }}
                >
                   { <Loader2 size={18} className='animate-spin' /> }  Đang nội suy và dựng đồ thị...
                </div>
              ) : (
                <WeatherChart
                  historyData={historyData}
                  openMeteoData={openMeteoData}
                  forecastData={forecastData}
                  compareHistoryData={compareHistoryData}
                  compareOpenMeteoData={compareOpenMeteoData}
                  compareForecastData={compareForecastData}
                  station1Name={selectedLoc.ten_khuvuc}
                  station2Name={compareLoc ? compareLoc.ten_khuvuc : "Trạm so sánh"}
                  tempUnit={tempUnit}
                />
              )}
            </div>
          </div>
        </div>
      )}

      {/* Modal Lịch sử và thống kê */}
      {showHistoryModal && selectedLoc && (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100vw",
            height: "100vh",
            background: "rgba(0,0,0,0.85)",
            zIndex: 9999,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            backdropFilter: "blur(5px)",
          }}
        >
          <div
            style={{
              width: "90%",
              maxWidth: "1100px",
              background: "#1e272e",
              borderRadius: "12px",
              overflow: "hidden",
              border: "1px solid #0F2854",
              display: "flex",
              flexDirection: "column",
              maxHeight: "85vh",
            }}
          >
            {/* Header Modal */}
            <div
              style={{
                padding: "20px",
                background: "#2c3e50",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <h2 style={{ margin: 0, color: "#fff", fontSize: "20px" }}>
                <BookOpen size={18} /> Lịch sử Quan trắc: {selectedLoc.ten_khuvuc}
              </h2>
              <button
                onClick={() => setShowHistoryModal(false)}
                style={{
                  background: "transparent",
                  border: "none",
                  color: "#e74c3c",
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <X size={24} />
              </button>
            </div>

            {/* Thanh Thống kê Nhanh (Statistics) */}
            <div
              style={{
                display: "flex",
                flexWrap: "wrap",
                background: "#0F2854",
                padding: "15px 20px",
                borderBottom: "1px solid #0F2854",
                gap: "15px",
              }}
            >
              <div
                style={{
                  flex: "1 1 220px",
                  background: "#1e272e",
                  padding: "15px",
                  borderRadius: "8px",
                  borderLeft: "4px solid #e74c3c",
                }}
              >
                <span style={{ color: "#bdc3c7", fontSize: "12px", display: "block" }}>
                   { <Thermometer size={16} /> }  Nhiệt độ Cao nhất (24h)
                </span>
                <strong style={{ color: "#fff", fontSize: "24px" }}>
                  {historyData.length > 0
                    ? formatTemp(Math.max(...historyData.map((d) => parseFloat(d.nhiet_do) || 0)))
                    : "0.0"}
                  {tempUnit === "F" ? "°F" : "°C"}
                </strong>
              </div>

              <div
                style={{
                  flex: "1 1 220px",
                  background: "#1e272e",
                  padding: "15px",
                  borderRadius: "8px",
                  borderLeft: "4px solid #1C4D8D",
                }}
              >
                <span style={{ color: "#bdc3c7", fontSize: "12px", display: "block" }}>
                   { <Thermometer size={16} /> }  Nhiệt độ Thấp nhất (24h)
                </span>
                <strong style={{ color: "#fff", fontSize: "24px" }}>
                  {historyData.length > 0
                    ? formatTemp(Math.min(...historyData.map((d) => parseFloat(d.nhiet_do) || 0)))
                    : "0.0"}
                  {tempUnit === "F" ? "°F" : "°C"}
                </strong>
              </div>

              <div
                style={{
                  flex: "1 1 220px",
                  background: "#1e272e",
                  padding: "15px",
                  borderRadius: "8px",
                  borderLeft: "4px solid #4988C4",
                }}
              >
                <span style={{ color: "#bdc3c7", fontSize: "12px", display: "block" }}>
                   { <Droplets size={16} /> }  Độ ẩm Trung bình (24h)
                </span>
                <strong style={{ color: "#fff", fontSize: "24px" }}>
                  {(
                    historyData.reduce((acc, d) => acc + (parseFloat(d.do_am) || 0), 0) /
                    (historyData.length || 1)
                  ).toFixed(1)}
                  %
                </strong>
              </div>

              <div
                style={{
                  flex: "1 1 220px",
                  background: "#1e272e",
                  padding: "15px",
                  borderRadius: "8px",
                  borderLeft: "4px solid #f1c40f",
                }}
              >
                <span style={{ color: "#bdc3c7", fontSize: "12px", display: "block" }}>
                  <Wind size={16} /> Tốc độ Gió Lớn nhất (24h)
                </span>
                <strong style={{ color: "#fff", fontSize: "24px" }}>
                  {historyData.length > 0
                    ? Math.max(...historyData.map((d) => parseFloat(d.toc_do_gio) || 0)).toFixed(1)
                    : "0.0"}
                  {" "}km/h
                </strong>
              </div>

              <div
                style={{
                  flex: "1 1 220px",
                  background: "#1e272e",
                  padding: "15px",
                  borderRadius: "8px",
                  borderLeft: "4px solid #e67e22",
                }}
              >
                <span style={{ color: "#bdc3c7", fontSize: "12px", display: "block" }}>
                  <Compass size={16} /> Hướng Gió TB (24h)
                </span>
                <strong style={{ color: "#fff", fontSize: "24px" }}>
                  {historyData.length > 0
                    ? (
                        historyData.reduce((acc, d) => acc + (parseInt(d.huong_gio) || 0), 0) /
                        historyData.length
                      ).toFixed(0)
                    : "0"}
                  °
                </strong>
              </div>

              <div
                style={{
                  flex: "1 1 220px",
                  background: "#1e272e",
                  padding: "15px",
                  borderRadius: "8px",
                  borderLeft: "4px solid #9b59b6",
                }}
              >
                <span style={{ color: "#bdc3c7", fontSize: "12px", display: "block" }}>
                  <Gauge size={16} /> Áp suất Khí quyển TB (24h)
                </span>
                <strong style={{ color: "#fff", fontSize: "24px" }}>
                  {historyData.length > 0
                    ? (
                        historyData.reduce((acc, d) => acc + (parseFloat(d.ap_suat) || 0), 0) /
                        historyData.length
                      ).toFixed(1)
                    : "0.0"}
                  {" "}hPa
                </strong>
              </div>
            </div>

            {/* Bảng Data Table (Lưới dữ liệu thô) */}
            <div
              className="hide-scroll"
              style={{ flex: 1, overflowY: "auto", overflowX: "auto", padding: "20px" }}
            >
              <table
                style={{
                  width: "100%",
                  borderCollapse: "collapse",
                  color: "#ecf0f1",
                  textAlign: "left",
                  fontSize: "14px",
                }}
              >
                <thead
                  style={{ position: "sticky", top: 0, background: "#2c3e50" }}
                >
                  <tr>
                    <th
                      style={{
                        padding: "12px 15px",
                        borderBottom: "2px solid #0F2854",
                        whiteSpace: "nowrap",
                      }}
                    >
                       { <Clock size={16} /> }  Thời gian Ghi nhận
                    </th>
                    <th
                      style={{
                        padding: "12px 15px",
                        borderBottom: "2px solid #0F2854",
                        whiteSpace: "nowrap",
                      }}
                    >
                       { <Thermometer size={16} /> }  Nhiệt độ
                    </th>
                    <th
                      style={{
                        padding: "12px 15px",
                        borderBottom: "2px solid #0F2854",
                        whiteSpace: "nowrap",
                      }}
                    >
                       { <Droplets size={16} /> }  Độ ẩm
                    </th>
                    <th
                      style={{
                        padding: "12px 15px",
                        borderBottom: "2px solid #0F2854",
                        whiteSpace: "nowrap",
                      }}
                    >
                       { <CloudRain size={16} /> }  Lượng mưa
                    </th>
                    <th
                      style={{
                        padding: "12px 15px",
                        borderBottom: "2px solid #0F2854",
                        whiteSpace: "nowrap",
                      }}
                    >
                      <Wind size={16} /> Tốc độ gió
                    </th>
                    <th
                      style={{
                        padding: "12px 15px",
                        borderBottom: "2px solid #0F2854",
                        whiteSpace: "nowrap",
                      }}
                    >
                      <Compass size={16} /> Hướng gió
                    </th>
                    <th
                      style={{
                        padding: "12px 15px",
                        borderBottom: "2px solid #0F2854",
                        whiteSpace: "nowrap",
                      }}
                    >
                      <Gauge size={16} /> Áp suất
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {historyData.map((d, i) => (
                    <tr
                      key={i}
                      style={{
                        background:
                          i % 2 === 0
                            ? "rgba(255,255,255,0.02)"
                            : "transparent",
                        borderBottom: "1px solid #0F2854",
                      }}
                    >
                      <td style={{ padding: "12px 15px" }}>
                        {new Date(d.thoi_gian).toLocaleString("vi-VN")}
                      </td>
                      <td
                        style={{
                          padding: "12px 15px",
                          color: "#f1c40f",
                          fontWeight: "bold",
                        }}
                      >
                        {formatTemp(d.nhiet_do)}{tempUnit === "F" ? "°F" : "°C"}
                      </td>
                      <td style={{ padding: "12px 15px", color: "#4988C4" }}>
                        {d.do_am}%
                      </td>
                      <td style={{ padding: "12px 15px", color: "#9b59b6" }}>
                        {d.luong_mua} mm
                      </td>
                      <td style={{ padding: "12px 15px", color: "#f1c40f" }}>
                        {d.toc_do_gio !== null && d.toc_do_gio !== undefined ? `${d.toc_do_gio} km/h` : "0.0 km/h"}
                      </td>
                      <td style={{ padding: "12px 15px", color: "#e67e22" }}>
                        {d.huong_gio !== null && d.huong_gio !== undefined ? `${d.huong_gio}°` : "0°"}
                      </td>
                      <td style={{ padding: "12px 15px", color: "#2ecc71" }}>
                        {d.ap_suat !== null && d.ap_suat !== undefined ? `${d.ap_suat} hPa` : "0.0 hPa"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default WeatherMap;
