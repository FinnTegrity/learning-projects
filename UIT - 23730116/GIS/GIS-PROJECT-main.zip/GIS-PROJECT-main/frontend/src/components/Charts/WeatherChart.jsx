import { CloudRain, Thermometer, Droplets } from 'lucide-react';
import React, { useState } from 'react';
import { Line, Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title, Tooltip, Legend } from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title, Tooltip, Legend);

const WeatherChart = ({ 
  historyData = [], 
  openMeteoData = [], 
  forecastData = [],
  compareHistoryData = [],
  compareOpenMeteoData = [],
  compareForecastData = [],
  station1Name = "Trạm 1",
  station2Name = "Trạm 2",
  tempUnit = 'C'
}) => {
  const [metric, setMetric] = useState('temperature'); 

  const convertTemp = (val) => {
    if (val === null || val === undefined || isNaN(val)) return undefined;
    if (tempUnit === 'F') {
      return parseFloat((parseFloat(val) * 1.8 + 32).toFixed(1));
    }
    return parseFloat(parseFloat(val).toFixed(1));
  };

  const timeMap = new Map();

  historyData.forEach(d => {
    const t = new Date(d.thoi_gian).getTime();
    if (!timeMap.has(t)) timeMap.set(t, {});
    timeMap.get(t).histT = convertTemp(d.nhiet_do);
    timeMap.get(t).histH = parseFloat(d.do_am);
    timeMap.get(t).histR = parseFloat(d.luong_mua);
  });

  openMeteoData.forEach(d => {
    const t = new Date(d.thoi_gian).getTime();
    if (!timeMap.has(t)) timeMap.set(t, {});
    timeMap.get(t).omT = convertTemp(d.nhiet_do);
    timeMap.get(t).omH = parseFloat(d.do_am);
    timeMap.get(t).omR = parseFloat(d.luong_mua);
  });

  forecastData.forEach(d => {
    const t = new Date(d.thoi_gian_dubao).getTime();
    if (!timeMap.has(t)) timeMap.set(t, {});
    timeMap.get(t).baseT = convertTemp(d.nhiet_do_dubao);
    timeMap.get(t).baseH = parseFloat(d.do_am_dubao);
  });

  // Nạp dữ liệu trạm so sánh (nếu có)
  compareHistoryData.forEach(d => {
    const t = new Date(d.thoi_gian).getTime();
    if (!timeMap.has(t)) timeMap.set(t, {});
    timeMap.get(t).compHistT = convertTemp(d.nhiet_do);
    timeMap.get(t).compHistH = parseFloat(d.do_am);
    timeMap.get(t).compHistR = parseFloat(d.luong_mua);
  });

  compareOpenMeteoData.forEach(d => {
    const t = new Date(d.thoi_gian).getTime();
    if (!timeMap.has(t)) timeMap.set(t, {});
    timeMap.get(t).compOmT = convertTemp(d.nhiet_do);
    timeMap.get(t).compOmH = parseFloat(d.do_am);
    timeMap.get(t).compOmR = parseFloat(d.luong_mua);
  });

  compareForecastData.forEach(d => {
    const t = new Date(d.thoi_gian_dubao).getTime();
    if (!timeMap.has(t)) timeMap.set(t, {});
    timeMap.get(t).compBaseT = convertTemp(d.nhiet_do_dubao);
    timeMap.get(t).compBaseH = parseFloat(d.do_am_dubao);
  });

  const sortedTimes = Array.from(timeMap.keys()).sort();
  const labels = [];
  const histT = [], histH = [], histR = [];
  const omT = [], omH = [], omR = [];
  const baseT = [], baseH = [];

  const compHistT = [], compHistH = [], compHistR = [];
  const compOmT = [], compOmH = [], compOmR = [];
  const compBaseT = [], compBaseH = [];

  sortedTimes.forEach(t => {
    const date = new Date(t);
    const hourStr = date.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });
    const dateStr = date.toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit' });
    labels.push(`${hourStr} (${dateStr})`);
    
    const vals = timeMap.get(t);
    histT.push(vals.histT !== undefined ? vals.histT : null);
    histH.push(vals.histH !== undefined ? vals.histH : null);
    histR.push(vals.histR !== undefined ? vals.histR : null);
    omT.push(vals.omT !== undefined ? vals.omT : null);
    omH.push(vals.omH !== undefined ? vals.omH : null);
    omR.push(vals.omR !== undefined ? vals.omR : null);
    baseT.push(vals.baseT !== undefined ? vals.baseT : null);
    baseH.push(vals.baseH !== undefined ? vals.baseH : null);

    compHistT.push(vals.compHistT !== undefined ? vals.compHistT : null);
    compHistH.push(vals.compHistH !== undefined ? vals.compHistH : null);
    compHistR.push(vals.compHistR !== undefined ? vals.compHistR : null);
    compOmT.push(vals.compOmT !== undefined ? vals.compOmT : null);
    compOmH.push(vals.compOmH !== undefined ? vals.compOmH : null);
    compOmR.push(vals.compOmR !== undefined ? vals.compOmR : null);
    compBaseT.push(vals.compBaseT !== undefined ? vals.compBaseT : null);
    compBaseH.push(vals.compBaseH !== undefined ? vals.compBaseH : null);
  });

  // Nối điểm cuối cùng của lịch sử với điểm bắt đầu của dự báo
  let lastHistIdx = -1;
  for (let i = sortedTimes.length - 1; i >= 0; i--) {
    if (histT[i] !== null) { lastHistIdx = i; break; }
  }

  if (lastHistIdx !== -1) {
    if (omT.length > lastHistIdx) omT[lastHistIdx] = histT[lastHistIdx];
    if (omH.length > lastHistIdx) omH[lastHistIdx] = histH[lastHistIdx];
    if (baseT.length > lastHistIdx) baseT[lastHistIdx] = histT[lastHistIdx];
    if (baseH.length > lastHistIdx) baseH[lastHistIdx] = histH[lastHistIdx];
  }

  let lastCompHistIdx = -1;
  for (let i = sortedTimes.length - 1; i >= 0; i--) {
    if (compHistT[i] !== null) { lastCompHistIdx = i; break; }
  }

  if (lastCompHistIdx !== -1) {
    if (compOmT.length > lastCompHistIdx) compOmT[lastCompHistIdx] = compHistT[lastCompHistIdx];
    if (compOmH.length > lastCompHistIdx) compOmH[lastCompHistIdx] = compHistH[lastCompHistIdx];
    if (compBaseT.length > lastCompHistIdx) compBaseT[lastCompHistIdx] = compHistT[lastCompHistIdx];
    if (compBaseH.length > lastCompHistIdx) compBaseH[lastCompHistIdx] = compHistH[lastCompHistIdx];
  }

  let datasets = [];
  let yAxisLabel = "";

  const hasCompare = compareHistoryData.length > 0;

  if (metric === 'temperature') {
    yAxisLabel = `Nhiệt độ (°${tempUnit})`;
    if (hasCompare) {
      datasets = [
        { label: `${station1Name} (Thực tế)`, data: histT, borderColor: '#e74c3c', backgroundColor: '#e74c3c', tension: 0.3, spanGaps: true },
        { label: `${station1Name} (Dự báo OM)`, data: omT, borderColor: '#e67e22', borderDash: [5, 5], tension: 0.3, spanGaps: true },
        { label: `${station2Name} (Thực tế)`, data: compHistT, borderColor: '#1C4D8D', backgroundColor: '#1C4D8D', tension: 0.3, spanGaps: true },
        { label: `${station2Name} (Dự báo OM)`, data: compOmT, borderColor: '#4988C4', borderDash: [5, 5], tension: 0.3, spanGaps: true },
      ];
      if (forecastData.length > 0) datasets.push({ label: `${station1Name} (Baseline)`, data: baseT, borderColor: '#9b59b6', borderDash: [2, 2], tension: 0.3, spanGaps: true, borderWidth: 3 });
      if (compareForecastData.length > 0) datasets.push({ label: `${station2Name} (Baseline)`, data: compBaseT, borderColor: '#f1c40f', borderDash: [2, 2], tension: 0.3, spanGaps: true, borderWidth: 3 });
    } else {
      datasets = [
        { label: 'Thực tế', data: histT, borderColor: '#e74c3c', backgroundColor: '#e74c3c', tension: 0.3, spanGaps: true },
        { label: 'Open-Meteo', data: omT, borderColor: '#e67e22', borderDash: [5, 5], tension: 0.3, spanGaps: true },
      ];
      if (forecastData.length > 0) datasets.push({ label: 'Baseline', data: baseT, borderColor: '#9b59b6', borderDash: [2, 2], tension: 0.3, spanGaps: true, borderWidth: 3 });
    }
  } 
  else if (metric === 'humidity') {
    yAxisLabel = "Độ ẩm (%)";
    if (hasCompare) {
      datasets = [
        { label: `${station1Name} (Thực tế)`, data: histH, borderColor: '#1C4D8D', backgroundColor: '#1C4D8D', tension: 0.3, spanGaps: true },
        { label: `${station1Name} (Dự báo OM)`, data: omH, borderColor: '#4988C4', borderDash: [5, 5], tension: 0.3, spanGaps: true },
        { label: `${station2Name} (Thực tế)`, data: compHistH, borderColor: '#e67e22', backgroundColor: '#e67e22', tension: 0.3, spanGaps: true },
        { label: `${station2Name} (Dự báo OM)`, data: compOmH, borderColor: '#f1c40f', borderDash: [5, 5], tension: 0.3, spanGaps: true },
      ];
      if (forecastData.length > 0) datasets.push({ label: `${station1Name} (Baseline)`, data: baseH, borderColor: '#2ecc71', borderDash: [2, 2], tension: 0.3, spanGaps: true, borderWidth: 3 });
      if (compareForecastData.length > 0) datasets.push({ label: `${station2Name} (Baseline)`, data: compBaseH, borderColor: '#8e44ad', borderDash: [2, 2], tension: 0.3, spanGaps: true, borderWidth: 3 });
    } else {
      datasets = [
        { label: 'Thực tế', data: histH, borderColor: '#1C4D8D', backgroundColor: '#1C4D8D', tension: 0.3, spanGaps: true },
        { label: 'Open-Meteo', data: omH, borderColor: '#4988C4', borderDash: [5, 5], tension: 0.3, spanGaps: true },
      ];
      if (forecastData.length > 0) datasets.push({ label: 'Baseline', data: baseH, borderColor: '#2ecc71', borderDash: [2, 2], tension: 0.3, spanGaps: true, borderWidth: 3 });
    }
  }
  else if (metric === 'rain') {
    yAxisLabel = "Lượng mưa (mm)";
    if (hasCompare) {
      datasets = [
        { label: `${station1Name} (Thực tế)`, data: histR, backgroundColor: 'rgba(52, 152, 219, 0.7)' },
        { label: `${station1Name} (Dự báo OM)`, data: omR, backgroundColor: 'rgba(155, 89, 182, 0.5)' },
        { label: `${station2Name} (Thực tế)`, data: compHistR, backgroundColor: 'rgba(231, 76, 60, 0.7)' },
        { label: `${station2Name} (Dự báo OM)`, data: compOmR, backgroundColor: 'rgba(241, 196, 15, 0.5)' }
      ];
    } else {
      datasets = [
        { label: 'Lượng mưa thực tế', data: histR, backgroundColor: 'rgba(52, 152, 219, 0.7)' },
        { label: 'Lượng mưa dự báo (Open-Meteo)', data: omR, backgroundColor: 'rgba(155, 89, 182, 0.5)' }
      ];
    }
  }

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { position: 'top', labels: { color: '#ecf0f1', boxWidth: 12 } },
      tooltip: { mode: 'index', intersect: false }
    },
    scales: {
      x: { ticks: { maxTicksLimit: 10, color: '#bdc3c7' }, grid: { color: 'rgba(255,255,255,0.1)' } },
      y: { type: 'linear', display: true, position: 'left', title: { display: true, text: yAxisLabel, color: '#ecf0f1' }, ticks: { color: '#bdc3c7' }, grid: { color: 'rgba(255,255,255,0.1)' } }
    }
  };

  return (
    <div style={{ background: '#0F2854', padding: '15px', borderRadius: '8px' }}>
      <div style={{ display: 'flex', gap: '5px', marginBottom: '15px', borderBottom: '1px solid #718093', paddingBottom: '10px' }}>
        <button onClick={() => setMetric('temperature')} style={{ flex: 1, padding: "6px", background: metric === 'temperature' ? "#e74c3c" : "transparent", color: metric === 'temperature' ? "white" : "#bdc3c7", border: "1px solid #e74c3c", borderRadius: "4px", cursor: "pointer", fontSize: "12px", fontWeight: "bold" }}> { <Thermometer size={16} /> }  Nhiệt độ</button>
        <button onClick={() => setMetric('humidity')} style={{ flex: 1, padding: "6px", background: metric === 'humidity' ? "#1C4D8D" : "transparent", color: metric === 'humidity' ? "white" : "#bdc3c7", border: "1px solid #1C4D8D", borderRadius: "4px", cursor: "pointer", fontSize: "12px", fontWeight: "bold" }}> { <Droplets size={16} /> }  Độ ẩm</button>
        <button onClick={() => setMetric('rain')} style={{ flex: 1, padding: "6px", background: metric === 'rain' ? "#9b59b6" : "transparent", color: metric === 'rain' ? "white" : "#bdc3c7", border: "1px solid #9b59b6", borderRadius: "4px", cursor: "pointer", fontSize: "12px", fontWeight: "bold" }}> { <CloudRain size={16} /> }  Lượng mưa</button>
      </div>

      <div style={{ height: '280px' }}>
        {metric === 'rain' ? (
          <Bar data={{ labels, datasets }} options={options} />
        ) : (
          <Line data={{ labels, datasets }} options={options} />
        )}
      </div>
    </div>
  );
};

export default WeatherChart;