import { Lock, Loader2, X } from 'lucide-react';
import React, { useState } from 'react';
import axios from 'axios';

const AuthModal = ({ onClose, onLoginSuccess }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      const res = await axios.post('http://localhost:5000/api/auth/login', {
        ten_dang_nhap: username,
        mat_khau: password
      });

      const { token, user } = res.data;

      localStorage.setItem('gis_token', token);
      localStorage.setItem('gis_user', JSON.stringify(user));

      onLoginSuccess(user);
    } catch (err) {
      setError(err.response?.data?.message || 'Đăng nhập thất bại. Vui lòng thử lại hệ thống!');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: 'rgba(0,0,0,0.85)', zIndex: 10000, display: 'flex', justifyContent: 'center', alignItems: 'center', backdropFilter: 'blur(5px)' }}>
      <div style={{ background: '#1e272e', padding: '30px', borderRadius: '12px', width: '360px', boxShadow: '0 15px 40px rgba(0,0,0,0.6)', border: '1px solid #0F2854' }}>
        
        {/* Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '25px' }}>
          <h2 style={{ margin: 0, color: '#fff', fontSize: '22px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span> { <Lock size={18} /> } </span> Đăng Nhập
          </h2>
          <button onClick={onClose} style={{ background: 'transparent', border: 'none', color: '#e74c3c', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}><X size={20} /></button>
        </div>

        {/* Thông báo lỗi nếu có */}
        {error && (
          <div style={{ background: 'rgba(231, 76, 60, 0.1)', border: '1px solid #e74c3c', color: '#e74c3c', padding: '12px', borderRadius: '8px', marginBottom: '20px', fontSize: '14px', textAlign: 'center', fontWeight: 'bold' }}>
            {error}
          </div>
        )}

        {/* Form nhập liệu */}
        <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: '18px' }}>
          <div>
            <label style={{ color: '#bdc3c7', fontSize: '13px', fontWeight: 'bold', marginBottom: '8px', display: 'block' }}>Tên đăng nhập:</label>
            <input 
              type="text" 
              value={username} 
              onChange={(e) => setUsername(e.target.value)} 
              required
              style={{ width: '100%', boxSizing: 'border-box', padding: '14px', borderRadius: '8px', background: '#0F2854', border: '1px solid #718093', color: '#fff', fontSize: '15px', outline: 'none', transition: 'all 0.3s' }}
              placeholder="Ví dụ: admin, analyst..."
            />
          </div>
          
          <div>
            <label style={{ color: '#bdc3c7', fontSize: '13px', fontWeight: 'bold', marginBottom: '8px', display: 'block' }}>Mật khẩu:</label>
            <input 
              type="password" 
              value={password} 
              onChange={(e) => setPassword(e.target.value)} 
              required
              style={{ width: '100%', boxSizing: 'border-box', padding: '14px', borderRadius: '8px', background: '#0F2854', border: '1px solid #718093', color: '#fff', fontSize: '15px', outline: 'none', transition: 'all 0.3s' }}
              placeholder="Mật khẩu mặc định: 123456"
            />
          </div>

          <button 
            type="submit" 
            disabled={isLoading}
            style={{ marginTop: '15px', width: '100%', padding: '14px', background: 'linear-gradient(to right, #1C4D8D, #1C4D8D)', color: 'white', border: 'none', borderRadius: '8px', fontSize: '16px', fontWeight: 'bold', cursor: isLoading ? 'not-allowed' : 'pointer', boxShadow: '0 4px 15px rgba(28, 77, 141, 0.4)' }}
          >
            {isLoading ? <><Loader2 size={18} className='animate-spin' /> Đang xác thực...</> : 'ĐĂNG NHẬP'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default AuthModal;