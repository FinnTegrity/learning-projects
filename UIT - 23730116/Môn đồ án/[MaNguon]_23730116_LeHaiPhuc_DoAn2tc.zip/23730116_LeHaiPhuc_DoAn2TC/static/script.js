// Le Hai Phuc - 23730116
// ===== GLOBAL STATE =====

const appState = {
  summary: "",
  mindmap_mermaid: "",
  flashcards: [],
  quizzes: [],
  source_text: "",
  source_file: ""
};

function hasStudyData() {
  return Boolean(
    (appState.summary && appState.summary.trim().length) ||
      (appState.mindmap_mermaid && appState.mindmap_mermaid.trim().length) ||
      (appState.flashcards && appState.flashcards.length) ||
      (appState.quizzes && appState.quizzes.length)
  );
}

function buildStudyDataPayload() {
  // Payload giống export JSON để bạn dùng lại giữa các tính năng
  return {
    version: 1,
    source_file: appState.source_file || null,
    source_text: appState.source_text || "",
    summary: appState.summary || "",
    mindmap_mermaid: appState.mindmap_mermaid || "",
    flashcards: appState.flashcards || [],
    quizzes: appState.quizzes || []
  };
}

function updateSaveDbButtonState() {
  const btn = document.getElementById("saveDbBtn");
  if (!btn) return;
  btn.disabled = !hasStudyData();
}
// ===== TF =====
function normalizeTFAnswer(ans) {
  if (typeof ans === "boolean") return ans;
  const s = String(ans ?? "").trim().toLowerCase();
  if (["true", "t", "1", "yes", "y", "đúng", "dung"].includes(s)) return true;
  if (["false", "f", "0", "no", "n", "sai"].includes(s)) return false;
  return null;
}


let currentFlashcardIndex = 0;
let showFlashcardAnswer = false;

// ===== INIT =====

document.addEventListener("DOMContentLoaded", () => {
  const tabs = document.querySelectorAll(".tab-button");
  const panels = {
    home: document.getElementById("tab-home"),
    summary: document.getElementById("tab-summary"),
    mindmap: document.getElementById("tab-mindmap"),
    flashcards: document.getElementById("tab-flashcards"),
    quiz: document.getElementById("tab-quiz")
  };

  tabs.forEach((btn) => {
    btn.addEventListener("click", () => {
      if (btn.classList.contains("tab-disabled")) return;
      const tabName = btn.dataset.tab;
      switchTab(tabName, tabs, panels);
    });
  });

  setupUploadAndProcess();
  setupCopyMindmapButton();
  setupFlashcardControls();
  setupQuizSubmit();
  setupAddMoreQuizButton();
  setupAddMoreFlashcardButton();
  setupDataImportExport();
  setupSavedSessions();

  renderSummary();
  renderMindmap();
  renderFlashcard();
  renderFlashcardList();
  renderQuizzes();
  updateAddQuizButtonState();
  updateAddFlashcardButtonState();
});

function switchTab(tabName, tabs, panels) {
  tabs.forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.tab === tabName);
  });
  Object.entries(panels).forEach(([name, panel]) => {
    panel.classList.toggle("hidden", name !== tabName);
  });
}

// ===== UPLOAD & PROCESS =====

function setupUploadAndProcess() {
  const fileInput = document.getElementById("fileInput");
  const fileDrop = document.getElementById("fileDrop");
  const fileNameEl = document.getElementById("fileName");
  const uploadBtn = document.getElementById("uploadBtn"); // có thể null
  const processBtn = document.getElementById("processBtn");
  const processBtnLabel = document.getElementById("processBtnLabel");
  const processBtnSpinner = document.getElementById("processBtnSpinner");
  const uploadStatus = document.getElementById("uploadStatus");

  let selectedFile = null;

  // Không dùng nút Tải tệp lên nữa
  if (uploadBtn) {
    uploadBtn.style.display = "none";
  }

  const showProcessingSpinner = (isOn) => {
    if (!processBtnSpinner || !processBtnLabel) return;
    if (isOn) {
      processBtnSpinner.classList.remove("hidden");
      processBtnLabel.textContent = "Đang xử lý...";
    } else {
      processBtnSpinner.classList.add("hidden");
      processBtnLabel.textContent = "Xử lý với AI";
    }
  };

  const autoUpload = () => {
    if (!selectedFile) return;

    uploadStatus.className = "status status-loading";
    uploadStatus.textContent = "Đang tải tệp lên...";
    processBtn.disabled = true;

    setTimeout(() => {
      uploadStatus.className = "status status-success";
      uploadStatus.textContent = "Tải tệp lên thành công!";
      processBtn.disabled = false;
    }, 800);
  };

  const handleFile = (file) => {
    if (!file) return;
    selectedFile = file;
    fileNameEl.textContent = `Đã chọn: ${file.name}`;
    appState.source_file = file.name || "";
    autoUpload();
  };

  // Chọn file từ input
  fileInput.addEventListener("change", (e) => {
    handleFile(e.target.files[0]);
  });

  // Kéo thả
  fileDrop.addEventListener("dragover", (e) => {
    e.preventDefault();
    fileDrop.classList.add("file-drop-hover");
  });

  fileDrop.addEventListener("dragleave", (e) => {
    e.preventDefault();
    fileDrop.classList.remove("file-drop-hover");
  });

  fileDrop.addEventListener("drop", (e) => {
    e.preventDefault();
    fileDrop.classList.remove("file-drop-hover");
    const file = e.dataTransfer.files[0];
    handleFile(file);
  });

  // Xử lý với AI
  processBtn.addEventListener("click", async () => {
    if (!selectedFile) {
      alert("Vui lòng chọn tệp trước.");
      return;
    }

    processBtn.disabled = true;
    showProcessingSpinner(true);

    uploadStatus.className = "status status-loading";
    uploadStatus.textContent = "Đang xử lý tài liệu với AI...";

    try {
      const formData = new FormData();
      formData.append("file", selectedFile);

      const res = await fetch("/api/process_document", {
        method: "POST",
        body: formData
      });

      if (!res.ok) {
        let errMsg = "Lỗi máy chủ.";
        try {
          const errData = await res.json();
          if (errData && errData.error) errMsg = errData.error;
        } catch (e) {}
        throw new Error(errMsg);
      }

      const data = await res.json();
      appState.summary = data.summary || "";
          appState.mindmap_mermaid = data.mindmap_mermaid || "";
          appState.source_text = data.source_text || "";
          appState.source_text = data.source_text || "";
      appState.flashcards = Array.isArray(data.flashcards)
        ? data.flashcards
        : [];
      appState.quizzes = Array.isArray(data.quizzes) ? data.quizzes : [];

      uploadStatus.className = "status status-success";
      uploadStatus.textContent =
        "Xử lý xong! Bạn có thể mở các tab để xem kết quả.";
      enableContentTabs();

      currentFlashcardIndex = 0;
      showFlashcardAnswer = false;
      renderSummary();
      renderMindmap();
      renderFlashcard();
      renderFlashcardList();
      renderQuizzes();
      updateSaveDbButtonState();
          updateAddQuizButtonState();
      updateAddFlashcardButtonState();
      switchToFirstResultTab();
    } catch (err) {
      console.error(err);
      uploadStatus.className = "status status-error";
      uploadStatus.textContent =
        err.message || "Có lỗi xảy ra, vui lòng thử lại.";
    } finally {
      showProcessingSpinner(false);
      processBtn.disabled = false;
    }
  });
}

// ===== ENABLE TABS & SWITCH =====

function enableContentTabs() {
  const tabNames = ["summary", "mindmap", "flashcards", "quiz"];
  tabNames.forEach((name) => {
    const btn = document.querySelector(`.tab-button[data-tab="${name}"]`);
    if (btn) {
      btn.classList.remove("tab-disabled");
      btn.removeAttribute("aria-disabled");
    }
  });
}

function switchToFirstResultTab() {
  const tabs = document.querySelectorAll(".tab-button");
  const panels = {
    home: document.getElementById("tab-home"),
    summary: document.getElementById("tab-summary"),
    mindmap: document.getElementById("tab-mindmap"),
    flashcards: document.getElementById("tab-flashcards"),
    quiz: document.getElementById("tab-quiz")
  };
  const summaryBtn = document.querySelector('.tab-button[data-tab="summary"]');
  if (summaryBtn && !summaryBtn.classList.contains("tab-disabled")) {
    switchTab("summary", tabs, panels);
  }
}

// ===== SUMMARY =====

function renderSummary() {
  const container = document.getElementById("summaryContent");
  if (!container) return;

  container.innerHTML = "";
  const text =
    appState.summary ||
    "Chưa có dữ liệu tóm tắt. Hãy tải và xử lý tài liệu ở tab Trang chủ.";

  const parts = text.split(/\n+/).filter((p) => p.trim().length > 0);
  if (!parts.length) {
    container.textContent = text;
    return;
  }

  parts.forEach((p) => {
    const para = document.createElement("p");
    para.textContent = p.replace(/^[-•\s]+/, "");
    container.appendChild(para);
  });
}

// ===== MINDMAP =====

async function renderMindmap() {
  const diagramWrapper = document.getElementById("mindmapDiagramWrapper");
  const codeEl = document.getElementById("mindmapCode");
  if (!diagramWrapper || !codeEl) return;

  let code =
    appState.mindmap_mermaid &&
    typeof appState.mindmap_mermaid === "string" &&
    appState.mindmap_mermaid.trim().length
      ? appState.mindmap_mermaid
      : "mindmap\n  root((Chưa có dữ liệu))";

  codeEl.textContent = code;
  diagramWrapper.innerHTML = "";

  if (!window.mermaid || typeof window.mermaid.render !== "function") {
    const msg = document.createElement("p");
    msg.style.color = "#e5e7eb";
    msg.style.fontSize = "12px";
    msg.textContent =
      "Mermaid chưa tải được. Hãy kiểm tra lại kết nối hoặc CDN.";
    diagramWrapper.appendChild(msg);
    return;
  }

  try {
    const { svg, bindFunctions } = await window.mermaid.render(
      "mindmapSvg",
      code
    );
    diagramWrapper.innerHTML = svg;
    if (typeof bindFunctions === "function") {
      bindFunctions(diagramWrapper);
    }
  } catch (e) {
    console.error("Mermaid render error:", e);
    const msg = document.createElement("p");
    msg.style.color = "#e5e7eb";
    msg.style.fontSize = "12px";
    msg.textContent =
      "Không vẽ được mindmap từ code Mermaid. Hãy copy code và thử trên Mermaid Live Editor.";
    diagramWrapper.appendChild(msg);
  }
}

function setupCopyMindmapButton() {
  const btn = document.getElementById("copyMindmapBtn");
  const codeEl = document.getElementById("mindmapCode");
  if (!btn || !codeEl) return;

  btn.addEventListener("click", async () => {
    const code = codeEl.textContent || "";
    if (!code.trim()) {
      alert("Chưa có code mindmap để copy.");
      return;
    }
    try {
      await navigator.clipboard.writeText(code);
      btn.textContent = "Đã copy!";
      btn.classList.add("btn-success");
      setTimeout(() => {
        btn.textContent = "Copy code Mermaid";
        btn.classList.remove("btn-success");
      }, 1300);
    } catch (err) {
      console.error(err);
      alert(
        "Trình duyệt không cho phép copy tự động. Hãy bôi đen và copy thủ công."
      );
    }
  });
}

// ===== FLASHCARDS =====

function setupFlashcardControls() {
  const prevBtn = document.getElementById("flashPrev");
  const nextBtn = document.getElementById("flashNext");
  const toggleAnsBtn = document.getElementById("flashToggleAnswer");
  const showAllBtn = document.getElementById("flashShowAll");

  if (prevBtn) {
    prevBtn.addEventListener("click", () => {
      if (!appState.flashcards.length) return;
      currentFlashcardIndex =
        (currentFlashcardIndex - 1 + appState.flashcards.length) %
        appState.flashcards.length;
      showFlashcardAnswer = false;
      renderFlashcard();
    });
  }

  if (nextBtn) {
    nextBtn.addEventListener("click", () => {
      if (!appState.flashcards.length) return;
      currentFlashcardIndex =
        (currentFlashcardIndex + 1) % appState.flashcards.length;
      showFlashcardAnswer = false;
      renderFlashcard();
    });
  }

  if (toggleAnsBtn) {
    toggleAnsBtn.addEventListener("click", () => {
      showFlashcardAnswer = !showFlashcardAnswer;
      const backWrapper = document.getElementById("flashBackWrapper");
      if (backWrapper) {
        if (showFlashcardAnswer) {
          backWrapper.classList.remove("blurred");
        } else {
          backWrapper.classList.add("blurred");
        }
      }
      // text đang giống nhau theo yêu cầu trước đó
      toggleAnsBtn.textContent = "Xem";
    });
  }

  if (showAllBtn) {
    showAllBtn.addEventListener("click", () => {
      const grid = document.getElementById("flashAllGrid");
      if (!grid) return;

      const isHidden = grid.classList.contains("hidden");
      if (isHidden) {
        grid.classList.remove("hidden");
        showAllBtn.textContent = "Ẩn bớt";
      } else {
        grid.classList.add("hidden");
        showAllBtn.textContent = "Xem tất cả thẻ";
      }
    });
  }
}

function renderFlashcard() {
  const cardFront = document.getElementById("flashFront");
  const cardBack = document.getElementById("flashBack");
  const counter = document.getElementById("flashCounter");
  const difficultyBadge = document.getElementById("flashDifficulty");
  const backWrapper = document.getElementById("flashBackWrapper");

  if (!cardFront || !cardBack || !counter || !difficultyBadge || !backWrapper)
    return;

  if (!appState.flashcards.length) {
    cardFront.textContent = "Chưa có flashcard.";
    cardBack.textContent = "Hãy xử lý tài liệu trước.";
    counter.textContent = "0 / 0";
    difficultyBadge.textContent = "";
    difficultyBadge.className = "badge badge-difficulty";
    backWrapper.classList.add("blurred");
    return;
  }

  const item = appState.flashcards[currentFlashcardIndex] || {};
  cardFront.textContent =
    item.front || "Không có nội dung mặt trước (front) trong dữ liệu.";
  cardBack.textContent =
    item.back || "Không có nội dung mặt sau (back) trong dữ liệu.";
  counter.textContent = `${currentFlashcardIndex + 1} / ${
    appState.flashcards.length
  }`;

  const diff = (item.difficulty || "").toLowerCase();
  difficultyBadge.className = "badge badge-difficulty";
  if (diff === "hard") {
    difficultyBadge.classList.add("badge-hard");
    difficultyBadge.textContent = "Khó";
  } else if (diff === "medium") {
    difficultyBadge.classList.add("badge-medium");
    difficultyBadge.textContent = "Trung bình";
  } else {
    difficultyBadge.classList.add("badge-easy");
    difficultyBadge.textContent = "Dễ";
  }

  if (showFlashcardAnswer) {
    backWrapper.classList.remove("blurred");
  } else {
    backWrapper.classList.add("blurred");
  }
}

function renderFlashcardList() {
  const grid = document.getElementById("flashAllGrid");
  if (!grid) return;

  // Mỗi lần render lại thì mặc định ẨN list và reset text nút
  grid.classList.add("hidden");
  const showAllBtn = document.getElementById("flashShowAll");
  if (showAllBtn) {
    showAllBtn.textContent = "Xem tất cả thẻ";
  }

  grid.innerHTML = "";

  if (!appState.flashcards.length) {
    const p = document.createElement("p");
    p.className = "muted";
    p.textContent = "Chưa có flashcard.";
    grid.appendChild(p);
    return;
  }

  appState.flashcards.forEach((item, index) => {
    const card = document.createElement("div");
    card.className = "mini-flashcard";

    const title = document.createElement("div");
    title.className = "mini-flashcard-title";
    title.textContent = `Thẻ ${index + 1}`;

    const q = document.createElement("p");
    q.className = "mini-flashcard-front";
    q.textContent = item.front || "";

    const a = document.createElement("p");
    a.className = "mini-flashcard-back";
    a.textContent = item.back || "";

    card.appendChild(title);
    card.appendChild(q);
    card.appendChild(a);
    grid.appendChild(card);
  });
}

// ===== QUIZ =====

function renderQuizzes() {
  const container = document.getElementById("quizContent");
  if (!container) return;
  container.innerHTML = "";

  if (!appState.quizzes.length) {
    const p = document.createElement("p");
    p.className = "muted";
    p.textContent =
      "Chưa có câu hỏi quiz. Hãy xử lý tài liệu để sinh câu hỏi.";
    container.appendChild(p);

    const resultEl = document.getElementById("quizResult");
    if (resultEl) {
      resultEl.textContent = "Bạn chưa làm bài.";
      resultEl.className = "quiz-result muted";
    }
    return;
  }

  appState.quizzes.forEach((qItem, idx) => {
    const card = document.createElement("div");
    card.className = "quiz-card";
    card.dataset.index = idx;

    const header = document.createElement("div");
    header.className = "quiz-header";

    const title = document.createElement("div");
    title.className = "quiz-title";
    title.textContent = `Câu ${idx + 1}`;

    const typeBadge = document.createElement("span");
    typeBadge.className = "badge";
    if (qItem.type === "fill") {
  typeBadge.classList.add("badge-fill");
  typeBadge.textContent = "Điền khuyết";
} else if (qItem.type === "tf") {
  typeBadge.classList.add("badge-tf");
  typeBadge.textContent = "Đúng/Sai";
} else {
  typeBadge.classList.add("badge-mcq");
  typeBadge.textContent = "Trắc nghiệm";
}


    header.appendChild(title);
    header.appendChild(typeBadge);

    const question = document.createElement("p");
    question.className = "quiz-question";
    question.textContent = qItem.question || "";

    card.appendChild(header);
    card.appendChild(question);

    if (qItem.type === "mcq" && Array.isArray(qItem.options)) {
      const list = document.createElement("ul");
      list.className = "quiz-options";
      qItem.options.forEach((opt, optIdx) => {
        const li = document.createElement("li");
        const label = document.createElement("label");
        label.className = "quiz-option-label";
        const radio = document.createElement("input");
        radio.type = "radio";
        radio.name = `quiz-${idx}`;
        const valueLetter = String.fromCharCode(65 + optIdx); // A, B, C, D
        radio.value = valueLetter;
        const span = document.createElement("span");
        span.textContent = opt;
        label.appendChild(radio);
        label.appendChild(span);
        li.appendChild(label);
        list.appendChild(li);
      });
      card.appendChild(list);
    } else if (qItem.type === "tf") {
  const list = document.createElement("ul");
  list.className = "quiz-options";

  const tfOptions = [
    { text: "Đúng", value: "true" },
    { text: "Sai", value: "false" }
  ];

  tfOptions.forEach((opt) => {
    const li = document.createElement("li");
    const label = document.createElement("label");
    label.className = "quiz-option-label";

    const radio = document.createElement("input");
    radio.type = "radio";
    radio.name = `quiz-tf-${idx}`;
    radio.value = opt.value;

    const span = document.createElement("span");
    span.textContent = opt.text;

    label.appendChild(radio);
    label.appendChild(span);
    li.appendChild(label);
    list.appendChild(li);
  });

  card.appendChild(list);
} else {
  const input = document.createElement("input");
  input.type = "text";
  input.name = `quiz-fill-${idx}`;
  input.className = "quiz-fill-input";
  input.placeholder = "Nhập đáp án của bạn...";
  card.appendChild(input);
}

    const feedback = document.createElement("div");
    feedback.className = "quiz-feedback muted";
    feedback.id = `quiz-feedback-${idx}`;
    card.appendChild(feedback);

    container.appendChild(card);
  });

  const resultEl = document.getElementById("quizResult");
  if (resultEl) {
    resultEl.textContent = "Bạn chưa làm bài.";
    resultEl.className = "quiz-result muted";
  }
}

function setupQuizSubmit() {
  const btn = document.getElementById("submitQuizBtn");
  if (!btn) return;

  btn.addEventListener("click", () => {
    if (!appState.quizzes.length) return;

    let correctCount = 0;
    const total = appState.quizzes.length;

    appState.quizzes.forEach((qItem, idx) => {
      const feedback = document.getElementById(`quiz-feedback-${idx}`);
      const card = document.querySelector(`.quiz-card[data-index="${idx}"]`);
      if (feedback) {
        feedback.textContent = "";
        feedback.classList.remove(
          "quiz-feedback-correct",
          "quiz-feedback-wrong"
        );
      }
      if (card) {
        card.classList.remove("quiz-card-correct", "quiz-card-wrong");
      }

      let isCorrect = false;
let userAnsDisplay = "";
let correctAnsDisplay = "";

if (qItem.type === "tf") {
  const selected = document.querySelector(`input[name="quiz-tf-${idx}"]:checked`);
  const correctBool = normalizeTFAnswer(qItem.answer);
  correctAnsDisplay = correctBool === null ? "" : (correctBool ? "Đúng" : "Sai");

  if (selected) {
    const userBool = selected.value === "true";
    userAnsDisplay = userBool ? "Đúng" : "Sai";
    if (correctBool !== null && userBool === correctBool) {
      isCorrect = true;
    }
  }
} else if (qItem.type === "mcq") {
  const selected = document.querySelector(`input[name="quiz-${idx}"]:checked`);
  correctAnsDisplay = qItem.answer || "";

  if (selected) {
    const userValue = (selected.value || "").trim().toUpperCase();
    const correctValue = (qItem.answer || "").trim().toUpperCase();
    userAnsDisplay = userValue;
    if (userValue && correctValue && userValue === correctValue) {
      isCorrect = true;
    }
  }
} else {
  const input = document.querySelector(`input[name="quiz-fill-${idx}"]`);
  correctAnsDisplay = qItem.answer || "";

  if (input) {
    const userValue = (input.value || "").trim().toLowerCase();
    const correctValue = (qItem.answer || "").trim().toLowerCase();
    userAnsDisplay = input.value || "";
    if (userValue && correctValue && userValue === correctValue) {
      isCorrect = true;
    }
  }
}


      if (isCorrect) {
        correctCount += 1;
        if (feedback) {
          feedback.textContent = "Chính xác!";
          feedback.classList.add("quiz-feedback-correct");
        }
        if (card) {
          card.classList.add("quiz-card-correct");
        }
      } else {
        if (feedback) {
          feedback.textContent =
            `Sai. Đáp án đúng: ${correctAnsDisplay || "không rõ"}` +
            (userAnsDisplay ? ` · Bạn trả lời: ${userAnsDisplay}` : "");
          feedback.classList.add("quiz-feedback-wrong");
        }
        if (card) {
          card.classList.add("quiz-card-wrong");
        }
      }
    });

    const resultEl = document.getElementById("quizResult");
    if (resultEl) {
      const percent = Math.round((correctCount / total) * 100);
      resultEl.textContent = `Kết quả: đúng ${correctCount}/${total} câu (${percent}%).`;
      resultEl.className = "quiz-result";
    }
  });
}

// ===== ADD MORE QUIZ (tạo thêm quiz sau khi đã có dữ liệu) =====

function buildQuizContext() {
  const parts = [];

  if (appState.source_text && appState.source_text.trim().length) {
    parts.push(appState.source_text.trim());
  }
  if (appState.summary && appState.summary.trim().length) {
    parts.push("TÓM TẮT:\n" + appState.summary.trim());
  }
  if (Array.isArray(appState.flashcards) && appState.flashcards.length) {
    const lines = appState.flashcards.slice(0, 30).map((fc) => {
      const q = (fc.front || "").trim();
      const a = (fc.back || "").trim();
      return `- Q: ${q}\n  A: ${a}`;
    });
    parts.push("FLASHCARDS:\n" + lines.join("\n"));
  }

  // mindmap_mermaid thường không tốt bằng summary/flashcards làm context, nên chỉ thêm khi thiếu
  if (
    parts.join("\n\n").trim().length < 200 &&
    appState.mindmap_mermaid &&
    appState.mindmap_mermaid.trim().length
  ) {
    parts.push("MINDMAP (Mermaid):\n" + appState.mindmap_mermaid.trim());
  }

  return parts.join("\n\n");
}

function canGenerateMoreQuiz() {
  const ctx = buildQuizContext();
  return ctx && ctx.trim().length >= 80;
}

function updateAddQuizButtonState() {
  const btn = document.getElementById("addQuizBtn");
  if (!btn) return;
  btn.disabled = !canGenerateMoreQuiz();
}

function setupAddMoreQuizButton() {
  const btn = document.getElementById("addQuizBtn");
  if (!btn) return;

  btn.addEventListener("click", async () => {
    if (!canGenerateMoreQuiz()) {
      alert("Chưa đủ dữ liệu để tạo thêm quiz. Hãy xử lý tài liệu hoặc nhập dữ liệu có tóm tắt/flashcard.");
      return;
    }

    const defaultCount = 6;
    const countRaw = prompt("Tạo thêm bao nhiêu câu Quiz? (1–20)", String(defaultCount));
    if (countRaw === null) return;
    let count = parseInt(String(countRaw).trim(), 10);
    if (!Number.isFinite(count)) count = defaultCount;
    if (count < 1) count = 1;
    if (count > 20) count = 20;

    try {
      btn.disabled = true;
      btn.textContent = "Đang tạo...";

      const res = await safeFetchJSON("/api/generate_quiz", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          context: buildQuizContext(),
          existing_quizzes: appState.quizzes || [],
          count
        })
      });

      const newQuizzes = Array.isArray(res.quizzes) ? res.quizzes : [];
      if (!newQuizzes.length) {
        alert("Không tạo được câu hỏi mới. Bạn thử lại nhé.");
        return;
      }

      appState.quizzes = (appState.quizzes || []).concat(newQuizzes);
      renderQuizzes();
      updateSaveDbButtonState();
          updateAddQuizButtonState();
      updateAddQuizButtonState();

      alert(`Đã tạo thêm ${newQuizzes.length} câu Quiz!`);
    } catch (err) {
      console.error(err);
      alert(err.message || "Tạo thêm quiz thất bại.");
    } finally {
      btn.textContent = "+ Tạo thêm Quiz";
      updateAddQuizButtonState();
    }
  });

  updateAddQuizButtonState();
}


// ===== IMPORT / EXPORT DATA =====

function setupDataImportExport() {
  const exportBtn = document.getElementById("exportBtn");
  const importInput = document.getElementById("importFile");

  // Xuất dữ liệu
  if (exportBtn) {
    exportBtn.addEventListener("click", () => {
      const hasData =
        (appState.summary && appState.summary.trim().length) ||
        (appState.mindmap_mermaid &&
          appState.mindmap_mermaid.trim().length) ||
        (appState.flashcards && appState.flashcards.length) ||
        (appState.quizzes && appState.quizzes.length);

      if (!hasData) {
        alert("Chưa có dữ liệu để xuất. Hãy xử lý một tài liệu trước.");
        return;
      }

      const payload = {
        version: 1,
        exported_at: new Date().toISOString(),
        source_file: appState.source_file || null,
        source_text: appState.source_text || "",
        summary: appState.summary || "",
        mindmap_mermaid: appState.mindmap_mermaid || "",
        flashcards: appState.flashcards || [],
        quizzes: appState.quizzes || []
      };

      const blob = new Blob([JSON.stringify(payload, null, 2)], {
        type: "application/json"
      });

      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      const baseName =
        (appState.source_file &&
          appState.source_file.replace(/\.[^/.]+$/, "")) ||
        "ai_study_session";
      a.href = url;
      a.download = baseName + "_study_data.json";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    });
  }

  // Nhập dữ liệu
  if (importInput) {
    importInput.addEventListener("change", (e) => {
      const file = e.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (evt) => {
        try {
          const text = evt.target.result;
          const data = JSON.parse(text);

          appState.summary = data.summary || "";
          appState.mindmap_mermaid = data.mindmap_mermaid || "";
          appState.source_text = data.source_text || "";
          appState.source_text = data.source_text || "";
          appState.flashcards = Array.isArray(data.flashcards)
            ? data.flashcards
            : [];
          appState.quizzes = Array.isArray(data.quizzes)
            ? data.quizzes
            : [];
          appState.source_file =
            data.source_file || `Nhập từ: ${file.name}`;

          currentFlashcardIndex = 0;
          showFlashcardAnswer = false;

          enableContentTabs();
          renderSummary();
          renderMindmap();
          renderFlashcard();
          renderFlashcardList();
          renderQuizzes();
          updateSaveDbButtonState();
          updateAddQuizButtonState();
          updateAddFlashcardButtonState();
          switchToFirstResultTab();

          const uploadStatus = document.getElementById("uploadStatus");
          if (uploadStatus) {
            uploadStatus.className = "status status-success";
            uploadStatus.textContent =
              "Đã nhập dữ liệu từ file JSON. Bạn có thể xem ở các tab.";
          }
          const fileNameEl = document.getElementById("fileName");
          if (fileNameEl) {
            fileNameEl.textContent = `Đã nhập dữ liệu từ: ${file.name}`;
          }
        } catch (err) {
          console.error("Import error:", err);
          alert(
            "File không đúng định dạng JSON mà ứng dụng này xuất ra. Vui lòng kiểm tra lại."
          );
        }
      };

      reader.readAsText(file, "utf-8");
      e.target.value = "";
    });
  }
}

// ===== DB: Saved Sessions =====


// ===== ADD MORE FLASHCARDS =====
function buildFlashcardContext() {
  const parts = [];

  if (appState.source_text && appState.source_text.trim().length) {
    parts.push(appState.source_text.trim());
  }
  if (appState.summary && appState.summary.trim().length) {
    parts.push("TÓM TẮT:\n" + appState.summary.trim());
  }

  // Nếu có quiz, tận dụng câu hỏi như gợi ý nội dung
  if (Array.isArray(appState.quizzes) && appState.quizzes.length) {
    const lines = appState.quizzes
      .slice(0, 20)
      .map((q) => (q && q.question ? String(q.question).trim() : ""))
      .filter(Boolean)
      .map((t) => "- " + t);
    if (lines.length) {
      parts.push("CÂU HỎI QUIZ (tham khảo):\n" + lines.join("\n"));
    }
  }

  // mindmap chỉ thêm khi thiếu ngữ cảnh
  if (
    parts.join("\n\n").trim().length < 200 &&
    appState.mindmap_mermaid &&
    appState.mindmap_mermaid.trim().length
  ) {
    parts.push("MINDMAP (Mermaid):\n" + appState.mindmap_mermaid.trim());
  }

  return parts.join("\n\n");
}

function canGenerateMoreFlashcards() {
  const ctx = buildFlashcardContext();
  return ctx && ctx.trim().length >= 80;
}

function updateAddFlashcardButtonState() {
  const btn = document.getElementById("addFlashcardBtn");
  if (!btn) return;
  btn.disabled = !canGenerateMoreFlashcards();
}

function setupAddMoreFlashcardButton() {
  const btn = document.getElementById("addFlashcardBtn");
  if (!btn) return;

  btn.addEventListener("click", async () => {
    if (!canGenerateMoreFlashcards()) {
      alert(
        "Chưa đủ dữ liệu để tạo thêm flashcard. Hãy xử lý tài liệu hoặc nhập/tải dữ liệu có tóm tắt."
      );
      return;
    }

    const defaultCount = 8;
    const countRaw = prompt(
      "Tạo thêm bao nhiêu Flashcard? (1–30)",
      String(defaultCount)
    );
    if (countRaw === null) return;

    let count = parseInt(String(countRaw).trim(), 10);
    if (!Number.isFinite(count)) count = defaultCount;
    if (count < 1) count = 1;
    if (count > 30) count = 30;

    const oldText = btn.textContent;
    btn.disabled = true;
    btn.textContent = "Đang tạo...";

    try {
      const res = await safeFetchJSON("/api/generate_flashcards", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          context: buildFlashcardContext(),
          existing_flashcards: appState.flashcards || [],
          count
        })
      });

      const newCards = Array.isArray(res.flashcards) ? res.flashcards : [];
      if (!newCards.length) {
        alert("Không tạo được flashcard mới. Bạn thử lại nhé.");
        return;
      }

      appState.flashcards = (appState.flashcards || []).concat(newCards);

      // reset UI cho dễ ôn tập
      currentFlashcardIndex = Math.min(currentFlashcardIndex, appState.flashcards.length - 1);
      if (currentFlashcardIndex < 0) currentFlashcardIndex = 0;
      showFlashcardAnswer = false;

      renderFlashcard();
      renderFlashcardList();

      updateSaveDbButtonState();
      updateAddQuizButtonState(); // flashcards nhiều hơn => quiz có thể sinh tốt hơn
      updateAddFlashcardButtonState();

      alert(`Đã tạo thêm ${newCards.length} flashcard!`);
    } catch (err) {
      console.error(err);
      alert(err.message || "Tạo thêm flashcard thất bại.");
    } finally {
      btn.textContent = oldText || "+ Tạo thêm Flashcard";
      updateAddFlashcardButtonState();
    }
  });
}


async function safeFetchJSON(url, options) {
  const res = await fetch(url, options);
  if (!res.ok) {
    let msg = "Lỗi máy chủ.";
    try {
      const errData = await res.json();
      if (errData && errData.error) msg = errData.error;
    } catch (e) {}
    throw new Error(msg);
  }
  return res.json();
}

function setupSavedSessions() {
  const selectEl = document.getElementById("savedSessionsSelect");
  const saveDbBtn = document.getElementById("saveDbBtn");
  if (!selectEl) return;

  const refreshList = async (selectIdToFocus = null) => {
    try {
      selectEl.disabled = true;
      selectEl.innerHTML = `<option value="">Đang tải danh sách...</option>`;
      const items = await safeFetchJSON("/api/sessions", { method: "GET" });

      selectEl.innerHTML = "";
      const placeholder = document.createElement("option");
      placeholder.value = "";
      placeholder.textContent = items.length
        ? "Chọn bản ôn tập đã lưu..."
        : "Chưa có bản ôn tập nào";
      placeholder.selected = true;
      selectEl.appendChild(placeholder);

      items.forEach((it) => {
        const opt = document.createElement("option");
        opt.value = String(it.id);
        opt.textContent = it.display_name || it.base_name || `Session #${it.id}`;
        selectEl.appendChild(opt);
      });

      selectEl.disabled = !items.length;

      if (selectIdToFocus) {
        selectEl.value = String(selectIdToFocus);
      }
    } catch (err) {
      console.error(err);
      selectEl.innerHTML = `<option value="">Không tải được danh sách</option>`;
      selectEl.disabled = true;
    }
  };

  // expose để dùng ở nơi khác nếu cần
  window.__refreshSavedSessions = refreshList;

  // Load 1 session khi chọn combobox
  selectEl.addEventListener("change", async () => {
    const id = selectEl.value;
    if (!id) return;

    try {
      const payload = await safeFetchJSON(`/api/sessions/${id}`, {
        method: "GET"
      });

      const data = payload.data || {};
      appState.summary = data.summary || "";
          appState.mindmap_mermaid = data.mindmap_mermaid || "";
          appState.source_text = data.source_text || "";
          appState.source_text = data.source_text || "";
      appState.flashcards = Array.isArray(data.flashcards) ? data.flashcards : [];
      appState.quizzes = Array.isArray(data.quizzes) ? data.quizzes : [];

      // Hiển thị nguồn (để export cũng đẹp)
      appState.source_file =
        payload.source_file ||
        data.source_file ||
        (payload.display_name ? `Ôn tập: ${payload.display_name}` : "");

      currentFlashcardIndex = 0;
      showFlashcardAnswer = false;

      enableContentTabs();
      renderSummary();
      renderMindmap();
      renderFlashcard();
      renderFlashcardList();
      renderQuizzes();
      updateSaveDbButtonState();
          updateAddQuizButtonState();
      updateAddFlashcardButtonState();
      switchToFirstResultTab();

      const uploadStatus = document.getElementById("uploadStatus");
      if (uploadStatus) {
        uploadStatus.className = "status status-success";
        uploadStatus.textContent = `Đã tải bản ôn tập từ CSDL: ${payload.display_name || ""}`;
      }
      const fileNameEl = document.getElementById("fileName");
      if (fileNameEl) {
        fileNameEl.textContent = `Đang ôn tập: ${payload.display_name || ""}`;
      }
    } catch (err) {
      console.error(err);
      alert(err.message || "Không tải được bản ôn tập.");
    }
  });

  // Nút lưu vào DB
  if (saveDbBtn) {
    saveDbBtn.addEventListener("click", async () => {
      if (!hasStudyData()) {
        alert("Chưa có dữ liệu để lưu. Hãy xử lý tài liệu trước.");
        return;
      }

      const defaultName =
        (appState.source_file && appState.source_file.replace(/\.[^/.]+$/, "")) ||
        "ai_study_session";
      const name = prompt("Nhập tên bản ôn tập để lưu vào CSDL:", defaultName);
      if (name === null) return; // user bấm Cancel
      const trimmed = String(name).trim();
      if (!trimmed) {
        alert("Tên không được để trống.");
        return;
      }

      try {
        saveDbBtn.disabled = true;
        const result = await safeFetchJSON("/api/sessions", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            name: trimmed,
            source_file: appState.source_file || null,
    source_text: appState.source_text || "",
            data: buildStudyDataPayload()
          })
        });

        await refreshList(result.id);

        const uploadStatus = document.getElementById("uploadStatus");
        if (uploadStatus) {
          uploadStatus.className = "status status-success";
          uploadStatus.textContent = `Đã lưu vào CSDL: ${result.display_name || ""}`;
        }

        alert(`Đã lưu vào CSDL: ${result.display_name || ""}`);
      } catch (err) {
        console.error(err);
        alert(err.message || "Lưu vào CSDL thất bại.");
      } finally {
        updateSaveDbButtonState();
          updateAddQuizButtonState();
      }
    });
  }

  // Load list lần đầu
  refreshList();
  updateSaveDbButtonState();
          updateAddQuizButtonState();
}
