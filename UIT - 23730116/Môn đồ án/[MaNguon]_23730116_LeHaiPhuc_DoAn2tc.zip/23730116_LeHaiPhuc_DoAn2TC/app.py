# Le Hai Phuc - 23730116
import os
import json
import sqlite3
from datetime import datetime
from pathlib import Path

from flask import Flask, request, jsonify
from openai import OpenAI
from PyPDF2 import PdfReader
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"

# ===== SQLite DB (lưu "bản ôn tập") =====
# Mặc định tạo file DB ngay trong folder dự án.
# Có thể đổi đường dẫn bằng biến môi trường STUDY_DB_PATH trong .env.
DB_PATH = Path(os.getenv("STUDY_DB_PATH") or (BASE_DIR / "study_sessions.sqlite3"))


def get_db_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    """Tạo bảng sessions nếu chưa có."""
    conn = get_db_conn()
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            base_name TEXT NOT NULL,
            created_at TEXT NOT NULL,
            source_file TEXT,
            payload_json TEXT NOT NULL
        );
        """
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_sessions_created_at ON sessions(created_at);"
    )
    conn.commit()
    conn.close()


def make_display_name(base_name: str, created_at_iso: str) -> str:
    """Ghép tên hiển thị: <tên> - <ngày giờ lưu>."""
    try:
        dt = datetime.fromisoformat(created_at_iso)
        ts = dt.strftime("%d-%m-%Y %H:%M")
    except Exception:
        ts = created_at_iso
    base_name = (base_name or "").strip()
    return f"{base_name} - {ts}" if base_name else ts

load_dotenv()

app = Flask(__name__, static_folder=str(STATIC_DIR), static_url_path="")

# Khởi tạo DB khi app start
init_db()

api_key = os.getenv("OPENAI_API_KEY")
if not api_key:
    raise RuntimeError("OPENAI_API_KEY chưa được cấu hình. Hãy tạo file .env hoặc biến môi trường.")

# Uncomment dong duoi day de su dung API key thu 1. Luu y cau hinh trong file .env
# client = OpenAI(api_key=api_key)

# Uncomment dong duoi day de su dung API key thu 2. Luu y cau hinh trong file .env

client = OpenAI(
    api_key=api_key,
    base_url="https://gpt1.shupremium.com/v1",
)

SYSTEM_PROMPT = """
Bạn là trợ lý học tập AI. Nhiệm vụ của bạn là chuyển một tài liệu học tập thành:
- Tóm tắt ngắn gọn, dễ học (tiếng Việt).
- Sơ đồ tư duy dạng code Mermaid.
- Bộ flashcard (hỏi - đáp) có mức độ khó.
- Bộ câu hỏi quiz trắc nghiệm (A/B/C/D) đúng/sai và điền khuyết.

YÊU CẦU ĐỊNH DẠNG:
- Trả về DUY NHẤT một JSON hợp lệ, không có giải thích, không có Markdown, không có ```.
- Mọi nội dung là tiếng Việt nếu tài liệu là tiếng Việt.
- Tuân thủ đúng schema sau:

{
  "summary": "chuỗi văn bản, có thể gồm nhiều đoạn hoặc bullet, tóm tắt những ý chính",
  "mindmap_mermaid": "chuỗi code Mermaid, kiểu mindmap hoặc flowchart, nút trung tâm là chủ đề chính",
  "flashcards": [
    {
      "front": "câu hỏi/ngắn gọn, 1 khái niệm cần nhớ",
      "back": "câu trả lời/nghĩa đầy đủ, súc tích",
      "difficulty": "easy" hoặc "medium" hoặc "hard"
    }
  ],
  "quizzes": [
    {
      "type": "mcq",
      "question": "câu hỏi trắc nghiệm",
      "options": ["A. ...", "B. ...", "C. ...", "D. ..."],
      "answer": "A"  // chỉ là ký tự A/B/C/D
    },
    {
      "type": "fill",
      "question": "câu có chỗ trống ____ cần điền",
      "answer": "đáp án đúng"
    },
    {
    "type": "tf",
    "question": "phát biểu đúng hay sai",
    "answer": true
    }
  ]
}

- Hãy tạo 8–15 flashcard.
- Hãy tạo 8–12 câu hỏi quiz, khoảng 60% trắc nghiệm 20% đúng/sai và 20% điền khuyết.
"""

QUIZ_ONLY_PROMPT = """
Bạn là trợ lý tạo câu hỏi quiz để ôn tập.

YÊU CẦU ĐỊNH DẠNG:
- Trả về DUY NHẤT một JSON hợp lệ, không có giải thích, không có Markdown, không có ```.

Schema bắt buộc:
{
  "quizzes": [
    {
      "type": "mcq",
      "question": "câu hỏi trắc nghiệm",
      "options": ["A. ...", "B. ...", "C. ...", "D. ..."],
      "answer": "A"  // chỉ là ký tự A/B/C/D
    },
    {
      "type": "fill",
      "question": "câu có chỗ trống ____ cần điền",
      "answer": "đáp án đúng"
    },
    {
      "type": "tf",
      "question": "phát biểu đúng hay sai",
      "answer": true
    }
  ]
}

RÀNG BUỘC CHẤT LƯỢNG:
- Tạo ĐÚNG SỐ LƯỢNG câu hỏi được yêu cầu.
- Tỷ lệ gợi ý: 60% mcq, 20% tf, 20% fill.
- Với mcq: luôn có đúng 4 options và answer phải là A/B/C/D.
- Tránh lặp lại ý/câu hỏi đã có (danh sách câu hỏi có sẵn sẽ được cung cấp).
- Nội dung tiếng Việt, ngắn gọn, rõ ràng.
"""


FLASHCARD_ONLY_PROMPT = """
Bạn là trợ lý tạo flashcard để ôn tập.

YÊU CẦU ĐỊNH DẠNG:
- Trả về DUY NHẤT một JSON hợp lệ, không có giải thích, không có Markdown, không có ```.

Schema bắt buộc:
{
  "flashcards": [
    {
      "front": "câu hỏi / khái niệm",
      "back": "câu trả lời / giải thích ngắn gọn",
      "difficulty": "easy" | "medium" | "hard"
    }
  ]
}

RÀNG BUỘC CHẤT LƯỢNG:
- Tạo ĐÚNG SỐ LƯỢNG flashcard được yêu cầu.
- Nội dung tiếng Việt, ngắn gọn, rõ ràng, đúng trọng tâm.
- Tránh lặp lại mặt trước (front) đã có (danh sách front có sẵn sẽ được cung cấp).
- Phân bổ độ khó gợi ý: ~50% easy, ~35% medium, ~15% hard.
"""


def extract_text_from_file(file_storage) -> str:
    """Trích xuất văn bản từ PDF hoặc file text đơn giản."""
    filename = (file_storage.filename or "").lower()

    if filename.endswith(".pdf"):
        reader = PdfReader(file_storage)
        texts = []
        for page in reader.pages:
            try:
                texts.append(page.extract_text() or "")
            except Exception:
                continue
        return "\n".join(texts)

    # Các định dạng khác: cố gắng đọc như text
    raw = file_storage.read()
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return raw.decode("latin-1", errors="ignore")

def strip_json_code_fences(text: str) -> str:
    """Loại bỏ ```json ``` nếu mô hình lỡ trả về trong code block."""
    text = text.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        # bỏ dòng đầu nếu là ``` hoặc ```json
        if lines and lines[0].strip().startswith("```"):
            lines = lines[1:]
        # bỏ dòng cuối nếu là ```
        if lines and lines[-1].strip().startswith("```"):
            lines = lines[:-1]
        text = "\n".join(lines).strip()
    return text

def generate_learning_materials(document_text: str) -> dict:
    """Gọi OpenAI để sinh tóm tắt, mindmap, flashcard, quiz."""
    # Giới hạn độ dài tránh quá nhiều token
    max_chars = 8000
    shortened = document_text[:max_chars]

    user_prompt = (
        "Hãy đọc tài liệu sau và tạo JSON đúng schema đã cho.\n"
        "Tài liệu:\n\n"
        f"{shortened}"
    )

    response = client.chat.completions.create(
        model="gpt-4.1-mini",  # hoặc gpt-4.1-mini nếu tài khoản bạn chưa có gpt-5
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt},
        ],
        temperature=0.4,
    )

    content = response.choices[0].message.content or ""
    content = strip_json_code_fences(content)

    data = json.loads(content)

    # Đảm bảo các key luôn tồn tại
    return {
        "summary": data.get("summary", ""),
        "mindmap_mermaid": data.get("mindmap_mermaid", ""),
        "flashcards": data.get("flashcards", []),
        "quizzes": data.get("quizzes", []),
        "source_text": shortened,
    }

@app.route("/")
def index():
    return app.send_static_file("index.html")

@app.route("/api/process_document", methods=["POST"])
def process_document():
    if "file" not in request.files:
        return jsonify({"error": "Không tìm thấy tệp upload (field name 'file')."}), 400

    file = request.files["file"]

    if not file.filename:
        return jsonify({"error": "Tên tệp trống."}), 400

    try:
        text = extract_text_from_file(file)
    except Exception as e:
        return jsonify({"error": f"Lỗi khi đọc tệp: {e}"}), 500

    if not text or not text.strip():
        return jsonify({"error": "Không trích xuất được nội dung văn bản từ tệp."}), 400

    try:
        result = generate_learning_materials(text)
    except json.JSONDecodeError:
        return jsonify({"error": "Mô hình trả về JSON không hợp lệ. Hãy thử lại."}), 500
    except Exception as e:
        # Trong thực tế bạn nên log kỹ hơn
        print("OpenAI API error:", repr(e))
        return jsonify({"error": "Lỗi khi gọi OpenAI API. Kiểm tra API key / quota."}), 500

    return jsonify(result)




def generate_more_flashcards(context_text: str, existing_fronts: list[str], count: int) -> dict:
    """Gọi OpenAI để sinh thêm flashcards từ context (tóm tắt/đoạn trích/quiz)."""
    max_chars = 8000
    shortened = (context_text or "")[:max_chars]

    existing_fronts = [str(f).strip() for f in (existing_fronts or []) if str(f).strip()]
    existing_fronts = existing_fronts[:60]

    user_prompt = (
        f"Hãy tạo thêm đúng {count} flashcard từ nội dung sau.\n\n"
        "NỘI DUNG (context):\n"
        f"{shortened}\n\n"
        "DANH SÁCH MẶT TRƯỚC (front) ĐÃ CÓ (tránh lặp):\n"
        + ("\n".join([f"- {f}" for f in existing_fronts]) if existing_fronts else "- (chưa có)\n")
    )

    response = client.chat.completions.create(
        model="gpt-4.1-mini",
        messages=[
            {"role": "system", "content": FLASHCARD_ONLY_PROMPT},
            {"role": "user", "content": user_prompt},
        ],
        temperature=0.6,
    )

    content = response.choices[0].message.content or ""
    content = strip_json_code_fences(content)
    data = json.loads(content)

    flashcards = data.get("flashcards", [])
    if not isinstance(flashcards, list):
        flashcards = []

    # Chuẩn hóa difficulty
    normed = []
    for item in flashcards:
        if not isinstance(item, dict):
            continue
        front = str(item.get("front") or "").strip()
        back = str(item.get("back") or "").strip()
        diff = str(item.get("difficulty") or "easy").strip().lower()
        if diff not in ("easy", "medium", "hard"):
            diff = "easy"
        if not front or not back:
            continue
        normed.append({"front": front, "back": back, "difficulty": diff})

    return {"flashcards": normed}


@app.route("/api/generate_flashcards", methods=["POST"])
def api_generate_flashcards():
    """Sinh thêm flashcard từ context hiện tại (dùng cho nút 'Tạo thêm Flashcard')."""
    payload = request.get_json(silent=True) or {}
    context = payload.get("context") or ""
    count = payload.get("count") or 8
    existing = payload.get("existing_flashcards") or []

    existing_fronts = []
    if isinstance(existing, list):
        for item in existing:
            if isinstance(item, dict) and item.get("front"):
                existing_fronts.append(item.get("front"))

    try:
        count = int(count)
    except Exception:
        count = 8

    if count < 1:
        count = 1
    if count > 30:
        count = 30

    if not isinstance(context, str) or len(context.strip()) < 30:
        return jsonify({"error": "Thiếu context để tạo flashcard. Hãy xử lý tài liệu hoặc tải dữ liệu có tóm tắt."}), 400

    try:
        result = generate_more_flashcards(context, existing_fronts, count)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e) or "Tạo flashcard thất bại."}), 500




def generate_more_quizzes(context_text: str, existing_questions: list[str], count: int) -> dict:
    """Gọi OpenAI để sinh thêm câu hỏi quiz từ context (tóm tắt/flashcards/đoạn trích)."""
    max_chars = 8000
    shortened = (context_text or "")[:max_chars]

    # Giới hạn danh sách câu đã có để prompt không quá dài
    existing_questions = [str(q).strip() for q in (existing_questions or []) if str(q).strip()]
    existing_questions = existing_questions[:40]

    user_prompt = (
        f"Hãy tạo thêm đúng {count} câu hỏi quiz từ nội dung sau.\n\n"
        "NỘI DUNG (context):\n"
        f"{shortened}\n\n"
        "DANH SÁCH CÂU HỎI ĐÃ CÓ (tránh lặp):\n"
        + ("\n".join([f"- {q}" for q in existing_questions]) if existing_questions else "- (chưa có)\n")
    )

    response = client.chat.completions.create(
        model="gpt-4.1-mini",
        messages=[
            {"role": "system", "content": QUIZ_ONLY_PROMPT},
            {"role": "user", "content": user_prompt},
        ],
        temperature=0.5,
    )

    content = response.choices[0].message.content or ""
    content = strip_json_code_fences(content)
    data = json.loads(content)

    quizzes = data.get("quizzes", [])
    if not isinstance(quizzes, list):
        quizzes = []

    return {"quizzes": quizzes}


@app.route("/api/generate_quiz", methods=["POST"])
def api_generate_quiz():
    """Sinh thêm quiz từ context hiện tại (dùng cho nút 'Tạo thêm Quiz')."""
    payload = request.get_json(silent=True) or {}
    context = payload.get("context") or ""
    count = payload.get("count") or 6
    existing = payload.get("existing_quizzes") or []

    # Lấy danh sách câu hỏi đã có để chống trùng
    existing_questions = []
    if isinstance(existing, list):
        for item in existing:
            if isinstance(item, dict) and item.get("question"):
                existing_questions.append(item.get("question"))

    try:
        count = int(count)
    except Exception:
        count = 6

    if count < 1:
        count = 1
    if count > 20:
        count = 20

    if not isinstance(context, str) or len(context.strip()) < 30:
        return jsonify({"error": "Thiếu context để tạo quiz. Hãy xử lý tài liệu hoặc nhập dữ liệu có tóm tắt/flashcard."}), 400

    try:
        result = generate_more_quizzes(context, existing_questions, count)
    except json.JSONDecodeError:
        return jsonify({"error": "Mô hình trả về JSON không hợp lệ. Hãy thử lại."}), 500
    except Exception as e:
        print("OpenAI API error:", repr(e))
        return jsonify({"error": "Lỗi khi gọi OpenAI API. Kiểm tra API key / quota."}), 500

    return jsonify(result)


# ===== DB API: Lưu / tải "bản ôn tập" =====

@app.route("/api/sessions", methods=["GET"])
def list_sessions():
    """Trả về danh sách các bản ôn tập đã lưu (mới nhất trước)."""
    conn = get_db_conn()
    rows = conn.execute(
        "SELECT id, base_name, created_at, source_file FROM sessions ORDER BY datetime(created_at) DESC, id DESC"
    ).fetchall()
    conn.close()

    items = []
    for r in rows:
        items.append(
            {
                "id": r["id"],
                "base_name": r["base_name"],
                "created_at": r["created_at"],
                "source_file": r["source_file"],
                "display_name": make_display_name(r["base_name"], r["created_at"]),
            }
        )
    return jsonify(items)


@app.route("/api/sessions", methods=["POST"])
def save_session():
    """Lưu 1 bản ôn tập.

    Body JSON:
    {
      "name": "Tên người dùng nhập",
      "source_file": "optional",
      "data": { ... schema giống export JSON ... }
    }
    """
    payload = request.get_json(silent=True) or {}
    base_name = (payload.get("name") or "").strip()
    if not base_name:
        return jsonify({"error": "Thiếu tên bản ôn tập (name)."}), 400

    data = payload.get("data")
    if not isinstance(data, dict):
        return jsonify({"error": "Thiếu hoặc sai định dạng data (phải là object JSON)."}), 400

    created_at = datetime.now().isoformat(timespec="seconds")
    source_file = payload.get("source_file")

    try:
        data_json = json.dumps(data, ensure_ascii=False)
    except Exception:
        return jsonify({"error": "Không thể serialize dữ liệu để lưu."}), 400

    conn = get_db_conn()
    cur = conn.execute(
        "INSERT INTO sessions(base_name, created_at, source_file, payload_json) VALUES (?,?,?,?)",
        (base_name, created_at, source_file, data_json),
    )
    conn.commit()
    new_id = cur.lastrowid
    conn.close()

    return jsonify(
        {
            "id": new_id,
            "base_name": base_name,
            "created_at": created_at,
            "display_name": make_display_name(base_name, created_at),
        }
    )


@app.route("/api/sessions/<int:session_id>", methods=["GET"])
def load_session(session_id: int):
    """Tải 1 bản ôn tập theo id."""
    conn = get_db_conn()
    r = conn.execute(
        "SELECT id, base_name, created_at, source_file, payload_json FROM sessions WHERE id = ?",
        (session_id,),
    ).fetchone()
    conn.close()

    if not r:
        return jsonify({"error": "Không tìm thấy bản ôn tập."}), 404

    try:
        data = json.loads(r["payload_json"])
    except Exception:
        data = {}

    return jsonify(
        {
            "id": r["id"],
            "base_name": r["base_name"],
            "created_at": r["created_at"],
            "source_file": r["source_file"],
            "display_name": make_display_name(r["base_name"], r["created_at"]),
            "data": data,
        }
    )

if __name__ == "__main__":
    # Chạy server dev
    port = int(os.getenv("PORT") or 5000)
    app.run(host="0.0.0.0", port=port, debug=True)
