@echo off
echo ==== SETUP - Web ho tro hoc tap - 23730116 - Le Hai Phuc - Do An ====

REM Chuyen thu muc lam viec hien tai ve thu muc cua file BAT
cd /d "%~dp0"

REM Thu dung 'py' neu co, neu khong thi dung 'python'
py --version >nul 2>&1
IF %ERRORLEVEL% EQU 0 (
  set "PYCMD=py -3"
) ELSE (
  python --version >nul 2>&1
  IF %ERRORLEVEL% EQU 0 (
    set "PYCMD=python"
  ) ELSE (
    echo Khong tim thay Python 3.x. Vui long cai Python va them vao PATH.
    pause
    exit /b 1
  )
)

REM Xoa venv cu neu co (tranh dinh vao python 3.11 cu)
IF EXIST venv (
  echo Xoa virtual environment cu...
  rmdir /S /Q venv
)

echo Tao virtual environment moi...
%PYCMD% -m venv venv

call venv\Scripts\activate

echo.
echo Nang cap pip va cai thu vien...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

echo.
echo Nho tao file .env va dat OPENAI_API_KEY=...
echo.

python app.py
pause
