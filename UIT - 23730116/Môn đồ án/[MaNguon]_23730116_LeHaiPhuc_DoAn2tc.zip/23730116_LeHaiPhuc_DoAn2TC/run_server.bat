@echo off
echo ==== RUN - Web ho tro hoc tap - 23730116 - Le Hai Phuc - Do An ====

REM Luon chuyen ve thu muc chua file BAT (thu muc project)
cd /d "%~dp0"

REM Kiem tra venv
IF NOT EXIST venv (
  echo Khong tim thay thu muc venv.
  echo Hay chay setup_and_run.bat hoac tu tay tao venv va cai requirements.txt truoc.
  pause
  exit /b 1
)

REM Kich hoat virtualenv
call venv\Scripts\activate

echo Dang chay app.py ...
echo (Neu muon dung lai, nhan Ctrl+C trong cua so nay)

python app.py

pause
