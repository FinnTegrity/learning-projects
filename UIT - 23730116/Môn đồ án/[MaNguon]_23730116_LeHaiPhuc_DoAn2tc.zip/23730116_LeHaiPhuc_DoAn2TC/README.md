
# Ứng dụng web hỗ trợ học tập: chuyển tài liệu thành tóm tắt, flashcard, quiz và sơ đồ tư duy.

- **Sinh viên:** UIT - 23730116 – Lê Hải Phúc  
- **Mô tả ngắn:** Ứng dụng web cho phép tải tài liệu PDF/TXT, sau đó dùng OpenAI để sinh:
  - Bản **tóm tắt** nội dung
  - **Sơ đồ tư duy** dưới dạng code Mermaid
  - Bộ **flashcard** hỏi – đáp
  - Bộ **câu hỏi quiz** (trắc nghiệm + điền khuyết) có chấm điểm trực tiếp trên web

---

## 1. Mục tiêu & bối cảnh

Đây là đồ án xây dựng **ứng dụng web hỗ trợ học tập**, tập trung vào:

- Tự động **chuyển đổi tài liệu** (đặc biệt là tài liệu học tập) thành:
  - Tóm tắt kiến thức chính
  - Sơ đồ tư duy Mindmap
  - Bộ thẻ ghi nhớ (flashcard)
  - Bộ câu hỏi quiz để tự kiểm tra
- Giao diện **web hiện đại, sáng sủa**, dễ dùng, hoạt động trên browser không cần cài app.
- Tận dụng **OpenAI (GPT-4.1-mini)** để xử lý ngôn ngữ tự nhiên.
- Hướng tới việc áp dụng các kỹ thuật **khai thác dữ liệu, gợi ý, Machine Learning** trong các phiên bản mở rộng.

Ứng dụng phù hợp cho sinh viên, giáo viên, người tự học muốn tiết kiệm thời gian tóm tắt và tạo câu hỏi từ tài liệu PDF/TXT.

---

## 2. Tính năng chính

### 2.1. Tải & xử lý tài liệu

- Hỗ trợ:
  - **PDF** (đọc nội dung bằng `PyPDF2`)
  - **TXT** (và các file text đơn giản)
- Giao diện upload:
  - Khu vực **“Chọn tệp từ máy / kéo thả tại đây”**
  - Hiển thị tên tệp đã chọn
  - Trạng thái upload:
    - `Chưa tải tệp lên.`
    - `Đang tải tệp lên...`
    - `Tải tệp lên thành công!`
- Nút **“Xử lý với AI”**:
  - Có trạng thái disabled/enabled rõ ràng
  - Khi xử lý:
    - Hiện spinner nhỏ trong nút
    - Label đổi thành **“Đang xử lý...”**
  - Sau khi xử lý xong:
    - Hiện thông báo **“Xử lý xong! Bạn có thể mở các tab để xem kết quả.”**
    - Tự chuyển sang tab **Tóm tắt** đầu tiên

Lưu ý: Chất lượng tốt nhất khi tài liệu là **PDF hoặc TXT**; các định dạng khác nên chuyển sang PDF/TXT trước.

---

### 2.2. Tóm tắt tài liệu

Tab **“Tóm tắt”** hiển thị:

- Nội dung tóm tắt được sinh bởi AI:
  - Có thể bao gồm nhiều đoạn hoặc bullet
  - Giúp người dùng nhanh chóng nắm ý chính
- Giao diện:
  - Hiển thị trong một **card** riêng
  - Tối ưu để **dễ đọc** trên màn hình desktop

Dữ liệu lấy từ trường `summary` trong JSON trả về của API.

---

### 2.3. Mindmap (Sơ đồ tư duy)

Tab **“Mindmap”**:

- Hiển thị sơ đồ tư duy dưới dạng **Mermaid**:
  - AI sinh ra trường `mindmap_mermaid` (code Mermaid).
  - Frontend dùng thư viện **Mermaid** (CDN) để render thành SVG.
- Tính năng:
  - Vùng hiển thị sơ đồ (SVG) với nền tối nhẹ, dễ quan sát.
  - Nút **“Copy code Mermaid”**:
    - Copy toàn bộ code mindmap vào clipboard.
    - Khi copy thành công, label sẽ đổi thành **“Đã copy!”** trong một khoảng thời gian ngắn.

Yêu cầu có **kết nối Internet** để load thư viện Mermaid qua CDN. Nếu Mermaid không load được, ứng dụng sẽ hiện thông báo lỗi mềm: “Mermaid chưa tải được...”.

---

### 2.4. Flashcard

Tab **“Flashcard”** cho phép học theo dạng thẻ ghi nhớ:

- Dữ liệu từ trường `flashcards` (mảng) trong JSON:
  - Mỗi phần tử có dạng:
    ```json
    {
      "front": "câu hỏi / khái niệm cần nhớ",
      "back": "đáp án / giải thích",
      "difficulty": "easy" | "medium" | "hard"
    }
    ```
  - AI được yêu cầu tạo **8–15 flashcard**.

- Giao diện học thẻ:
  - 1 thẻ trung tâm:
    - **Mặt trước** (front): câu hỏi / khái niệm.
    - **Mặt sau** (back): câu trả lời, có thể ẩn/hiện.
  - Bộ nút điều khiển:
    - `‹` (Prev): chuyển sang thẻ trước.
    - `›` (Next): chuyển sang thẻ sau.
    - Nút **“Hiện/Ẩn đáp án”** (toggle answer).
  - Badge **mức độ khó** (easy/medium/hard) đổi màu tương ứng.
  - Bộ đếm: `current / total` (ví dụ 3 / 10).

- Xem tất cả flashcard:
  - Nút **“Xem tất cả thẻ”**:
    - Mở dạng **grid** hiển thị toàn bộ thẻ (front + back).
    - Giúp người dùng nhìn tổng quan tất cả flashcard một lần.

---

### 2.5. Quiz (Câu hỏi trắc nghiệm & điền khuyết)

Tab **“Quiz”** dùng để tự kiểm tra kiến thức:

- Dữ liệu từ trường `quizzes` trong JSON:
  - AI được yêu cầu tạo **8–12 câu hỏi**, trong đó khoảng:
    - **70% trắc nghiệm** (MCQ)
    - **30% điền khuyết** (fill-in-the-blank)
  - Mỗi câu quiz có cấu trúc:
    ```json
    // Câu trắc nghiệm
    {
      "type": "mcq",
      "question": "Câu hỏi trắc nghiệm...",
      "options": ["A. ...", "B. ...", "C. ...", "D. ..."],
      "answer": "A"  // một ký tự A/B/C/D
    }

    // Câu điền khuyết
    {
      "type": "fill",
      "question": "Câu có chỗ trống ____ cần điền",
      "answer": "đáp án đúng"
    }
    ```

- Giao diện làm bài:
  - Mỗi câu là một **card** riêng:
    - Hiển thị số câu, nội dung câu hỏi.
    - MCQ: list các lựa chọn với radio button.
    - Fill: ô input để nhập đáp án.
  - Nút **“Nộp bài”**:
    - Chấm điểm tất cả câu.
    - Mỗi câu:
      - Hiển thị feedback:
        - “Chính xác!”
        - Hoặc “Sai. Đáp án đúng: … · Bạn trả lời: …”
      - Tô màu card đúng/sai (xanh/đỏ nhẹ).
    - Hiển thị kết quả tổng:
      - Ví dụ: `Kết quả: đúng 7/10 câu (70%).`

---

### 2.6. Giao diện & trải nghiệm người dùng

- Thiết kế **sáng, hiện đại, phong cách “app”**:
  - Background gradient nhẹ từ góc trên trái.
  - App-shell bo góc lớn, bóng nhẹ, giống card iOS.
  - Sử dụng font **Inter** (Google Fonts).
- Thanh tab trên cùng:
  - `Trang chủ` – `Tóm tắt` – `Mindmap` – `Flashcard` – `Quiz`
  - Trước khi xử lý, các tab kết quả bị **disable** (xám + `tab-disabled`).
- Hiệu ứng UX:
  - Trạng thái hover, focus rõ ràng.
  - Các thông báo trạng thái (status) dùng màu:
    - Mặc định / Loading / Success / Error.
  - Spinner cho nút xử lý AI.
- Footer:
  - Ghi chú đây là **demo ứng dụng web hỗ trợ học tập** của sinh viên 23730116 – Lê Hải Phúc.

---

## 3. Kiến trúc & công nghệ

### 3.1. Backend

- **Ngôn ngữ:** Python
- **Framework:** [Flask](https://flask.palletsprojects.com/)
- **Thư viện chính:**
  - `openai` – gọi OpenAI Chat Completions API
  - `PyPDF2` – đọc nội dung PDF
  - `python-dotenv` – load biến môi trường từ `.env`
- **File chính:** `app.py`
  - Cấu hình:
    - Đọc biến môi trường `OPENAI_API_KEY`.
    - Khởi tạo `OpenAI` client.
  - Endpoint:
    - `GET /`
      - Trả về file `static/index.html`.
    - `POST /api/process_document`
      - Nhận file upload (`multipart/form-data`, field name `file`).
      - Gọi hàm `extract_text_from_file()` để lấy text.
      - Gọi `generate_learning_materials(text)` để gửi prompt lên OpenAI.
      - Trả JSON:
        ```json
        {
          "summary": "...",
          "mindmap_mermaid": "mindmap code...",
          "flashcards": [ ... ],
          "quizzes": [ ... ]
        }
        ```

  - Xử lý lỗi:
    - Thiếu file upload → HTTP 400.
    - Lỗi đọc file → HTTP 500 với thông báo “Lỗi khi đọc tệp: …”.
    - Lỗi JSON (mô hình trả về không đúng schema) → HTTP 500.
    - Lỗi OpenAI API (key/quota/kết nối) → HTTP 500.

  - Cấu hình chạy:
    - Host: `0.0.0.0`
    - Port: `5000` (có thể override qua biến môi trường `PORT`).

---

### 3.2. Frontend

- **Công nghệ:** HTML + CSS + JavaScript thuần (không framework).
- **File:**
  - `static/index.html` – giao diện chính, single-page.
  - `static/styles.css` – style, layout, màu sắc.
  - `static/script.js` – logic xử lý UI & gọi API.
  - `static/uit.png` – icon (favicon/logo).

- **Thư viện bên ngoài:**
  - Google Fonts – `Inter`.
  - Mermaid.js (CDN) – render sơ đồ tư duy từ code.

- **Luồng hoạt động ở frontend:**
  1. Người dùng chọn/kéo thả tệp → script bắt sự kiện và hiển thị trạng thái tải.
  2. Khi click **“Xử lý với AI”**:
     - JavaScript tạo `FormData`, append file.
     - Gọi `fetch("/api/process_document", { method: "POST", body: formData })`.
  3. Backend trả JSON → script cập nhật `appState`:
     - `summary`
     - `mindmap_mermaid`
     - `flashcards`
     - `quizzes`
  4. Gọi các hàm `renderSummary`, `renderMindmap`, `renderFlashcard`, `renderQuizzes` để hiển thị.

---

## 4. Cấu trúc thư mục

Sau khi giải nén, cấu trúc chính:

```text
23730116_LeHaiPhuc_DoAn2TC/
├─ app.py               # Flask backend, endpoint API
├─ requirements.txt     # Danh sách thư viện Python
├─ setup.bat            # Script setup + chạy app cho Windows
├─ run_server.bat        # Script chạy app dựa trên venv đã có
├─ .env                 # Chứa OPENAI_API_KEY
├─ static/
│  ├─ index.html        # Giao diện web
│  ├─ styles.css        # CSS
│  ├─ script.js         # JS logic
│  └─ uit.png           # Icon/logo
└─ venv/                # Virtualenv
```

---

## 5. Hướng dẫn cài đặt & chạy

### 5.1. Yêu cầu hệ thống

- Python **3.x** (khuyến nghị 3.10+).
- Kết nối Internet để:
  - Gọi OpenAI API.
  - Load Mermaid từ CDN.
- Một **OpenAI API key** hợp lệ.

---

### 5.2. Cách 1 – Dành cho Windows (dùng file `.bat`)

1. Giải nén thư mục project, ví dụ:
   ```text
   D:\Projects\23730116_LeHaiPhuc_DoAn2TC
   ```

2. Mở **Command Prompt** (hoặc double-click cũng được) và chạy:

   #### Lần đầu cài đặt
   ```bat
   setup.bat
   ```
   Script sẽ:
   - Kiểm tra có Python 3.x chưa.
   - Xóa `venv` cũ (nếu có).
   - Tạo `venv` mới.
   - Cài thư viện từ `requirements.txt`.
   - Nhắc tạo file `.env` với `OPENAI_API_KEY`.

3. Tạo (hoặc chỉnh sửa) file `.env` trong thư mục project:

   ```env
   OPENAI_API_KEY=your_openai_api_key_here
   ```

4. Sau khi setup xong, lần sau muốn chạy nhanh chỉ cần:

   ```bat
   run_server.bat
   ```

5. Mở trình duyệt và truy cập:

   - `http://localhost:5000`

---

### 5.3. Cách 2 – Thủ công (Windows / macOS / Linux)

1. Mở terminal, cd vào thư mục project:

   ```bash
   cd 23730116_LeHaiPhuc_DoAn2TC
   ```

2. Tạo virtualenv:

   ```bash
   python -m venv venv
   ```

3. Kích hoạt:

   - Windows:
     ```bash
     venv\Scripts\activate
     ```
   - macOS / Linux:
     ```bash
     source venv/bin/activate
     ```

4. Cài đặt thư viện:

   ```bash
   pip install --upgrade pip
   pip install -r requirements.txt
   ```

5. Tạo file `.env`:

   ```env
   OPENAI_API_KEY=your_openai_api_key_here
   ```

6. Chạy server:

   ```bash
   python app.py
   ```

7. Mở trình duyệt tại:

   ```text
   http://localhost:5000
   ```

---

## 6. Cách sử dụng chi tiết

1. **Mở ứng dụng**  
   Truy cập `http://localhost:5000`.

2. **Tải tài liệu**  
   Tại tab **Trang chủ**:
   - Click vào vùng “Chọn tệp từ máy” hoặc kéo-thả file vào.
   - Chờ trạng thái chuyển sang **“Tải tệp lên thành công!”**.

3. **Xử lý với AI**  
   - Nhấn nút **“Xử lý với AI”**.
   - Quan sát trạng thái:
     - Nút hiển thị “Đang xử lý…”
     - Dòng status: “Đang xử lý tài liệu với AI...”
   - Khi xong, ứng dụng sẽ:
     - Hiển thị thông báo thành công.
     - Mở tab **Tóm tắt**.

4. **Xem tóm tắt**  
   - Vào tab **Tóm tắt** để xem nội dung được AI rút gọn.

5. **Xem sơ đồ tư duy**  
   - Vào tab **Mindmap**.
   - Xem sơ đồ đã render (nếu Mermaid load OK).
   - Có thể bấm **“Copy code Mermaid”** để sử dụng với các công cụ khác.

6. **Học bằng flashcard**  
   - Vào tab **Flashcard**:
     - Dùng `‹` và `›` để chuyển thẻ.
     - Dùng nút **Hiện/Ẩn đáp án** để tự test.
     - Xem độ khó mỗi thẻ qua badge màu.
     - Nếu muốn xem toàn bộ → bấm **“Xem tất cả thẻ”**.

7. **Làm bài quiz**  
   - Vào tab **Quiz**:
     - Trả lời từng câu (chọn radio hoặc điền đáp án).
     - Bấm **“Nộp bài”**:
       - Hiện feedback cho từng câu (đúng/sai, đáp án đúng).
       - Hiển thị tổng số câu đúng và phần trăm.

---
