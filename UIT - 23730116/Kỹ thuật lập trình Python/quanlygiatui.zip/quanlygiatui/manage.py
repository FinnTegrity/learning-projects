#!/usr/bin/env python
""" 
Django's command-line utility for administrative tasks.
File này do Django tự sinh, chỉ thêm comment tiếng Việt.
"""

import os
import sys

def main():
    """ Hàm chính để chạy câu lệnh quản lý Django """
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'quanlygiatui.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        # Nếu Django chưa được cài đặt, hiển thị thông báo lỗi
        raise ImportError(
            "Không thể import Django. "
            "Đảm bảo bạn đã cài đặt Django "
            "và có thể kích hoạt môi trường ảo."
        ) from exc
    execute_from_command_line(sys.argv)

if __name__ == '__main__':
    main()
