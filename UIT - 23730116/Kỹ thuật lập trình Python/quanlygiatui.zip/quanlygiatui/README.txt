
# Dự án: quanlygiatui

## Cấu trúc thư mục
- quanlygiatui/
  - README.txt
  - db.sqlite3
  - manage.py
  - quanly/
    - __init__.py
    - admin.py
    - apps.py
    - migrations/
      - __init__.py
      - 0001_initial.py
      - 0002_auto.py
    - models.py
    - permissions.py
    - serializers.py
    - tests.py
    - urls.py
    - views.py
  - quanlygiatui/
    - __init__.py
    - asgi.py
    - settings.py
    - urls.py
    - wsgi.py

## Mô tả
Đây là một hệ thống quản lý giặt ủi được xây dựng bằng Django và Django REST Framework.

- manage.py: Tập tin khởi động để chạy các lệnh Django.
- Thư mục quanly/: Chứa các mô-đun chính của ứng dụng:
  - models.py: Định nghĩa các mô hình (bảng) cơ sở dữ liệu.
  - views.py: Xử lý logic API.
  - serializers.py: Chuyển đổi dữ liệu giữa model và JSON.
  - permissions.py: Quy định quyền truy cập tùy chỉnh.
  - urls.py: Định tuyến URL cho app.
  - migrations/: Ghi nhận các thay đổi trong cơ sở dữ liệu.
- Thư mục quanlygiatui/: Cấu hình chính của dự án Django:
  - settings.py: Cấu hình tổng thể của dự án.
  - urls.py: Định tuyến URL cấp dự án.
  - asgi.py, wsgi.py: Giao tiếp với server khi triển khai.

## Hướng dẫn sử dụng
1. Cài đặt Python 3.8 trở lên.
2. Tạo môi trường ảo:
   python3 -m venv venv
   source venv/bin/activate

3. Cài đặt các thư viện phụ thuộc:
   pip install -r requirements.txt

4. Khởi tạo cơ sở dữ liệu:
   python manage.py migrate

5. Chạy máy chủ phát triển:
   python manage.py runserver

## Phát triển
- Chỉnh sửa mã trong thư mục quanly/ khi cần thiết.
- Khi thay đổi các model, chạy:
   python manage.py makemigrations
   python manage.py migrate

## Tác giả
Tác giả: Nhóm 7 
Thành viên:
23730116	Lê Hải Phúc 
23730115	Nguyễn Lê Quý Phát
23730064	Nguyễn Thiên Trâm Anh
