"""
Định nghĩa URL tổng hợp cho project.
Chúng ta gom tất cả URL của app 'quanly' vào namespace 'api/'.
"""

from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    # Trang admin của Django
    path('admin/', admin.site.urls),

    # Tất cả API của app 'quanly' sẽ bắt đầu bằng: /api/
    path('api/', include('quanly.urls')),
]
