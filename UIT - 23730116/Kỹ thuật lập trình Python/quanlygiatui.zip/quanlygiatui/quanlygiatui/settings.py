"""
Cài đặt mặc định cho project quanlygiatui.
Áp dụng SQLite làm DB, cài đặt INSTALLED_APPS, middleware, template…
"""

from pathlib import Path

# Thư mục gốc (BASE_DIR)
BASE_DIR = Path(__file__).resolve().parent.parent

 
# CÀI ĐẶT CƠ BẢN
 

# Khóa bí mật (để sản xuất, nên đổi cho an toàn)
SECRET_KEY = 'django-insecure-thay-bang-khoa-cua-ban-tai-day'

# Bật chế độ debug khi phát triển
DEBUG = True

# Cho phép tất cả host (chỉ dev)
ALLOWED_HOSTS = []

 
# ỨNG DỤNG CÀI ĐẶT
 

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    # Thêm DRF
    'rest_framework',
    # Ứng dụng chính
    'quanly.apps.QuanlyConfig',

]

 
# MIDDLEWARE
 

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

 
# ĐỊNH NGHĨA URL TỔNG
 

ROOT_URLCONF = 'quanlygiatui.urls'

 
# TEMPLATE
 

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],  # Nếu muốn thêm folder templates, đặt ở đây
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

 
# WSGI & ASGI
 

WSGI_APPLICATION = 'quanlygiatui.wsgi.application'
ASGI_APPLICATION = 'quanlygiatui.asgi.application'

 
# CẤU HÌNH CƠ SỞ DỮ LIỆU (DATABASE)
# Mặc định SQLite, nếu muốn Postgres, chỉnh lại ở đây.
 

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

 
# XÁC THỰC (AUTHENTICATION) 
 

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

 
# QUẢN LÝ NGÔN NGỮ VÀ MÚI GIỜ
 

LANGUAGE_CODE = 'vi-vn'
TIME_ZONE = 'Asia/Ho_Chi_Minh'
USE_I18N = True
USE_L10N = True
USE_TZ = True

 
# TỆP TĨNH
 

STATIC_URL = '/static/'

 
# CÀI ĐẶT DRF
 

REST_FRAMEWORK = {
    'DEFAULT_PERMISSION_CLASSES': [
        'rest_framework.permissions.IsAuthenticatedOrReadOnly',
    ],
    'DEFAULT_AUTHENTICATION_CLASSES': [
        'rest_framework.authentication.SessionAuthentication',
        'rest_framework.authentication.BasicAuthentication',
    ],
}
