"""
Định nghĩa các serializer cho từng model,
dùng để chuyển đổi (serialize/deserialize) dữ liệu giữa JSON và đối tượng Python.
Áp dụng DRF để xây dựng API.
"""

from rest_framework import serializers
from .models import (
    KhachHang, DichVu, HangHoa,
    DonHang, ChiTietDonHang,
    ThanhToanTienMat, ThanhToanChuyenKhoan,
    HoaDon
)


 
# Serializer cho KhachHang
 
class KhachHangSerializer(serializers.ModelSerializer):
    """
    Chuyển dữ liệu KhachHang ↔ JSON
    """

    class Meta:
        model = KhachHang
        fields = [
            'ma_khach_hang',
            'ten_khach_hang',
            'dia_chi',
            'so_dien_thoai',
            'email',
            'ngay_tao',
            'ngay_cap_nhat',
        ]
        read_only_fields = ('ma_khach_hang', 'ngay_tao', 'ngay_cap_nhat')


 
# Serializer cho DichVu
 
class DichVuSerializer(serializers.ModelSerializer):
    class Meta:
        model = DichVu
        fields = [
            'ma_dich_vu',
            'ten_dich_vu',
            'don_gia_vnd',
            'mo_ta',
            'ngay_tao',
            'ngay_cap_nhat',
        ]
        read_only_fields = ('ma_dich_vu', 'ngay_tao', 'ngay_cap_nhat')


 
# Serializer cho HangHoa
 
class HangHoaSerializer(serializers.ModelSerializer):
    class Meta:
        model = HangHoa
        fields = [
            'ma_hang_hoa',
            'ten_hang_hoa',
            'don_vi_tinh',
            'ngay_tao',
            'ngay_cap_nhat',
        ]
        read_only_fields = ('ma_hang_hoa', 'ngay_tao', 'ngay_cap_nhat')


 
# Serializer cho ChiTietDonHang
 
class ChiTietDonHangSerializer(serializers.ModelSerializer):
    class Meta:
        model = ChiTietDonHang
        fields = [
            'id',
            'don_hang',
            'hang_hoa',
            'dich_vu',
            'so_luong',
            'don_gia_vnd',
            'thanh_tien_vnd',
            'ngay_tao',
            'ngay_cap_nhat',
        ]
        read_only_fields = ('thanh_tien_vnd', 'ngay_tao', 'ngay_cap_nhat')


 
# Serializer cho DonHang
 
class DonHangSerializer(serializers.ModelSerializer):
    """
    Để hiển thị chi tiết, có thể lồng ChiTietDonHangSerializer bên trong.
    """

    chi_tiet = ChiTietDonHangSerializer(
        source='chitietdonhang_set', many=True, read_only=True
    )

    class Meta:
        model = DonHang
        fields = [
            'ma_don_hang',
            'khach_hang',
            'trang_thai',
            'tong_tien_vnd',
            'ngay_tao',
            'ngay_cap_nhat',
            'chi_tiet',
        ]
        read_only_fields = ('ma_don_hang', 'tong_tien_vnd', 'ngay_tao', 'ngay_cap_nhat')


 
# Serializer cho ThanhToanTienMat
 
class ThanhToanTienMatSerializer(serializers.ModelSerializer):
    """
    Xử lý thanh toán tiền mặt (đa hình).
    """

    class Meta:
        model = ThanhToanTienMat
        fields = [
            'id',
            'don_hang',
            'so_tien_vnd',
            'ngay_thanh_toan',
            'ngay_tao',
            'ngay_cap_nhat',
        ]
        read_only_fields = ('ngay_tao', 'ngay_cap_nhat')


 
# Serializer cho ThanhToanChuyenKhoan
 
class ThanhToanChuyenKhoanSerializer(serializers.ModelSerializer):
    """
    Xử lý thanh toán chuyển khoản (đa hình).
    """

    class Meta:
        model = ThanhToanChuyenKhoan
        fields = [
            'id',
            'don_hang',
            'so_tien_vnd',
            'ngay_thanh_toan',
            'nha_bang',
            'so_tai_khoan',
            'ngay_tao',
            'ngay_cap_nhat',
        ]
        read_only_fields = ('ngay_tao', 'ngay_cap_nhat')


 
# Serializer cho HoaDon
 
class HoaDonSerializer(serializers.ModelSerializer):
    class Meta:
        model = HoaDon
        fields = [
            'ma_hoa_don',
            'don_hang',
            'ngay_lap',
            'tong_tien_vnd',
            'da_thanh_toan',
            'ngay_tao',
            'ngay_cap_nhat',
        ]
        read_only_fields = ('ma_hoa_don', 'tong_tien_vnd', 'ngay_tao', 'ngay_cap_nhat')
