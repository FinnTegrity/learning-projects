from django.contrib import admin
from .models import (
    KhachHang, DichVu, HangHoa,
    DonHang, ChiTietDonHang,
    ThanhToanTienMat, ThanhToanChuyenKhoan,
    HoaDon
)


# Đăng ký KhachHang

@admin.register(KhachHang)
class KhachHangAdmin(admin.ModelAdmin):
    list_display = ('ma_khach_hang', 'ten_khach_hang', 'so_dien_thoai', 'email')
    search_fields = ('ten_khach_hang', 'so_dien_thoai')
    list_filter = ('ngay_tao',)  # Lọc theo ngày tạo


 
# Đăng ký DichVu
 
@admin.register(DichVu)
class DichVuAdmin(admin.ModelAdmin):
    list_display = ('ma_dich_vu', 'ten_dich_vu', 'don_gia_vnd')
    search_fields = ('ten_dich_vu',)
    list_filter = ('ngay_tao',)


 
# Đăng ký HangHoa
 
@admin.register(HangHoa)
class HangHoaAdmin(admin.ModelAdmin):
    list_display = ('ma_hang_hoa', 'ten_hang_hoa', 'don_vi_tinh')
    search_fields = ('ten_hang_hoa',)
    list_filter = ('ngay_tao',)


 
# Đăng ký DonHang
 
@admin.register(DonHang)
class DonHangAdmin(admin.ModelAdmin):
    list_display = ('ma_don_hang', 'khach_hang', 'trang_thai', 'tong_tien_vnd')
    search_fields = ('ma_don_hang', 'khach_hang__ten_khach_hang')
    list_filter = ('trang_thai', 'ngay_tao')


 
# Đăng ký ChiTietDonHang
 
@admin.register(ChiTietDonHang)
class ChiTietDonHangAdmin(admin.ModelAdmin):
    list_display = ('don_hang', 'hang_hoa', 'dich_vu', 'so_luong', 'thanh_tien_vnd')
    search_fields = ('don_hang__ma_don_hang',)
    list_filter = ('ngay_tao',)


 
# Đăng ký ThanhToanTienMat
 
@admin.register(ThanhToanTienMat)
class ThanhToanTienMatAdmin(admin.ModelAdmin):
    list_display = ('don_hang', 'so_tien_vnd', 'ngay_thanh_toan')
    search_fields = ('don_hang__ma_don_hang',)
    list_filter = ('ngay_thanh_toan',)


 
# Đăng ký ThanhToanChuyenKhoan
 
@admin.register(ThanhToanChuyenKhoan)
class ThanhToanChuyenKhoanAdmin(admin.ModelAdmin):
    list_display = ('don_hang', 'so_tien_vnd', 'nha_bang', 'so_tai_khoan', 'ngay_thanh_toan')
    search_fields = ('don_hang__ma_don_hang', 'nha_bang')
    list_filter = ('ngay_thanh_toan',)


 
# Đăng ký HoaDon
 
@admin.register(HoaDon)
class HoaDonAdmin(admin.ModelAdmin):
    list_display = ('ma_hoa_don', 'don_hang', 'ngay_lap', 'tong_tien_vnd', 'da_thanh_toan')
    search_fields = ('ma_hoa_don', 'don_hang__ma_don_hang')
    list_filter = ('ngay_lap', 'da_thanh_toan')
