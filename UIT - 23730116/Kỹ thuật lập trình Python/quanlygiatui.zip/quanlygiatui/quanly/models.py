"""
Tất cả các mô hình (models) cho hệ thống quản lý dịch vụ giặt ủi.
Áp dụng OOP:
- Lớp trừu tượng BaseModel cho thời gian tạo/cập nhật
- Lớp trừu tượng HinhThucThanhToan (abstraction)
- Kế thừa, ghi đè, đa hình, đóng gói…
"""

from django.db import models
from django.utils import timezone

 
# LỚP CHUNG (Trừu tượng) dùng để lưu thời gian
 
class CoThoiGian(models.Model):
    """
    Lớp trừu tượng chứa các trường thời gian chung:
    - ngay_tao (created_at) tự động
    - ngay_cap_nhat (updated_at) tự động
    Các lớp con khi kế thừa sẽ có sẵn hai trường này.
    """

    ngay_tao = models.DateTimeField(auto_now_add=True, verbose_name="Ngày tạo")
    ngay_cap_nhat = models.DateTimeField(auto_now=True, verbose_name="Ngày cập nhật")

    class Meta:
        abstract = True  # Không tạo bảng riêng cho lớp này


 
# THÔNG TIN KHÁCH HÀNG
 
class KhachHang(CoThoiGian):
    """
    Lưu thông tin khách hàng:
    - ma_khach_hang: mã định danh (String, tự sinh)
    - ten_khach_hang, dia_chi, so_dien_thoai, email
    """

    ma_khach_hang = models.CharField(
        max_length=20, primary_key=True, editable=False, verbose_name="Mã KH"
    )
    ten_khach_hang = models.CharField(max_length=100, verbose_name="Tên khách hàng")
    dia_chi = models.CharField(max_length=255, verbose_name="Địa chỉ")
    so_dien_thoai = models.CharField(max_length=20, verbose_name="Số điện thoại")
    email = models.EmailField(max_length=100, blank=True, null=True, verbose_name="Email")

    def __str__(self):
        return f"{self.ten_khach_hang} - {self.ma_khach_hang}"

    def save(self, *args, **kwargs):
        """
        Ghi đè phương thức save để tự động sinh mã khách hàng nếu chưa có.
        Ví dụ: 'KH20250605001' (HHMMSS+Random…).
        """
        if not self.ma_khach_hang:
            # Tự sinh mã đơn giản theo thời gian hiện tại
            now = timezone.now()
            chuoi_thoi_gian = now.strftime("%Y%m%d%H%M%S")
            self.ma_khach_hang = f"KH{chuoi_thoi_gian}"
        super().save(*args, **kwargs)  # Gọi lại save gốc từ cha


 
# DANH MỤC DỊCH VỤ GIẶT ỦI
 
class DichVu(CoThoiGian):
    """
    Lưu các gói dịch vụ giặt ủi:
    - ma_dich_vu: mã dịch vụ (PK)
    - ten_dich_vu: tên dịch vụ
    - don_gia_vnd: giá (Vnd)
    - mo_ta: mô tả (tuỳ chọn)
    """

    ma_dich_vu = models.CharField(
        max_length=20, primary_key=True, editable=False, verbose_name="Mã DV"
    )
    ten_dich_vu = models.CharField(max_length=100, verbose_name="Tên dịch vụ")
    don_gia_vnd = models.IntegerField(verbose_name="Đơn giá (Vnd)")
    mo_ta = models.TextField(blank=True, null=True, verbose_name="Mô tả dịch vụ")

    def __str__(self):
        return f"{self.ten_dich_vu} - {self.don_gia_vnd} Vnd"

    def save(self, *args, **kwargs):
        """
        Ghi đè save để tự sinh mã dịch vụ nếu chưa có.
        Ví dụ: 'DV20250605001'
        """
        if not self.ma_dich_vu:
            now = timezone.now()
            chuoi_thoi_gian = now.strftime("%Y%m%d%H%M%S")
            self.ma_dich_vu = f"DV{chuoi_thoi_gian}"
        super().save(*args, **kwargs)


 
# DANH MỤC HÀNG HOÁ (LOẠI HÀNG GIẶT)
 
class HangHoa(CoThoiGian):
    """
    Lưu các loại hàng giặt:
    - ma_hang_hoa: mã hàng (PK)
    - ten_hang_hoa, don_vi_tinh
    """

    ma_hang_hoa = models.CharField(
        max_length=20, primary_key=True, editable=False, verbose_name="Mã HH"
    )
    ten_hang_hoa = models.CharField(max_length=100, verbose_name="Tên hàng hoá")
    don_vi_tinh = models.CharField(max_length=20, verbose_name="Đơn vị tính (Ví dụ: Cai, Kg)")

    def __str__(self):
        return f"{self.ten_hang_hoa}"

    def save(self, *args, **kwargs):
        """
        Ghi đè save để tự sinh mã hàng hoá nếu chưa có.
        Ví dụ: 'HH20250605001'
        """
        if not self.ma_hang_hoa:
            now = timezone.now()
            chuoi_thoi_gian = now.strftime("%Y%m%d%H%M%S")
            self.ma_hang_hoa = f"HH{chuoi_thoi_gian}"
        super().save(*args, **kwargs)


 
# ĐƠN HÀNG
 
class DonHang(CoThoiGian):
    """
    Lưu thông tin đơn hàng:
    - ma_don_hang: PK
    - khach_hang: FK
    - ngay_tao: tự động (thừa từ CoThoiGian)
    - trang_thai: lựa chọn (da_tiep_nhan, dang_xu_ly, da_hoan_thanh, da_huy)
    - tong_tien_vnd: tính tổng từ ChiTietDonHang
    """

    # Các trạng thái đơn hàng
    CHOICES_TRANG_THAI = [
        ('da_tiep_nhan', 'Đã tiếp nhận'),
        ('dang_xu_ly', 'Đang xử lý'),
        ('da_hoan_thanh', 'Đã hoàn thành'),
        ('da_huy', 'Đã huỷ'),
    ]

    ma_don_hang = models.CharField(
        max_length=20, primary_key=True, editable=False, verbose_name="Mã ĐH"
    )
    khach_hang = models.ForeignKey(
        KhachHang, on_delete=models.CASCADE, related_name='don_hangs', verbose_name="Khách hàng"
    )
    trang_thai = models.CharField(
        max_length=20, choices=CHOICES_TRANG_THAI, default='da_tiep_nhan', verbose_name="Trạng thái"
    )
    tong_tien_vnd = models.IntegerField(default=0, verbose_name="Tổng tiền (Vnd)")

    def __str__(self):
        return f"ĐH {self.ma_don_hang} - {self.khach_hang.ten_khach_hang}"

    def save(self, *args, **kwargs):
        """
        Ghi đè save để:
        - Tự sinh ma_don_hang nếu chưa có
        - Tính tổng tiền (vnd) = tổng thanh_tien_vnd của các ChiTietDonHang liên quan
        """
        if not self.ma_don_hang:
            now = timezone.now()
            chuoi_thoi_gian = now.strftime("%Y%m%d%H%M%S")
            self.ma_don_hang = f"DH{chuoi_thoi_gian}"

        # Tính tổng tiền: query tất cả chi tiết đơn hàng
        tong = 0
        if self.pk:
            # Trường hợp đã có pk, tức là update, tổng có thể tính lại
            from django.db.models import Sum
            # Nếu có chi tiết đơn, tính tổng
            tu_sum = self.chitietdonhang_set.aggregate(
                tongtien=Sum('thanh_tien_vnd')
            ).get('tongtien')
            if tu_sum:
                tong = tu_sum
        self.tong_tien_vnd = tong
        super().save(*args, **kwargs)


 
# CHI TIẾT ĐƠN HÀNG
 
class ChiTietDonHang(CoThoiGian):
    """
    Lưu mỗi dòng chi tiết trong đơn hàng:
    - don_hang (FK)
    - hang_hoa (FK)
    - dich_vu (FK)
    - so_luong
    - don_gia_vnd
    - thanh_tien_vnd (tự tính = so_luong * don_gia_vnd)
    """

    don_hang = models.ForeignKey(
        DonHang, on_delete=models.CASCADE, verbose_name="Đơn hàng"
    )
    hang_hoa = models.ForeignKey(
        HangHoa, on_delete=models.CASCADE, verbose_name="Hàng hoá"
    )
    dich_vu = models.ForeignKey(
        DichVu, on_delete=models.CASCADE, verbose_name="Dịch vụ"
    )
    so_luong = models.IntegerField(default=1, verbose_name="Số lượng")
    don_gia_vnd = models.IntegerField(verbose_name="Đơn giá (Vnd)")
    thanh_tien_vnd = models.IntegerField(default=0, verbose_name="Thành tiền (Vnd)")

    def __str__(self):
        return f"{self.don_hang.ma_don_hang} - {self.hang_hoa.ten_hang_hoa} x {self.so_luong}"

    def save(self, *args, **kwargs):
        """
        Ghi đè save để tự tính thanh_tien_vnd = so_luong * don_gia_vnd,
        sau đó gọi save của DonHang để cập nhật tong_tien_vnd
        """
        # Tính thành tiền
        self.thanh_tien_vnd = self.so_luong * self.don_gia_vnd
        super().save(*args, **kwargs)

        # Sau khi lưu chi tiết, cập nhật lại tổng tiền của DonHang
        self.don_hang.save()


 
# LỚP TRỪU TƯỢNG CHO HÌNH THỨC THANH TOÁN
 
class HinhThucThanhToan(CoThoiGian):
    """
    Lớp trừu tượng định nghĩa chung các trường của thanh toán:
    - don_hang (FK)
    - so_tien_vnd
    - ngay_thanh_toan
    Các lớp con sẽ ghi đè (đa hình) để bổ sung trường riêng (nếu có).
    """

    don_hang = models.ForeignKey(
        DonHang, on_delete=models.CASCADE, verbose_name="Đơn hàng"
    )
    so_tien_vnd = models.IntegerField(verbose_name="Số tiền (Vnd)")
    ngay_thanh_toan = models.DateTimeField(verbose_name="Ngày thanh toán")

    class Meta:
        abstract = True

    def __str__(self):
        return f"Thanh toán đơn {self.don_hang.ma_don_hang} - {self.so_tien_vnd} Vnd"


 
# THANH TOÁN TIỀN MẶT
 
class ThanhToanTienMat(HinhThucThanhToan):
    """
    Lớp mô tả thanh toán bằng tiền mặt.
    Kế thừa từ HinhThucThanhToan (đa hình).
    """

    class Meta:
        verbose_name = "Thanh toán tiền mặt"
        verbose_name_plural = "Danh sách thanh toán tiền mặt"


 
# THANH TOÁN CHUYỂN KHOẢN
 
class ThanhToanChuyenKhoan(HinhThucThanhToan):
    """
    Lớp mô tả thanh toán chuyển khoản.
    Có thêm thông tin:
    - nha_bang
    - so_tai_khoan
    """

    nha_bang = models.CharField(max_length=100, verbose_name="Ngân hàng")
    so_tai_khoan = models.CharField(max_length=50, verbose_name="Số tài khoản")

    class Meta:
        verbose_name = "Thanh toán chuyển khoản"
        verbose_name_plural = "Danh sách thanh toán chuyển khoản"


 
# HÓA ĐƠN
 
class HoaDon(CoThoiGian):
    """
    Lưu thông tin hoá đơn in ra sau khi đơn hàng hoàn thành:
    - ma_hoa_don (PK)
    - don_hang (OneToOneField)
    - ngay_lap
    - tong_tien_vnd (copy từ DonHang)
    - da_thanh_toan (True/False)
    """

    ma_hoa_don = models.CharField(
        max_length=20, primary_key=True, editable=False, verbose_name="Mã HD"
    )
    don_hang = models.OneToOneField(
        DonHang, on_delete=models.CASCADE, verbose_name="Đơn hàng"
    )
    ngay_lap = models.DateTimeField(default=timezone.now, verbose_name="Ngày lập")
    tong_tien_vnd = models.IntegerField(verbose_name="Tổng tiền (Vnd)")
    da_thanh_toan = models.BooleanField(default=False, verbose_name="Đã thanh toán")

    def __str__(self):
        return f"HD {self.ma_hoa_don} - {self.don_hang.ma_don_hang}"

    def save(self, *args, **kwargs):
        """
        Ghi đè save để tự sinh mã hoá đơn nếu chưa có,
        và tự động copy tong_tien_vnd từ DonHang nếu cần.
        """
        if not self.ma_hoa_don:
            now = timezone.now()
            chuoi_thoi_gian = now.strftime("%Y%m%d%H%M%S")
            self.ma_hoa_don = f"HD{chuoi_thoi_gian}"
        if self.don_hang:
            self.tong_tien_vnd = self.don_hang.tong_tien_vnd
        super().save(*args, **kwargs)
