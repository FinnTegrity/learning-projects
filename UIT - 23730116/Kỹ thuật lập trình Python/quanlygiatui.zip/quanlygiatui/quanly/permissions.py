from rest_framework import permissions

class ChiDocChoAdmin(permissions.BasePermission):
    """
    Chỉ cho phép admin thực hiện hành động (POST, PUT, DELETE),
    user (khách truy cập) chỉ được phép GET (đọc).
    """

    def has_permission(self, request, view):
        # Nếu là phương thức an toàn (GET, HEAD, OPTIONS) → cho qua
        if request.method in permissions.SAFE_METHODS:
            return True
        # Chỉ admin (is_staff=True) mới được thực hiện thêm, sửa, xóa
        return request.user and request.user.is_staff
