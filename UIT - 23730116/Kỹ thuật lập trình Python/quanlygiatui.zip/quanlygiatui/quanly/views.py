"""
Định nghĩa các API endpoints cho ứng dụng 'quanly'.
Sử dụng Django REST Framework để tạo các viewsets / APIView.
Áp dụng OOP: 
- Có thể tách một lớp cơ sở chung nếu cần
- Ghi đè phương thức để custom logic
- Phân quyền (permissions) cho admin/user
- API thống kê doanh thu
"""

from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.decorators import action, api_view, permission_classes
from rest_framework.permissions import IsAdminUser, IsAuthenticatedOrReadOnly
from django.db.models import Sum
from django.utils.dateparse import parse_date
from django.shortcuts import get_object_or_404

from .models import (
    KhachHang, DichVu, HangHoa,
    DonHang, ChiTietDonHang,
    ThanhToanTienMat, ThanhToanChuyenKhoan,
    HoaDon
)
from .serializers import (
    KhachHangSerializer, DichVuSerializer, HangHoaSerializer,
    DonHangSerializer, ChiTietDonHangSerializer,
    ThanhToanTienMatSerializer, ThanhToanChuyenKhoanSerializer,
    HoaDonSerializer
)


 
# ViewSet chung cho các model đơn giản: KhachHang, DichVu, HangHoa
 
class CoSoViewSet(viewsets.ModelViewSet):
    """
    Đây là lớp cha trừu tượng (abstract) nếu muốn sử dụng chung
    cho KhachHang, DichVu, HangHoa. Tuy nhiên DRF không hỗ trợ
    abstract viewset trực tiếp, nên ta có thể kế thừa lại.
    """

    permission_classes = [IsAuthenticatedOrReadOnly]  # Mặc định: ai cũng có thể xem, chỉ user xác thực mới sửa/xóa


class KhachHangViewSet(CoSoViewSet):
    """
    API cho KhachHang:  
      - GET /api/khachhang/  
      - POST /api/khachhang/  
      - GET /api/khachhang/{id}/  
      - PUT /api/khachhang/{id}/  
      - DELETE /api/khachhang/{id}/  
    """

    queryset = KhachHang.objects.all().order_by('-ngay_tao')
    serializer_class = KhachHangSerializer
    # Nếu muốn giới hạn quyền admin mới được tạo, sửa, xóa, có thể ghi:
    # permission_classes = [IsAdminUser] cho khớp yêu cầu


class DichVuViewSet(CoSoViewSet):
    """
    API cho DichVu.
    """

    queryset = DichVu.objects.all().order_by('-ngay_tao')
    serializer_class = DichVuSerializer


class HangHoaViewSet(CoSoViewSet):
    """
    API cho HangHoa.
    """

    queryset = HangHoa.objects.all().order_by('-ngay_tao')
    serializer_class = HangHoaSerializer


 
# ViewSet cho ChiTietDonHang (thực chất chỉ CRUD)
 
class ChiTietDonHangViewSet(viewsets.ModelViewSet):
    """
    API cho ChiTietDonHang:
    - GET /api/chitietdonhang/
    - POST /api/chitietdonhang/
    - GET /api/chitietdonhang/{id}/
    - PUT /api/chitietdonhang/{id}/
    - DELETE /api/chitietdonhang/{id}/
    """

    queryset = ChiTietDonHang.objects.all().order_by('-ngay_tao')
    serializer_class = ChiTietDonHangSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]


 
# ViewSet cho DonHang
 
class DonHangViewSet(viewsets.ModelViewSet):
    """
    API cho DonHang:
    - GET /api/donhang/
    - POST /api/donhang/
    - GET /api/donhang/{id}/
    - PUT /api/donhang/{id}/
    - DELETE /api/donhang/{id}/
    """

    queryset = DonHang.objects.all().order_by('-ngay_tao')
    serializer_class = DonHangSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]

    @action(detail=True, methods=['post'], permission_classes=[IsAuthenticatedOrReadOnly])
    def them_chitiet(self, request, pk=None):
        """
        Tạo API custom để thêm nhiều ChiTietDonHang cho 1 DonHang.
        Ví dụ POST lên /api/donhang/{ma_don_hang}/them_chitiet/
        Dữ liệu gửi lên JSON list các chi tiết: 
        [
            {
                "hang_hoa": "HH20250605001",
                "dich_vu": "DV20250605006",
                "so_luong": 3,
                "don_gia_vnd": 25000
            },
            ...
        ]
        """

        donhang = self.get_object()
        ds_chitiet = request.data
        ketqua = []
        for ct in ds_chitiet:
            serializer_ct = ChiTietDonHangSerializer(data={
                'don_hang': donhang.pk,
                'hang_hoa': ct.get('hang_hoa'),
                'dich_vu': ct.get('dich_vu'),
                'so_luong': ct.get('so_luong'),
                'don_gia_vnd': ct.get('don_gia_vnd'),
            })
            if serializer_ct.is_valid():
                serializer_ct.save()
                ketqua.append(serializer_ct.data)
            else:
                return Response(serializer_ct.errors, status=status.HTTP_400_BAD_REQUEST)
        # Sau khi thêm, DonHang.save() sẽ tự động tính lại tong_tien_vnd do trong model đã override
        return Response(ketqua, status=status.HTTP_201_CREATED)


 
# ViewSet cho ThanhToan (đa hình: tiền mặt + chuyển khoản)
 
class ThanhToanTienMatViewSet(viewsets.ModelViewSet):
    """
    API cho ThanhToanTienMat (tiền mặt).
    """

    queryset = ThanhToanTienMat.objects.all().order_by('-ngay_tao')
    serializer_class = ThanhToanTienMatSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]


class ThanhToanChuyenKhoanViewSet(viewsets.ModelViewSet):
    """
    API cho ThanhToanChuyenKhoan (chuyển khoản).
    """

    queryset = ThanhToanChuyenKhoan.objects.all().order_by('-ngay_tao')
    serializer_class = ThanhToanChuyenKhoanSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]


 
# ViewSet cho HoaDon
 
class HoaDonViewSet(viewsets.ModelViewSet):
    """
    API cho HoaDon:
    - GET /api/hoadon/
    - POST /api/hoadon/
    - GET /api/hoadon/{id}/
    - PUT /api/hoadon/{id}/
    - DELETE /api/hoadon/{id}/
    """

    queryset = HoaDon.objects.all().order_by('-ngay_tao')
    serializer_class = HoaDonSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]

    @action(detail=False, methods=['get'], permission_classes=[IsAdminUser])
    def thongkedoanhthu(self, request):
        """
        API thống kê doanh thu trong khoảng thời gian:
        /api/hoadon/thongkedoanhthu/?tu_ngay=YYYY-MM-DD&den_ngay=YYYY-MM-DD

        Ví dụ: /api/hoadon/thongkedoanhthu/?tu_ngay=2025-06-01&den_ngay=2025-06-30
        """

        tu_ngay_str = request.query_params.get('tu_ngay')
        den_ngay_str = request.query_params.get('den_ngay')
        if not tu_ngay_str or not den_ngay_str:
            return Response(
                {"chi_tiet": "Cần truyền đầy đủ 'tu_ngay' và 'den_ngay' với định dạng YYYY-MM-DD"},
                status=status.HTTP_400_BAD_REQUEST
            )
        # Chuyển chuỗi sang date
        tu_ngay = parse_date(tu_ngay_str)
        den_ngay = parse_date(den_ngay_str)
        if not tu_ngay or not den_ngay:
            return Response(
                {"chi_tiet": "Sai định dạng ngày, phải là YYYY-MM-DD"},
                status=status.HTTP_400_BAD_REQUEST
            )
        # Tính tổng doanh thu (sum tong_tien_vnd của HoaDon có ngay_lap nằm trong khoảng)
        ds_hoadon = HoaDon.objects.filter(
            ngay_lap__date__gte=tu_ngay,
            ngay_lap__date__lte=den_ngay,
            da_thanh_toan=True
        )
        tong_doanh_thu = ds_hoadon.aggregate(tong=Sum('tong_tien_vnd')).get('tong') or 0

        return Response({
            "tu_ngay": tu_ngay_str,
            "den_ngay": den_ngay_str,
            "tong_doanh_thu_vnd": tong_doanh_thu,
        }, status=status.HTTP_200_OK)

from .permissions import ChiDocChoAdmin

class DichVuViewSet(CoSoViewSet):
    queryset = DichVu.objects.all().order_by('-ngay_tao')
    serializer_class = DichVuSerializer
    permission_classes = [ChiDocChoAdmin]
