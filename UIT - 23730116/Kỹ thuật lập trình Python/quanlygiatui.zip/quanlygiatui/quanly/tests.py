"""
File: test.py

Mô tả:
  - Đây là tập hợp các kiểm thử đơn vị (unit test) cho các model trong hệ thống quản lý giặt ủi.
  - Bao gồm kiểm tra tạo mã tự động, hiển thị chuỗi (__str__), tính toán số tiền,
    và đảm bảo tính đúng đắn của quan hệ dữ liệu giữa các bảng.

Được xây dựng bằng:
  - Django TestCase
  - Các lớp kiểm thử theo chuẩn unittest tích hợp trong Django

Phạm vi kiểm thử:
  - KhachHang
  - DichVu
  - HangHoa
  - DonHang
  - ChiTietDonHang
  - HoaDon
  - ThanhToanTienMat
  - ThanhToanChuyenKhoan
"""

from django.test import TestCase
from django.utils import timezone

from .models import (
    KhachHang,
    DichVu,
    HangHoa,
    DonHang,
    ChiTietDonHang,
    HoaDon,
    ThanhToanTienMat,
    ThanhToanChuyenKhoan,
)


class ModelTests(TestCase):
    def test_khachhang_creation_and_str(self):
        """
        Khi lưu KhachHang mà chưa có ma_khach_hang, save() phải tự tạo mã bắt đầu bằng 'KH';
        __str__ trả về 'ten_khach_hang - ma_khach_hang'.
        """
        kh = KhachHang(
            ten_khach_hang="Nguyen Van A",
            dia_chi="123 Đường ABC",
            so_dien_thoai="0123456789",
            email="vana@example.com",
        )
        # Trước khi save, ma_khach_hang chưa được gán
        self.assertFalse(hasattr(kh, "ma_khach_hang") and kh.ma_khach_hang)
        kh.save()
        # Sau khi save, ma_khach_hang phải tồn tại và bắt đầu bằng 'KH'
        self.assertTrue(kh.ma_khach_hang.startswith("KH"))
        self.assertIn("Nguyen Van A", str(kh))
        self.assertIn(kh.ma_khach_hang, str(kh))

    def test_dichvu_creation_and_str(self):
        """
        Khi lưu DichVu mà chưa có ma_dich_vu, save() phải tự tạo mã bắt đầu bằng 'DV';
        __str__ trả về 'ten_dich_vu - don_gia_vnd Vnd'.
        """
        dv = DichVu(
            ten_dich_vu="Giặt Thường",
            don_gia_vnd=50000,
            mo_ta="Dịch vụ giặt ủi cơ bản",
        )
        self.assertFalse(hasattr(dv, "ma_dich_vu") and dv.ma_dich_vu)
        dv.save()
        self.assertTrue(dv.ma_dich_vu.startswith("DV"))
        expected_str = f"{dv.ten_dich_vu} - {dv.don_gia_vnd} Vnd"
        self.assertEqual(str(dv), expected_str)

    def test_hanghoa_creation_and_str(self):
        """
        Khi lưu HangHoa mà chưa có ma_hang_hoa, save() phải tự tạo mã bắt đầu bằng 'HH';
        __str__ trả về ten_hang_hoa.
        """
        hh = HangHoa(
            ten_hang_hoa="Áo Sơ Mi",
            don_vi_tinh="Cái",
        )
        self.assertFalse(hasattr(hh, "ma_hang_hoa") and hh.ma_hang_hoa)
        hh.save()
        self.assertTrue(hh.ma_hang_hoa.startswith("HH"))
        self.assertEqual(str(hh), "Áo Sơ Mi")

    def test_donhang_and_chitietdonhang_total(self):
        """
        Tạo KhachHang và DonHang; khi save DonHang lần đầu, tong_tien_vnd = 0.
        Sau đó tạo HangHoa, DichVu, rồi ChiTietDonHang với so_luong và don_gia_vnd,
        save phải tự tính thanh_tien_vnd và cập nhật tổng tiền của DonHang.
        """
        # Tạo KhachHang
        kh = KhachHang(
            ten_khach_hang="Nguyen Van B",
            dia_chi="456 Đường XYZ",
            so_dien_thoai="0987654321",
            email="vanb@example.com",
        )
        kh.save()

        # Tạo DonHang
        dh = DonHang(khach_hang=kh)
        self.assertFalse(hasattr(dh, "ma_don_hang") and dh.ma_don_hang)
        dh.save()
        # Sau khi save, ma_don_hang phải bắt đầu bằng 'DH', tổng tiền ban đầu = 0
        self.assertTrue(dh.ma_don_hang.startswith("DH"))
        self.assertEqual(dh.tong_tien_vnd, 0)

        # Tạo HangHoa và DichVu
        hh = HangHoa(ten_hang_hoa="Khăn", don_vi_tinh="Cái")
        hh.save()
        dv = DichVu(ten_dich_vu="Giặt Nhanh", don_gia_vnd=70000, mo_ta="Quy trình nhanh")
        dv.save()

        # Tạo ChiTietDonHang: 2 Khăn, don_gia_vnd = 70000
        ct = ChiTietDonHang(
            don_hang=dh,
            hang_hoa=hh,
            dich_vu=dv,
            so_luong=2,
            don_gia_vnd=70000,
        )
        # Trước khi save, mặc định thanh_tien_vnd = 0 (theo default của model)
        self.assertEqual(ct.thanh_tien_vnd, 0)
        ct.save()

        # Sau khi save, thanh_tien_vnd phải = so_luong * don_gia_vnd = 140000
        self.assertEqual(ct.thanh_tien_vnd, 2 * 70000)
        # Đồng thời, DonHang.tong_tien_vnd phải được cập nhật = 140000
        dh.refresh_from_db()
        self.assertEqual(dh.tong_tien_vnd, 140000)

        # Thêm một chi tiết khác: 1 Khăn, giá 70000
        ct2 = ChiTietDonHang(
            don_hang=dh,
            hang_hoa=hh,
            dich_vu=dv,
            so_luong=1,
            don_gia_vnd=70000,
        )
        ct2.save()
        # Tổng của dh là 140000 + 70000 = 210000
        dh.refresh_from_db()
        self.assertEqual(dh.tong_tien_vnd, 210000)

    def test_hoadon_creation_and_fields(self):
        """
        Khi tạo HoaDon, save() phải tự sinh ma_hoa_don bắt đầu bằng 'HD',
        và sao chép tong_tien_vnd từ DonHang; trường da_thanh_toan mặc định False.
        __str__ trả về 'HD <ma> - <ma_don_hang>'.
        """
        # Tạo KhachHang
        kh = KhachHang(
            ten_khach_hang="Tran Thi C",
            dia_chi="789 Đường DEF",
            so_dien_thoai="0112233445",
            email="tranc@example.com",
        )
        kh.save()
        # Tạo DonHang
        dh = DonHang(khach_hang=kh)
        dh.save()
        # Thêm chi tiết để dh có tong_tien_vnd khác 0
        hh = HangHoa(ten_hang_hoa="Áo Thun", don_vi_tinh="Cái")
        hh.save()
        dv = DichVu(ten_dich_vu="Giặt Kết Hợp", don_gia_vnd=80000, mo_ta="")
        dv.save()
        ct = ChiTietDonHang(
            don_hang=dh,
            hang_hoa=hh,
            dich_vu=dv,
            so_luong=3,
            don_gia_vnd=80000,
        )
        ct.save()
        dh.refresh_from_db()
        # Tạo HoaDon
        hd = HoaDon(
            don_hang=dh,
            ngay_lap=timezone.now(),
        )
        self.assertFalse(hasattr(hd, "ma_hoa_don") and hd.ma_hoa_don)
        hd.save()
        # Sau khi save, ma_hoa_don phải bắt đầu bằng 'HD'
        self.assertTrue(hd.ma_hoa_don.startswith("HD"))
        # tong_tien_vnd của hd phải bằng tong_tien_vnd của dh
        self.assertEqual(hd.tong_tien_vnd, dh.tong_tien_vnd)
        # da_thanh_toan mặc định False
        self.assertFalse(hd.da_thanh_toan)
        # __str__
        expected_str = f"HD {hd.ma_hoa_don} - {dh.ma_don_hang}"
        self.assertEqual(str(hd), expected_str)

    def test_thanhtoantienmat_and_chuyenkhoan_basic(self):
        """
        Tạo ThanhToanTienMat và ThanhToanChuyenKhoan, kiểm tra các trường được lưu chính xác.
        """
        # Tạo KhachHang, DonHang, rồi một ChiTiet để dh có tổng tiền
        kh = KhachHang(
            ten_khach_hang="Le Van D",
            dia_chi="321 Đường GHI",
            so_dien_thoai="0998877665",
            email="levand@example.com",
        )
        kh.save()
        dh = DonHang(khach_hang=kh)
        dh.save()
        hh = HangHoa(ten_hang_hoa="Chăn", don_vi_tinh="Chiếc")
        hh.save()
        dv = DichVu(ten_dich_vu="Giặt Sấy", don_gia_vnd=100000, mo_ta="")
        dv.save()
        ct = ChiTietDonHang(
            don_hang=dh,
            hang_hoa=hh,
            dich_vu=dv,
            so_luong=1,
            don_gia_vnd=100000,
        )
        ct.save()
        dh.refresh_from_db()

        # Tạo ThanhToanTienMat
        ngay_tt = timezone.now()
        tt_tienmat = ThanhToanTienMat(
            don_hang=dh,
            so_tien_vnd=dh.tong_tien_vnd,
            ngay_thanh_toan=ngay_tt,
        )
        tt_tienmat.save()
        self.assertEqual(tt_tienmat.don_hang, dh)
        self.assertEqual(tt_tienmat.so_tien_vnd, dh.tong_tien_vnd)
        self.assertEqual(tt_tienmat.ngay_thanh_toan, ngay_tt)

        # Tạo ThanhToanChuyenKhoan
        ngay_tt2 = timezone.now()
        tt_ck = ThanhToanChuyenKhoan(
            don_hang=dh,
            so_tien_vnd=dh.tong_tien_vnd,
            ngay_thanh_toan=ngay_tt2,
            nha_bang="ABC Bank",
            so_tai_khoan="123456789",
        )
        tt_ck.save()
        self.assertEqual(tt_ck.don_hang, dh)
        self.assertEqual(tt_ck.so_tien_vnd, dh.tong_tien_vnd)
        self.assertEqual(tt_ck.ngay_thanh_toan, ngay_tt2)
        self.assertEqual(tt_ck.nha_bang, "ABC Bank")
        self.assertEqual(tt_ck.so_tai_khoan, "123456789")

