"""
Định nghĩa đường dẫn (URL patterns) cho toàn bộ API của app 'quanly'.
Sử dụng DefaultRouter của DRF để đăng ký các ViewSet.
"""

from django.urls import path, include
from rest_framework.routers import DefaultRouter

from .views import (
    KhachHangViewSet, DichVuViewSet, HangHoaViewSet,
    DonHangViewSet, ChiTietDonHangViewSet,
    ThanhToanTienMatViewSet, ThanhToanChuyenKhoanViewSet,
    HoaDonViewSet
)

# Tạo router tự động
router = DefaultRouter()
router.register(r'khachhang', KhachHangViewSet, basename='khachhang')
router.register(r'dichvu', DichVuViewSet, basename='dichvu')
router.register(r'hanghoa', HangHoaViewSet, basename='hanghoa')
router.register(r'donhang', DonHangViewSet, basename='donhang')
router.register(r'chitietdonhang', ChiTietDonHangViewSet, basename='chitietdonhang')
router.register(r'thanhtoantienmat', ThanhToanTienMatViewSet, basename='thanhtoantienmat')
router.register(r'thanhtoanchuyenkhoan', ThanhToanChuyenKhoanViewSet, basename='thanhtoanchuyenkhoan')
router.register(r'hoadon', HoaDonViewSet, basename='hoadon')

urlpatterns = [
    path('', include(router.urls)),
]
