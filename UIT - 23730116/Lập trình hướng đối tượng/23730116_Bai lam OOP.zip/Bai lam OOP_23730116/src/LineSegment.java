public class LineSegment extends Geometry {
    private Point start;
    private Point end;

    public LineSegment() {}

    public LineSegment(Point start, Point end) {
        this.start = start;
        this.end = end;
    }

    public Point getStart() {
        return start;
    }

    public void setStart(Point start) {
        this.start = start;
    }

    public Point getEnd() {
        return end;
    }

    public void setEnd(Point end) {
        this.end = end;
    }

    @Override
    public void input() {
        System.out.println("Nhap diem dau:");
        start = new Point();
        start.input();
        System.out.println("Nhap diem cuoi:");
        end = new Point();
        end.input();
    }

    @Override
    public void output() {
        System.out.print("Doan thang co diem dau ");
        start.output();
        System.out.print(" va diem cuoi ");
        end.output();
    }

    @Override
    public boolean isValid() {
        return start != null && end != null;
    }

    @Override
    public double perimeterCalculate() {
        return Math.sqrt(Math.pow(end.getX() - start.getX(), 2) + Math.pow(end.getY() - start.getY(), 2));
    }

    @Override
    public double areaCalculate() {
        return 0;
    }
}
