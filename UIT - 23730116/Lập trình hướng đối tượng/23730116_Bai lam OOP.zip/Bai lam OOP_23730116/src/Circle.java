import java.util.Scanner;

public class Circle extends Geometry {
    private Point center;
    private double radius;

    public Circle() {}

    public Circle(Point center, double radius) {
        this.center = center;
        this.radius = radius;
    }

    public Point getCenter() {
        return center;
    }

    public void setCenter(Point center) {
        this.center = center;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    @Override
    public void input() {
        center = new Point();
        System.out.println("Nhap toa do tam:");
        center.input();
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhap ban kinh: ");
        radius = sc.nextDouble();
    }

    @Override
    public void output() {
        System.out.print("Duong tron co tam la ");
        center.output();
        System.out.println(" va ban kinh " + radius);
    }

    @Override
    public boolean isValid() {
        return radius > 0;
    }

    @Override
    public double perimeterCalculate() {
        return 2 * Math.PI * radius;
    }

    @Override
    public double areaCalculate() {
        return Math.PI * Math.pow(radius, 2);
    }

    public String checkRelativePosition(Point point) {
        double distance = Math.sqrt(Math.pow(point.getX() - center.getX(), 2) + Math.pow(point.getY() - center.getY(), 2));
        if (distance < radius) {
            return "Diem nam trong duong tron";
        } else if (distance == radius) {
            return "Diem nam tren duong tron";
        } else {
            return "Diem nam ngoai duong tron";
        }
    }
}
