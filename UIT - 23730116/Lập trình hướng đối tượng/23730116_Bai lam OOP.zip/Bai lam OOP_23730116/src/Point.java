import java.util.Scanner;

public class Point {
    private double x;
    private double y;

    public Point() {}

    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public void input() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhap x: ");
        x = sc.nextDouble();
        System.out.print("Nhap y: ");
        y = sc.nextDouble();
    }

    public void output() {
        System.out.println("(" + x + ", " + y + ")");
    }
}
