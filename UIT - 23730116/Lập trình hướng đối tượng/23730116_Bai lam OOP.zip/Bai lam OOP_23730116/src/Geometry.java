public abstract class Geometry {
    abstract void input();
    abstract void output();
    abstract boolean isValid();
    abstract double perimeterCalculate();
    abstract double areaCalculate();
}
