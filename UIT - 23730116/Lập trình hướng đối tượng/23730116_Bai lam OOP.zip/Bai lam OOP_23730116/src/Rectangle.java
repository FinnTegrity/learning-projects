public class Rectangle extends Geometry {
    private Point[] points;

    public Rectangle() {
        points = new Point[4];
    }

    public Rectangle(Point[] points) {
        this.points = points;
    }

    public Point[] getPoints() {
        return points;
    }

    public void setPoints(Point[] points) {
        this.points = points;
    }

    @Override
    public void input() {
        for (int i = 0; i < 4; i++) {
            System.out.println("Nhap diem thu " + (i + 1) + ":");
            points[i] = new Point();
            points[i].input();
        }
    }

    @Override
    public void output() {
        System.out.println("Hinh chu nhat co cac dinh la:");
        for (int i = 0; i < 4; i++) {
            points[i].output();
        }
    }

    @Override
    public boolean isValid() {
        double a = new LineSegment(points[0], points[1]).perimeterCalculate();
        double b = new LineSegment(points[1], points[2]).perimeterCalculate();
        double c = new LineSegment(points[2], points[3]).perimeterCalculate();
        double d = new LineSegment(points[3], points[0]).perimeterCalculate();

        double diagonal1 = new LineSegment(points[0], points[2]).perimeterCalculate();
        double diagonal2 = new LineSegment(points[1], points[3]).perimeterCalculate();

        return a == c && b == d && diagonal1 == diagonal2 && Math.pow(diagonal1, 2) == Math.pow(a, 2) + Math.pow(b, 2);
    }

    @Override
    public double perimeterCalculate() {
        double perimeter = 0;
        for (int i = 0; i < 4; i++) {
            perimeter += new LineSegment(points[i], points[(i + 1) % 4]).perimeterCalculate();
        }
        return perimeter;
    }

    @Override
    public double areaCalculate() {
        double a = new LineSegment(points[0], points[1]).perimeterCalculate();
        double b = new LineSegment(points[1], points[2]).perimeterCalculate();
        return a * b;
    }
}
