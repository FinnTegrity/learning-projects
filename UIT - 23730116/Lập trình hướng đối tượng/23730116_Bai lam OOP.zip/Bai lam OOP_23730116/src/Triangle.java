import java.util.Scanner;

public class Triangle extends Geometry {
    private Point[] points;

    public Triangle() {
        points = new Point[3];
    }

    public Triangle(Point[] points) {
        this.points = points;
    }

    public Point[] getPoints() {
        return points;
    }

    public void setPoints(Point[] points) {
        this.points = points;
    }

    @Override
    public void input() {
        for (int i = 0; i < 3; i++) {
            System.out.println("Nhap diem thu " + (i + 1) + ":");
            points[i] = new Point();
            points[i].input();
        }
    }

    @Override
    public void output() {
        System.out.println("Tam giac co cac dinh la:");
        for (int i = 0; i < 3; i++) {
            points[i].output();
        }
    }

    @Override
    public boolean isValid() {
        return points[0] != null && points[1] != null && points[2] != null &&
                !((points[0].getX() == points[1].getX() && points[0].getY() == points[1].getY()) ||
                        (points[0].getX() == points[2].getX() && points[0].getY() == points[2].getY()) ||
                        (points[1].getX() == points[2].getX() && points[1].getY() == points[2].getY()));
    }

    @Override
    public double perimeterCalculate() {
        double perimeter = 0;
        for (int i = 0; i < 3; i++) {
            perimeter += new LineSegment(points[i], points[(i + 1) % 3]).perimeterCalculate();
        }
        return perimeter;
    }

    @Override
    public double areaCalculate() {
        double a = new LineSegment(points[0], points[1]).perimeterCalculate();
        double b = new LineSegment(points[1], points[2]).perimeterCalculate();
        double c = new LineSegment(points[2], points[0]).perimeterCalculate();
        double p = perimeterCalculate() / 2;
        return Math.sqrt(p * (p - a) * (p - b) * (p - c));
    }
}
