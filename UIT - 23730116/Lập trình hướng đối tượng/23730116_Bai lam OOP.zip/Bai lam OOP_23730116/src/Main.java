import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Chon loai hinh:");
        System.out.println("1. LineSegment");
        System.out.println("2. Triangle");
        System.out.println("3. Rectangle");
        System.out.println("4. Circle");
        System.out.println("Lua chon cua ban la: ");
        int choice = sc.nextInt();

        switch (choice) {
            case 1:
                LineSegment lineSegment = new LineSegment();
                lineSegment.input();
                lineSegment.output();
                System.out.println("Chieu dai doan thang: " + lineSegment.perimeterCalculate());
                break;
            case 2:
                Triangle triangle = new Triangle();
                triangle.input();
                if (triangle.isValid()) {
                    triangle.output();
                    System.out.println("Chu vi tam giac: " + triangle.perimeterCalculate());
                    System.out.println("Dien tich tam giac: " + triangle.areaCalculate());
                } else {
                    System.out.println("Khong phai la tam giac");
                }
                break;
            case 3:
                Rectangle rectangle = new Rectangle();
                rectangle.input();
                if (rectangle.isValid()) {
                    rectangle.output();
                    System.out.println("Chu vi hinh chu nhat: " + rectangle.perimeterCalculate());
                    System.out.println("Dien tich hinh chu nhat: " + rectangle.areaCalculate());
                } else {
                    System.out.println("Khong phai la hinh chu nhat");
                }
                break;
            case 4:
                Circle circle = new Circle();
                circle.input();
                if (circle.isValid()) {
                    circle.output();
                    System.out.println("Chu vi duong tron: " + circle.perimeterCalculate());
                    System.out.println("Dien tich duong tron: " + circle.areaCalculate());
                    System.out.println("Nhap diem de kiem tra vi tri:");
                    Point point = new Point();
                    point.input();
                    System.out.println(circle.checkRelativePosition(point));
                } else {
                    System.out.println("Ban kinh phai lon hon 0");
                }
                break;
            default:
                System.out.println("Lua chon khong hop le");
                break;
        }
    }
}
