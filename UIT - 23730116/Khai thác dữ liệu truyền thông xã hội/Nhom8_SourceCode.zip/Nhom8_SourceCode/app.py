# -*- coding: utf-8 -*-
"""
Full app Streamlit: Gom cụm đánh giá trực tuyến theo chủ đề thảo luận
Mở rộng: Dashboard phân tích khủng hoảng thương hiệu từ đánh giá tiêu cực

Chức năng chính:
- Upload CSV hoặc dùng bộ dữ liệu mẫu tiếng Việt đi kèm
- Tách từ tiếng Việt bằng underthesea và làm sạch dữ liệu
- Vector hóa TF-IDF
- Gom cụm bằng K-means (có phương pháp Elbow) hoặc LDA
- Khai thác từ khóa đại diện từng cụm
- Dự đoán cảm xúc (Sentiment Analysis) bằng mô hình Naive Bayes đã train (Machine Learning)
- Dashboard đánh giá tiêu cực: keyword mining, cảnh báo rủi ro đột biến theo Moving Average
- WordCloud, biểu đồ 2D, biểu đồ Plotly, xuất kết quả CSV
"""

from __future__ import annotations

import io
import os
import re
import pickle
from pathlib import Path
from typing import Dict, List, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
from sklearn.cluster import KMeans
from sklearn.decomposition import TruncatedSVD, LatentDirichletAllocation
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import silhouette_score
from underthesea import word_tokenize
from wordcloud import WordCloud

APP_DIR = Path(__file__).resolve().parent

SAMPLE_DATA_PATH = APP_DIR / "data" / "test_vietnamese_social_comments_large.csv"

MODEL_DIR = APP_DIR / "models"
SENTIMENT_MODEL_PATH = MODEL_DIR / "sentiment_model.pkl"
SENTIMENT_VEC_PATH = MODEL_DIR / "tfidf_vectorizer_nb.pkl"

# Stopwords tiếng Việt rút gọn, đủ dùng cho demo môn học.
VI_STOPWORDS = {
    "và", "là", "của", "có", "cho", "trong", "khi", "với", "một", "các", "những", "được", "này", "kia",
    "đó", "thì", "mà", "nên", "rất", "quá", "cũng", "đã", "đang", "sẽ", "bị", "về", "từ", "để",
    "ở", "ra", "vào", "lên", "xuống", "như", "nếu", "hay", "hoặc", "tôi", "mình", "bạn", "anh", "chị",
    "em", "mọi", "người", "ai", "đâu", "gì", "sao", "nào", "nha", "nhé", "ạ", "ơi", "luôn", "thật",
    "hơi", "khá", "cực", "kỳ", "nữa", "lại", "vẫn", "chưa", "cần", "phải", "nhiều", "ít", "hơn", "nhất",
    "the", "a", "an", "and", "or", "is", "are", "was", "were", "to", "of", "for", "in", "on", "at",
    "this", "that", "it", "my", "me", "you", "we", "they"
}

CRISIS_TERMS = [
    # Giao dịch & Tài chính
    "lỗi_thanh_toán", "tiền_đã_trừ", "đơn_không_hiện", "hoàn_tiền", "mất_tiền", "bị_trừ",
    "đòi_lại_tiền", "quỵt_tiền", "lừa_tiền", "không_hoàn_học_phí", "ép_đóng_học_phí",
    
    # Kỹ thuật & Hệ thống
    "lỗi_hệ_thống", "sập_web", "không_truy_cập", "không_vào_được", "lỗi_đăng_nhập",
    "khóa_tài_khoản", "bị_khóa", "mất_tài_khoản", "không_học_được", "lỗi_video",
    "giật_lag", "treo_máy", "lỗi_app",
    
    # Chất lượng đào tạo & Dịch vụ
    "dạy_tệ", "chất_lượng_kém", "quảng_cáo_sai", "không_đúng_cam_kết", "treo_đầu_dê",
    "lừa_người_học", "lừa_đảo", "vô_trách_nhiệm", "thiếu_trách_nhiệm", "làm_ăn_vớ_vẩn",
    "thái_độ_tệ", "chửi_khách", "coi_thường", "giao_trễ", "không_phản_hồi", "né_tránh",
    
    # Cảm xúc tiêu cực & Khủng hoảng
    "mất_niềm_tin", "phản_ánh", "bức_xúc", "khiếu_nại", "tẩy_chay", "tố_cáo",
    "thất_vọng", "phốt", "tệ", "cảnh_báo", "bắt_ép", "ép_buộc", "bất_công", "bất_hợp_lý",
    "tệ_hại", "quá_kém", "lừa_mị", "đồn_nhảm", "phốt_to"
]

SENTIMENT_LABELS_VI = {
    "positive": "Tích cực",
    "neutral": "Trung lập",
    "negative": "Tiêu cực",
}

def find_vietnamese_font() -> str | None:
    """Tìm font có hỗ trợ tiếng Việt để WordCloud hiển thị đẹp trên Windows/macOS/Linux."""
    candidates = [
        r"C:\Windows\Fonts\arial.ttf",
        r"C:\Windows\Fonts\tahoma.ttf",
        r"C:\Windows\Fonts\calibri.ttf",
        "/System/Library/Fonts/Supplemental/Arial Unicode.ttf",
        "/System/Library/Fonts/Supplemental/Arial.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
    ]
    for path in candidates:
        if os.path.exists(path):
            return path
    return None


@st.cache_data(show_spinner=False)
def load_sample_data() -> pd.DataFrame:
    return pd.read_csv(SAMPLE_DATA_PATH, encoding="utf-8-sig")


def load_uploaded_csv(file) -> pd.DataFrame:
    """Đọc CSV upload, thử nhiều encoding phổ biến để tránh lỗi tiếng Việt."""
    raw = file.getvalue()
    encodings = ["utf-8-sig", "utf-8", "cp1258", "latin1"]
    last_error: Exception | None = None
    for enc in encodings:
        try:
            return pd.read_csv(io.BytesIO(raw), encoding=enc)
        except Exception as exc:
            last_error = exc
    raise ValueError(f"Không đọc được CSV. Lỗi cuối: {last_error}")


def clean_text(text: object) -> str:
    """Làm sạch đánh giá, tách từ bằng underthesea."""
    if pd.isna(text):
        return ""
    text = str(text).lower().strip()
    text = re.sub(r"http\S+|www\.\S+", " ", text)
    text = re.sub(r"\S+@\S+", " ", text)
    text = re.sub(r"[@#]\w+", " ", text)
    text = re.sub(r"\d+", " ", text)
    text = re.sub(r"[^\w\sÀ-ỹà-ỹ]", " ", text, flags=re.UNICODE)
    
    # Tách từ tiếng Việt
    text = word_tokenize(text, format="text")
    
    text = re.sub(r"\s+", " ", text).strip()
    return text


def remove_stopwords(text: str, stopwords: set[str]) -> str:
    words = [w for w in text.split() if w not in stopwords and len(w) > 1]
    return " ".join(words)


def dataframe_to_csv_bytes(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False, encoding="utf-8-sig").encode("utf-8-sig")


@st.cache_resource
def load_sentiment_model():
    if not SENTIMENT_MODEL_PATH.exists() or not SENTIMENT_VEC_PATH.exists():
        return None, None
    with open(SENTIMENT_MODEL_PATH, "rb") as f:
        nb_model = pickle.load(f)
    with open(SENTIMENT_VEC_PATH, "rb") as f:
        nb_vec = pickle.load(f)
    return nb_model, nb_vec


# =========================
# Gom cụm chủ đề
# =========================

def get_top_keywords_per_cluster(
    model,
    vectorizer: TfidfVectorizer,
    n_terms: int = 8,
    is_lda: bool = False
) -> Dict[int, List[str]]:
    feature_names = np.array(vectorizer.get_feature_names_out())
    keywords: Dict[int, List[str]] = {}
    
    if is_lda:
        for topic_idx, topic in enumerate(model.components_):
            top_idx = topic.argsort()[::-1][:n_terms]
            keywords[topic_idx] = feature_names[top_idx].tolist()
    else:
        for cluster_id, center in enumerate(model.cluster_centers_):
            top_idx = center.argsort()[::-1][:n_terms]
            keywords[cluster_id] = feature_names[top_idx].tolist()
    return keywords


def make_cluster_names(top_keywords: Dict[int, List[str]]) -> Dict[int, str]:
    names = {}
    for cluster_id, words in top_keywords.items():
        short_words = ", ".join(words[:4]) if words else "chưa rõ"
        names[cluster_id] = f"Cụm {cluster_id} - {short_words}"
    return names


def calculate_elbow(x_tfidf, max_k: int = 10) -> Tuple[List[int], List[float]]:
    inertias = []
    ks = list(range(2, min(max_k + 1, x_tfidf.shape[0])))
    for k in ks:
        km = KMeans(n_clusters=k, random_state=42, n_init=10)
        km.fit(x_tfidf)
        inertias.append(km.inertia_)
    return ks, inertias


def get_elbow_point(ks: List[int], inertias: List[float]) -> int:
    """Tự động tìm điểm cùi chỏ (Elbow point) bằng phương pháp khoảng cách lớn nhất đến đường nối p1-p2."""
    if len(ks) < 3:
        return ks[0]
    p1 = np.array([ks[0], inertias[0]])
    p2 = np.array([ks[-1], inertias[-1]])
    
    distances = []
    for i in range(len(ks)):
        p = np.array([ks[i], inertias[i]])
        # Khoảng cách từ điểm p đến đường thẳng p1-p2
        dist = np.abs(np.cross(p2 - p1, p1 - p)) / np.linalg.norm(p2 - p1)
        distances.append(dist)
        
    return ks[np.argmax(distances)]


def run_clustering(
    df: pd.DataFrame,
    text_col: str,
    algo_type: str,
    n_clusters: int,
    max_features: int,
    min_df: int,
    max_df: float,
    ngram_max: int,
    use_stopwords: bool,
    auto_k: bool = False
) -> Tuple[pd.DataFrame, TfidfVectorizer, object, Dict[int, List[str]], float | None, np.ndarray | None, Tuple[List[int], List[float]] | None, int]:
    
    work_df = df.copy()
    work_df[text_col] = work_df[text_col].fillna("").astype(str)
    
    work_df["clean_text"] = work_df[text_col].apply(clean_text)

    if use_stopwords:
        work_df["processed_text"] = work_df["clean_text"].apply(lambda x: remove_stopwords(x, VI_STOPWORDS))
    else:
        work_df["processed_text"] = work_df["clean_text"]

    work_df = work_df[work_df["processed_text"].str.len() > 0].reset_index(drop=True)

    if len(work_df) < 3:
        raise ValueError("Dữ liệu sau khi làm sạch còn quá ít đánh giá. Hãy dùng file có nhiều dòng hơn.")

    n_clusters = min(n_clusters, len(work_df))
    min_df = max(1, min(min_df, len(work_df)))

    vectorizer = TfidfVectorizer(
        max_features=max_features,
        min_df=min_df,
        max_df=max_df,
        ngram_range=(1, ngram_max),
        token_pattern=r"(?u)\b\w+\b",
    )
    x_tfidf = vectorizer.fit_transform(work_df["processed_text"])

    if x_tfidf.shape[1] < 2:
        raise ValueError("Số lượng đặc trưng TF-IDF quá ít. Hãy giảm min_df hoặc dùng thêm dữ liệu.")

    score = None
    points = None
    elbow_data = None
    
    if algo_type == "K-Means":
        # Tính toán Elbow
        if x_tfidf.shape[0] > 3:
            elbow_data = calculate_elbow(x_tfidf, max_k=10)
            if auto_k and elbow_data is not None:
                ks, inertias = elbow_data
                n_clusters = get_elbow_point(ks, inertias)
            
        model = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
        labels = model.fit_predict(x_tfidf)
        top_keywords = get_top_keywords_per_cluster(model, vectorizer, n_terms=10, is_lda=False)
        
        if n_clusters > 1 and len(work_df) > n_clusters:
            try:
                score = float(silhouette_score(x_tfidf, labels))
            except Exception:
                pass
    else:
        # LDA
        model = LatentDirichletAllocation(n_components=n_clusters, random_state=42)
        doc_topic_dist = model.fit_transform(x_tfidf)
        labels = doc_topic_dist.argmax(axis=1)
        top_keywords = get_top_keywords_per_cluster(model, vectorizer, n_terms=10, is_lda=True)

    cluster_names = make_cluster_names(top_keywords)

    work_df["cluster"] = labels
    work_df["cluster_name"] = work_df["cluster"].map(cluster_names)

    if x_tfidf.shape[1] >= 2 and len(work_df) >= 2:
        try:
            reducer = TruncatedSVD(n_components=2, random_state=42)
            points = reducer.fit_transform(x_tfidf)
        except Exception:
            pass

    return work_df, vectorizer, model, top_keywords, score, points, elbow_data, n_clusters


# =========================
# Sentiment + crisis dashboard
# =========================

def normalize_sentiment_label(value: object) -> str:
    """Chuẩn hóa nhãn cảm xúc nếu dùng cột sẵn có."""
    if pd.isna(value):
        return "neutral"
    s = str(value).strip().lower()
    if s in {"positive", "pos", "1", "tích cực"}:
        return "positive"
    if s in {"negative", "neg", "-1", "tiêu cực"}:
        return "negative"
    return "neutral"


def count_terms(text: str, terms: List[str]) -> int:
    low = str(text).lower()
    return sum(1 for term in terms if term in low)


def matched_terms(text: str, terms: List[str]) -> List[str]:
    low = str(text).lower()
    return [term for term in terms if term in low]


def predict_sentiment_ml(texts: List[str], nb_model, nb_vec) -> List[str]:
    """Dự đoán cảm xúc sử dụng mô hình Naive Bayes."""
    if len(texts) == 0:
        return []
    X = nb_vec.transform(texts)
    preds = nb_model.predict(X)
    return preds.tolist()


def enrich_with_sentiment(
    df: pd.DataFrame,
    text_col: str,
    sentiment_col: str | None,
    likes_col: str | None,
    shares_col: str | None,
) -> pd.DataFrame:
    crisis_df = df.copy()

    if sentiment_col and sentiment_col in crisis_df.columns:
        crisis_df["sentiment"] = crisis_df[sentiment_col].apply(normalize_sentiment_label)
        crisis_df["sentiment_source"] = f"Cột nhãn: {sentiment_col}"
    else:
        nb_model, nb_vec = load_sentiment_model()
        if nb_model is not None and nb_vec is not None:
            preds = predict_sentiment_ml(crisis_df["processed_text"].tolist(), nb_model, nb_vec)
            crisis_df["sentiment"] = preds
            crisis_df["sentiment_source"] = "Mô hình Naive Bayes"
        else:
            # Fallback nếu chưa train model (gán neutral)
            crisis_df["sentiment"] = "neutral"
            crisis_df["sentiment_source"] = "Lỗi: Không tìm thấy model. Vui lòng chạy train.py trước."

    crisis_df["sentiment_vi"] = crisis_df["sentiment"].map(SENTIMENT_LABELS_VI).fillna("Trung lập")
    crisis_df["crisis_terms"] = crisis_df["processed_text"].apply(lambda x: ", ".join(matched_terms(str(x), CRISIS_TERMS)))
    crisis_df["crisis_term_count"] = crisis_df["crisis_terms"].apply(lambda x: 0 if not x else len(x.split(", ")))

    likes = pd.to_numeric(crisis_df[likes_col], errors="coerce").fillna(0) if likes_col and likes_col in crisis_df.columns else 0
    shares = pd.to_numeric(crisis_df[shares_col], errors="coerce").fillna(0) if shares_col and shares_col in crisis_df.columns else 0
    engagement = np.log1p(likes) + 1.5 * np.log1p(shares)

    negative_flag = (crisis_df["sentiment"] == "negative").astype(int)
    crisis_df["comment_risk_score"] = (
        negative_flag * 45
        + crisis_df["crisis_term_count"] * 18
        + np.clip(engagement * 4, 0, 35)
    ).round(1)
    crisis_df["comment_risk_score"] = crisis_df["comment_risk_score"].clip(0, 100)

    def risk_bucket(score: float) -> str:
        if score >= 75:
            return "Rất cao"
        if score >= 55:
            return "Cao"
        if score >= 30:
            return "Trung bình"
        return "Thấp"

    crisis_df["risk_bucket"] = crisis_df["comment_risk_score"].apply(risk_bucket)
    return crisis_df


def mine_keywords_from_texts(texts: List[str], top_n: int = 15) -> pd.DataFrame:
    texts = [t for t in texts if isinstance(t, str) and t.strip()]
    if len(texts) < 2:
        return pd.DataFrame(columns=["Từ khóa", "Điểm TF-IDF"])
    try:
        vec = TfidfVectorizer(
            max_features=1000,
            min_df=1,
            max_df=0.95,
            ngram_range=(1, 2),
            token_pattern=r"(?u)\b\w+\b",
        )
        x = vec.fit_transform(texts)
        scores = np.asarray(x.sum(axis=0)).ravel()
        feature_names = np.array(vec.get_feature_names_out())
        top_idx = scores.argsort()[::-1][:top_n]
        return pd.DataFrame({"Từ khóa": feature_names[top_idx], "Điểm TF-IDF": scores[top_idx].round(3)})
    except Exception:
        return pd.DataFrame(columns=["Từ khóa", "Điểm TF-IDF"])


# =========================
# Biểu đồ
# =========================

def plot_cluster_bar(cluster_counts: pd.DataFrame):
    fig, ax = plt.subplots(figsize=(9, 4.5))
    ax.bar(cluster_counts["Tên cụm"], cluster_counts["Số đánh giá"], color="#3b82f6")
    ax.set_title("Số lượng đánh giá theo từng cụm chủ đề")
    ax.set_xlabel("Cụm chủ đề")
    ax.set_ylabel("Số đánh giá")
    ax.tick_params(axis="x", rotation=30)
    plt.setp(ax.get_xticklabels(), ha="right")
    plt.tight_layout()
    return fig


def plot_scatter_2d(points: np.ndarray, labels: np.ndarray):
    fig, ax = plt.subplots(figsize=(8, 5))
    scatter = ax.scatter(points[:, 0], points[:, 1], c=labels, alpha=0.75, cmap="tab10")
    ax.set_title("Biểu diễn đánh giá trên không gian 2D sau khi giảm chiều")
    ax.set_xlabel("Thành phần 1")
    ax.set_ylabel("Thành phần 2")
    legend = ax.legend(*scatter.legend_elements(), title="Cụm", loc="best")
    ax.add_artist(legend)
    plt.tight_layout()
    return fig


def plot_sentiment_bar(sentiment_counts: pd.DataFrame):
    colors = {"Tích cực": "#10b981", "Trung lập": "#9ca3af", "Tiêu cực": "#ef4444"}
    fig, ax = plt.subplots(figsize=(7, 4))
    bar_colors = [colors.get(x, "#3b82f6") for x in sentiment_counts["Cảm xúc"]]
    ax.bar(sentiment_counts["Cảm xúc"], sentiment_counts["Số đánh giá"], color=bar_colors)
    ax.set_title("Phân bố cảm xúc đánh giá")
    ax.set_xlabel("Cảm xúc")
    ax.set_ylabel("Số đánh giá")
    plt.tight_layout()
    return fig


def plot_crisis_timeline_plotly(df: pd.DataFrame, date_col: str, window_size: int = 7, threshold_multiplier: float = 2.0):
    temp = df.copy()
    temp[date_col] = pd.to_datetime(temp[date_col], errors="coerce")
    temp = temp.dropna(subset=[date_col])
    if temp.empty:
        return None, 0
        
    temp["date_only"] = temp[date_col].dt.date
    grouped = temp.groupby("date_only").agg(
        tong_binh_luan=("sentiment", "size"),
        binh_luan_tieu_cuc=("sentiment", lambda x: int((x == "negative").sum())),
    ).reset_index()
    
    grouped = grouped.sort_values("date_only")
    
    # Tính Moving Average cho đánh giá tiêu cực
    grouped["MA_tieu_cuc"] = grouped["binh_luan_tieu_cuc"].rolling(window=window_size, min_periods=1).mean()
    
    # Phát hiện đột biến (Anomaly)
    # So sánh ngày hiện tại với đường MA (shift 1 để so với trung bình các ngày trước đó)
    grouped["MA_prev"] = grouped["MA_tieu_cuc"].shift(1).fillna(grouped["MA_tieu_cuc"])
    grouped["is_anomaly"] = grouped["binh_luan_tieu_cuc"] > (grouped["MA_prev"] * threshold_multiplier)
    # Lọc bỏ các ngày có số lượng đánh giá tiêu cực quá bé (dưới 3) để tránh nhiễu
    grouped["is_anomaly"] = grouped["is_anomaly"] & (grouped["binh_luan_tieu_cuc"] >= 3)
    
    anomaly_count = grouped["is_anomaly"].sum()

    # Dùng Plotly để vẽ
    fig = go.Figure()
    
    # Line tổng đánh giá
    fig.add_trace(go.Scatter(x=grouped["date_only"], y=grouped["tong_binh_luan"], 
                             mode='lines+markers', name='Tổng đánh giá', 
                             line=dict(color='lightgray', dash='dash')))
                             
    # Line đánh giá tiêu cực
    fig.add_trace(go.Scatter(x=grouped["date_only"], y=grouped["binh_luan_tieu_cuc"], 
                             mode='lines+markers', name='BL tiêu cực',
                             line=dict(color='#ef4444', width=2)))
                             
    # Line Moving Average
    fig.add_trace(go.Scatter(x=grouped["date_only"], y=grouped["MA_prev"], 
                             mode='lines', name=f'MA {window_size} ngày trước',
                             line=dict(color='#f59e0b', width=2, dash='dot')))
                             
    # Highlight Anomalies
    anomalies = grouped[grouped["is_anomaly"]]
    if not anomalies.empty:
        fig.add_trace(go.Scatter(x=anomalies["date_only"], y=anomalies["binh_luan_tieu_cuc"],
                                 mode='markers', name='Đột biến',
                                 marker=dict(color='red', size=12, symbol='star')))

    fig.update_layout(
        title="Diễn biến đánh giá tiêu cực & Cảnh báo đột biến",
        xaxis_title="Thời gian",
        yaxis_title="Số lượng",
        hovermode="x unified",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
    )
    
    return fig, anomaly_count


def make_wordcloud(text: str):
    font_path = find_vietnamese_font()
    wc = WordCloud(
        width=1000,
        height=500,
        background_color="white",
        font_path=font_path,
        collocations=False,
        max_words=120,
    ).generate(text)
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.imshow(wc, interpolation="bilinear")
    ax.axis("off")
    plt.tight_layout()
    return fig


# =========================
# Giao diện Streamlit
# =========================

st.set_page_config(
    page_title="Hệ thống phân tích đánh giá và cảnh báo khủng hoảng thương hiệu",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown(
    """
    <style>
    .main .block-container {padding-top: 1rem; padding-bottom: 2rem; max-width: 1400px;}
    .metric-card {background: #f7f9fc; border: 1px solid #e6edf5; border-radius: 10px; padding: 16px; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);}
    .small-note {color: #5c6670; font-size: 0.95rem;}

    .stTabs [data-baseweb="tab-list"] {
        gap: 6px;
    }
    .stTabs [data-baseweb="tab"] {
        height: 45px;
        white-space: pre-wrap;
        background-color: #f8fafc;
        border-radius: 6px 6px 0px 0px;
        padding: 10px;
        box-shadow: inset 0 -2px 0 0 #e2e8f0;
        border: 1px solid #e2e8f0;
        border-bottom: none;
    }
    .stTabs [aria-selected="true"] {
        background-color: #ffffff;
        box-shadow: inset 0 -3px 0 0 #3b82f6;
        font-weight: 600;
        border-top: 2px solid #3b82f6;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.title("Hệ thống phân tích đánh giá & cảnh báo khủng hoảng thương hiệu")
st.caption("Ứng dụng học thuật: Phân tích NLP (underthesea, TF-IDF), K-means/LDA, Naive Bayes Sentiment, Anomaly Detection.")

with st.sidebar:
    st.header("Bảng điều khiển")
    
    with st.expander("1. Nguồn dữ liệu", expanded=True):
        uploaded_file = st.file_uploader("Upload file CSV", type=["csv"])

        if uploaded_file is not None:
            try:
                input_df = load_uploaded_csv(uploaded_file)
                st.success("Đã đọc file CSV upload.")
            except Exception as exc:
                st.error(str(exc))
                st.stop()
        else:
            input_df = load_sample_data()
            st.success(f"Đang dùng dữ liệu mẫu: {SAMPLE_DATA_PATH.name}")

        if input_df.empty:
            st.error("File dữ liệu đang rỗng.")
            st.stop()

        all_columns = input_df.columns.tolist()
        default_col = "comment" if "comment" in all_columns else all_columns[0]
        text_col = st.selectbox("Chọn cột chứa đánh giá", all_columns, index=all_columns.index(default_col))

    with st.expander("2. Tham số gom cụm", expanded=False):
        algo_type = st.radio("Thuật toán", ["K-Means", "LDA"])
        
        auto_k = False
        if algo_type == "K-Means":
            auto_k = st.checkbox("Tự động chọn K tối ưu (phương pháp Elbow)", value=True)
            
        if auto_k and algo_type == "K-Means":
            st.info("Hệ thống sẽ tự động tìm K tối ưu dựa trên phương pháp Elbow.")
            n_clusters = 6
        else:
            n_clusters = st.slider("Số lượng cụm (K)", min_value=2, max_value=12, value=6, step=1)
            
        max_features = st.slider("Đặc trưng tối đa (max_features)", min_value=100, max_value=8000, value=2500, step=100)
        min_df = st.slider("Tần suất xuất hiện tối thiểu (min_df)", min_value=1, max_value=10, value=2, step=1)
        max_df = st.slider("Loại bỏ từ quá phổ biến (max_df)", min_value=0.50, max_value=1.00, value=0.95, step=0.05)
        ngram_max = st.radio("Cấu hình N-gram", [1, 2], index=1, format_func=lambda x: "1-gram" if x == 1 else "1-gram + 2-gram")
        use_stopwords = st.checkbox("Loại bỏ Stopwords", value=True)

    with st.expander("3. Cảnh báo khủng hoảng", expanded=False):
        sentiment_col = None  # Luôn sử dụng mô hình Naive Bayes để đánh giá cảm xúc

        date_default = "date" if "date" in all_columns else "Không dùng"
        date_options = ["Không dùng"] + all_columns
        date_col_choice = st.selectbox("Cột thời gian", date_options, index=date_options.index(date_default) if date_default in date_options else 0)
        date_col = None if date_col_choice == "Không dùng" else date_col_choice

        if date_col:
            window_size = st.slider("Số ngày tính trung bình", min_value=3, max_value=14, value=7)
            threshold_multi = st.slider("Hệ số đột biến (threshold)", min_value=1.0, max_value=5.0, value=2.0, step=0.1)
        else:
            window_size = 7
            threshold_multi = 2.0

        platform_default = "platform" if "platform" in all_columns else "Không dùng"
        platform_col_choice = st.selectbox("Cột nền tảng/kênh", ["Không dùng"] + all_columns, index=(["Không dùng"] + all_columns).index(platform_default) if platform_default in (["Không dùng"] + all_columns) else 0)
        platform_col = None if platform_col_choice == "Không dùng" else platform_col_choice

        likes_col = "likes" if "likes" in all_columns else None
        shares_col = "shares" if "shares" in all_columns else None

    st.divider()
    run_button = st.button("Chạy phân tích", type="primary", use_container_width=True)

if not run_button:
    st.info("Vui lòng kiểm tra nguồn dữ liệu, cấu hình tham số ở \"Bảng điều khiển\" và chọn \"Chạy phân tích\".")
    st.subheader("Xem trước dữ liệu đầu vào")

    # --- Thông tin tổng quan dataset ---
    n_rows, n_cols = input_df.shape
    n_missing = int(input_df.isnull().sum().sum())
    n_duplicates = int(input_df.duplicated().sum())

    info_c1, info_c2, info_c3, info_c4, info_c5 = st.columns(5)
    info_c1.metric("Số dòng", f"{n_rows:,}")
    info_c2.metric("Số cột", f"{n_cols}")
    info_c3.metric("Giá trị thiếu", f"{n_missing:,}")
    info_c4.metric("Dòng trùng lặp", f"{n_duplicates:,}")

    with st.expander("Chi tiết các cột trong dataset", expanded=False):
        col_info = []
        for col in input_df.columns:
            series = input_df[col]
            col_info.append({
                "Tên cột": col,
                "Kiểu dữ liệu": str(series.dtype),
                "Số giá trị duy nhất": series.nunique(),
                "Số giá trị null": int(series.isnull().sum()),
                "% Null": f"{series.isnull().mean() * 100:.1f}%",
                "Mẫu giá trị": str(series.dropna().iloc[0]) if not series.dropna().empty else "—",
            })
        st.dataframe(pd.DataFrame(col_info), use_container_width=True, hide_index=True)

    st.dataframe(input_df.head(10), use_container_width=True)
    st.stop()

# ----- BẮT ĐẦU XỬ LÝ -----
with st.spinner('Đang thực hiện tiền xử lý và chạy thuật toán...'):
    try:
        result_df, vectorizer, model, top_keywords, score, points, elbow_data, actual_k = run_clustering(
            df=input_df,
            text_col=text_col,
            algo_type=algo_type,
            n_clusters=n_clusters,
            max_features=max_features,
            min_df=min_df,
            max_df=max_df,
            ngram_max=ngram_max,
            use_stopwords=use_stopwords,
            auto_k=auto_k
        )
    except Exception as exc:
        st.error(f"Không thể chạy phân tích: {exc}")
        st.stop()

with st.spinner('Đang dự đoán cảm xúc và tính điểm khủng hoảng...'):
    result_df = enrich_with_sentiment(
        result_df,
        text_col=text_col,
        sentiment_col=sentiment_col,
        likes_col=likes_col,
        shares_col=shares_col,
    )

cluster_names = make_cluster_names(top_keywords)
cluster_counts = (
    result_df.groupby(["cluster", "cluster_name"])
    .size()
    .reset_index(name="Số đánh giá")
    .sort_values("cluster")
)
cluster_counts["Tên cụm"] = cluster_counts["cluster_name"]

st.success("Phân tích hoàn tất.")

st.markdown("### Tóm tắt Thuật toán")
col1, col2, col3, col4 = st.columns(4)
col1.metric("Thuật toán", algo_type)
col2.metric("Số cụm đã tạo", actual_k)
col3.metric("Số đặc trưng (Từ khóa)", f"{len(vectorizer.get_feature_names_out()):,}")
col4.metric("Silhouette score", "N/A (LDA)" if score is None else f"{score:.3f}")

st.divider()

# ----- TABS -----
tab1, tab2, tab3, tab4 = st.tabs([
    "Báo cáo Khủng hoảng",
    "Phân tích Chủ đề",
    "Phân tích Chuyên sâu",
    "Dữ liệu & Xuất",
])

# Tab 1: Khủng hoảng
with tab1:
    st.subheader("Tổng quan khủng hoảng")
    if "Lỗi:" in str(result_df["sentiment_source"].iloc[0]):
        st.error(result_df["sentiment_source"].iloc[0])
    
    total = len(result_df)
    negative_count = int((result_df["sentiment"] == "negative").sum())
    positive_count = int((result_df["sentiment"] == "positive").sum())
    neutral_count = int((result_df["sentiment"] == "neutral").sum())
    negative_ratio = negative_count / total * 100 if total else 0
    high_risk_count = int((result_df["comment_risk_score"] >= 55).sum())
    high_risk_ratio = high_risk_count / total * 100 if total else 0
    crisis_index = min(100, negative_ratio * 0.7 + high_risk_ratio * 1.2 + (result_df["crisis_term_count"].mean() * 12))

    if crisis_index >= 60:
        crisis_level = "Rất cao"
    elif crisis_index >= 40:
        crisis_level = "Cao"
    elif crisis_index >= 20:
        crisis_level = "Trung bình"
    else:
        crisis_level = "Thấp"

    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Đánh giá tiêu cực", f"{negative_count:,}", f"{negative_ratio:.1f}%")
    c2.metric("Đánh giá trung lập", f"{neutral_count:,}")
    c3.metric("Đánh giá tích cực", f"{positive_count:,}")
    c4.metric("Đánh giá rủi ro cao", f"{high_risk_count:,}", f"{high_risk_ratio:.1f}%")
    c5.metric("Chỉ số khủng hoảng", f"{crisis_index:.1f}/100", crisis_level)

    sentiment_counts = (
        result_df["sentiment_vi"].value_counts().rename_axis("Cảm xúc").reset_index(name="Số đánh giá")
    )

    left, right = st.columns([1, 1])
    with left:
        st.markdown("**Phân bố cảm xúc**")
        st.pyplot(plot_sentiment_bar(sentiment_counts), use_container_width=True)
    with right:
        st.markdown("**Top từ khóa trong đánh giá tiêu cực**")
        negative_texts = result_df.loc[result_df["sentiment"] == "negative", "processed_text"].tolist()
        neg_keywords = mine_keywords_from_texts(negative_texts, top_n=12)
        st.dataframe(neg_keywords, use_container_width=True, height=350)

    if date_col:
        st.divider()
        fig, anomaly_count = plot_crisis_timeline_plotly(result_df, date_col, window_size, threshold_multi)
        if fig:
            st.subheader(f"Timeline cảnh báo đột biến (Có {anomaly_count} ngày)")
            if anomaly_count > 0:
                st.error(f"Phát hiện {anomaly_count} ngày có lượng đánh giá tiêu cực tăng vọt so với trung bình ({window_size} ngày trước, hệ số {threshold_multi}x).")
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.warning("Không đọc được cột thời gian để vẽ timeline.")

    if platform_col and platform_col in result_df.columns:
        st.divider()
        st.subheader("Phân tích nguồn gây khủng hoảng (Theo kênh/nền tảng)")
        platform_table = (
            result_df.assign(is_negative=(result_df["sentiment"] == "negative"))
            .groupby(platform_col)
            .agg(
                tong_binh_luan=("sentiment", "size"),
                binh_luan_tieu_cuc=("is_negative", "sum"),
                diem_rui_ro_tb=("comment_risk_score", "mean"),
            )
            .reset_index()
        )
        platform_table["ty_le_tieu_cuc_%"] = (platform_table["binh_luan_tieu_cuc"] / platform_table["tong_binh_luan"] * 100).round(1)
        platform_table["diem_rui_ro_tb"] = platform_table["diem_rui_ro_tb"].round(1)
        platform_table = platform_table.sort_values(["binh_luan_tieu_cuc", "ty_le_tieu_cuc_%"], ascending=False)
        st.dataframe(platform_table, use_container_width=True)

    st.divider()
    st.subheader("Danh sách đánh giá có nguy cơ khủng hoảng cao")
    high_risk_df = result_df.sort_values("comment_risk_score", ascending=False).copy()
    candidate_cols = [
        date_col if date_col else None,
        platform_col if platform_col else None,
        text_col,
        "sentiment_vi",
        "cluster_name",
        "crisis_terms",
        "comment_risk_score",
    ]
    candidate_cols = [c for c in candidate_cols if c and c in high_risk_df.columns]
    st.dataframe(high_risk_df[candidate_cols].head(50), use_container_width=True)


# Tab 2: Phân tích Chủ đề
with tab2:
    st.subheader(f"Kết quả gom cụm bằng {algo_type}")
    left, right = st.columns([1.2, 1])
    with left:
        st.pyplot(plot_cluster_bar(cluster_counts), use_container_width=True)
    with right:
        st.dataframe(cluster_counts[["cluster", "cluster_name", "Số đánh giá"]], use_container_width=True, height=350)

    st.divider()
    st.subheader("Từ khóa đại diện và WordCloud")
    for cluster_id in sorted(top_keywords):
        with st.expander(f"{cluster_names[cluster_id]} — {int((result_df['cluster'] == cluster_id).sum())} đánh giá", expanded=(cluster_id == 0)):
            st.markdown("**Top từ khóa (TF-IDF):** " + ", ".join(f"`{w}`" for w in top_keywords[cluster_id][:12]))
            
            c_left, c_right = st.columns([1, 1])
            with c_left:
                text_for_wc = " ".join(result_df.loc[result_df["cluster"] == cluster_id, "processed_text"].tolist())
                if text_for_wc.strip():
                    st.pyplot(make_wordcloud(text_for_wc), use_container_width=True)
                else:
                    st.warning("Cụm này chưa đủ nội dung để tạo WordCloud.")
            with c_right:
                cluster_df = result_df[result_df["cluster"] == cluster_id]
                show_cols = [text_col, "sentiment_vi", "comment_risk_score"]
                st.dataframe(cluster_df[show_cols].head(20), use_container_width=True, height=250)

# Tab 3: Phân tích chuyên sâu
with tab3:
    col_a, col_b = st.columns(2)
    
    with col_a:
        st.subheader("Đánh giá thuật toán: Elbow")
        if algo_type == "K-Means" and elbow_data is not None:
            ks, inertias = elbow_data
            fig_elbow = go.Figure()
            fig_elbow.add_trace(go.Scatter(x=ks, y=inertias, mode='lines+markers', marker=dict(size=8), name="WCSS"))
            
            # Highlight điểm cùi chỏ (Elbow) được chọn tự động
            if auto_k:
                fig_elbow.add_trace(go.Scatter(
                    x=[actual_k], y=[inertias[ks.index(actual_k)]], 
                    mode='markers', marker=dict(color='red', size=12, symbol='star'),
                    name="K tối ưu (Auto)"
                ))
            
            fig_elbow.update_layout(
                title="Đồ thị Elbow (Quán tính - WCSS)",
                xaxis_title="Số lượng cụm (K)",
                yaxis_title="Inertia (WCSS)",
                xaxis=dict(tickmode='linear', tick0=2, dtick=1)
            )
            st.plotly_chart(fig_elbow, use_container_width=True)
            st.info("Điểm khuỷu tay (Elbow) là điểm độ dốc bắt đầu giảm đáng kể. Có thể sử dụng để chọn K tối ưu.")
        else:
            st.warning("Phương pháp Elbow chỉ được hiển thị khi dùng K-Means.")

    with col_b:
        st.subheader("Trực quan hóa dữ liệu: Tọa độ 2D")
        if points is not None:
            st.pyplot(plot_scatter_2d(points, result_df["cluster"].to_numpy()), use_container_width=True)
            st.caption(f"Trực quan hóa không gian đánh giá (sau giảm chiều SVD/PCA).")
        else:
            st.warning("Không tạo được biểu đồ 2D với dữ liệu hiện tại.")

# Tab 4: Dữ liệu & Xuất
with tab4:
    st.subheader("Dữ liệu đầu vào ban đầu")
    st.dataframe(input_df.head(20), use_container_width=True)

    st.divider()
    st.subheader("Kết quả toàn diện")
    export_cols = [text_col, "clean_text", "processed_text", "cluster", "cluster_name", "sentiment", "sentiment_vi", "comment_risk_score", "risk_bucket", "crisis_terms"]
    export_cols = [c for c in export_cols if c in result_df.columns]
    extra_cols = [c for c in result_df.columns if c not in export_cols]
    export_df = result_df[export_cols + extra_cols]

    st.download_button(
        label="Tải file kết quả (CSV)",
        data=dataframe_to_csv_bytes(export_df),
        file_name="ket_qua_gom_cum_va_canh_bao_khung_hoang.csv",
        mime="text/csv",
        use_container_width=True,
    )
    st.dataframe(export_df.head(250), use_container_width=True)

