@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"

if not exist ".venv\Scripts\activate.bat" (
    echo [LOI] Chua co .venv. Hay chay run_windows.bat truoc.
    pause
    exit /b 1
)

call .venv\Scripts\activate.bat
streamlit run app.py
pause
