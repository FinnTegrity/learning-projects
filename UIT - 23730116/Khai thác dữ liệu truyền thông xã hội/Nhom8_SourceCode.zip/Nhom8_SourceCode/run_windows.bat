@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"

echo ============================================
echo  Gom cum binh luan MXH - One click Windows
echo ============================================
echo.

where py >nul 2>nul
if %errorlevel%==0 (
    set "PYTHON_CMD=py -3"
) else (
    where python >nul 2>nul
    if %errorlevel%==0 (
        set "PYTHON_CMD=python"
    ) else (
        echo [LOI] Khong tim thay Python.
        echo Hay cai Python 3.10+ tai https://www.python.org/downloads/
        echo Khi cai dat nho tick "Add Python to PATH".
        pause
        exit /b 1
    )
)

echo [1/4] Kiem tra Python...
%PYTHON_CMD% --version
if %errorlevel% neq 0 (
    echo [LOI] Python khong chay duoc.
    pause
    exit /b 1
)

echo.
echo [2/4] Tao moi truong ao .venv neu chua co...
if not exist ".venv" (
    %PYTHON_CMD% -m venv .venv
    if %errorlevel% neq 0 (
        echo [LOI] Khong tao duoc moi truong ao .venv.
        pause
        exit /b 1
    )
) else (
    echo Da co .venv, bo qua buoc tao moi.
)

echo.
echo [3/4] Cai thu vien can thiet...
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
if %errorlevel% neq 0 (
    echo [LOI] Cai thu vien that bai. Thu chay lai file nay voi mang Internet on dinh.
    pause
    exit /b 1
)

echo.
echo [4/4] Khoi dong ung dung Streamlit...
echo Neu trinh duyet khong tu mo, hay copy link Local URL hien ra trong man hinh nay.
streamlit run app.py

echo.
echo Ung dung da dung.
pause
