# -*- coding: utf-8 -*-
"""
Script huấn luyện mô hình Naive Bayes để phân tích cảm xúc
"""

import os
import pickle
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import classification_report
from underthesea import word_tokenize
import re

DATA_PATHS = [
    "data/train_vietnamese_sentiment_analyst_data.csv",
    "data/train_shop_vietnamese_text_comment.csv"
]
MODEL_DIR = "models"
os.makedirs(MODEL_DIR, exist_ok=True)
MODEL_PATH = os.path.join(MODEL_DIR, "sentiment_model.pkl")
VEC_PATH = os.path.join(MODEL_DIR, "tfidf_vectorizer_nb.pkl")

# Stopwords tiếng Việt
VI_STOPWORDS = {
    "và", "là", "của", "có", "cho", "trong", "khi", "với", "một", "các", "những", "được", "này", "kia",
    "đó", "thì", "mà", "nên", "rất", "quá", "cũng", "đã", "đang", "sẽ", "bị", "về", "từ", "để",
    "ở", "ra", "vào", "lên", "xuống", "như", "nếu", "hay", "hoặc", "tôi", "mình", "bạn", "anh", "chị",
    "em", "mọi", "người", "ai", "đâu", "gì", "sao", "nào", "nha", "nhé", "ạ", "ơi", "luôn", "thật",
    "hơi", "khá", "cực", "kỳ", "nữa", "lại", "vẫn", "chưa", "cần", "phải", "nhiều", "ít", "hơn", "nhất",
    "the", "a", "an", "and", "or", "is", "are", "was", "were", "to", "of", "for", "in", "on", "at",
    "this", "that", "it", "my", "me", "you", "we", "they"
}

def clean_text_for_train(text):
    if pd.isna(text):
        return ""
    text = str(text).lower().strip()
    # Loại bỏ URL, email, tag, số, ký tự đặc biệt
    text = re.sub(r"http\S+|www\.\S+", " ", text)
    text = re.sub(r"\S+@\S+", " ", text)
    text = re.sub(r"[@#]\w+", " ", text)
    text = re.sub(r"\d+", " ", text)
    text = re.sub(r"[^\w\sÀ-ỹà-ỹ]", " ", text, flags=re.UNICODE)
    
    # Tách từ bằng underthesea
    text = word_tokenize(text, format="text")
    
    # Loại bỏ stopwords
    words = [w for w in text.split() if w not in VI_STOPWORDS and len(w) > 1]
    return " ".join(words)

def normalize_sentiment(val):
    if pd.isna(val):
        return None
    val = str(val).strip().lower()
    if val in {"positive", "pos", "1", "tích cực"}:
        return "positive"
    if val in {"negative", "neg", "-1", "tiêu cực"}:
        return "negative"
    if val in {"neutral", "neu", "0", "trung lập"}:
        return "neutral"
    return None

def train():
    dfs = []
    for data_path in DATA_PATHS:
        print(f"Đang đọc dữ liệu từ: {data_path}")
        try:
            df_temp = pd.read_csv(data_path, encoding="utf-8-sig")
        except Exception as e:
            raise ValueError(f"Không thể đọc file {data_path}: {str(e)}")
            
        # Kiểm tra cột comment
        if "comment" not in df_temp.columns:
            raise ValueError(f"File {data_path} phải có cột 'comment'.")
            
        # Xác định cột label
        label_col = None
        if "sentiment_label" in df_temp.columns:
            label_col = "sentiment_label"
        elif "label" in df_temp.columns:
            label_col = "label"
        else:
            raise ValueError(f"File {data_path} phải có cột 'sentiment_label' hoặc 'label'.")
            
        # Trích xuất và căn chỉnh
        df_clean = pd.DataFrame({
            "comment": df_temp["comment"],
            "raw_label": df_temp[label_col]
        })
        dfs.append(df_clean)
        
    df = pd.concat(dfs, ignore_index=True)
    print(f"Tổng số mẫu sau khi gộp: {len(df)}")
    
    label_col = "raw_label"
    print("Tiền xử lý và gán nhãn dữ liệu...")
    
    # Cảnh báo nhãn bị thiếu (NaN)
    missing_labels_count = df[label_col].isna().sum()
    if missing_labels_count > 0:
        print(f"CẢNH BÁO: Có {missing_labels_count} dòng bị thiếu nhãn (NaN). Các dòng này sẽ bị loại bỏ.")
        
    df["label"] = df[label_col].apply(normalize_sentiment)
    
    # Cảnh báo nhãn không hợp lệ
    unrecognized = df[df["label"].isna() & df[label_col].notna()]
    if len(unrecognized) > 0:
        unrecognized_values = unrecognized[label_col].unique()
        print(f"CẢNH BÁO: Phát hiện {len(unrecognized)} dòng có nhãn không hợp lệ: {unrecognized_values}. Các dòng này sẽ bị loại bỏ.")
        
    # Cảnh báo đánh giá thiếu nội dung (NaN)
    missing_comment_count = df["comment"].isna().sum()
    if missing_comment_count > 0:
        print(f"CẢNH BÁO: Có {missing_comment_count} dòng bị thiếu nội dung (comment). Các dòng này sẽ bị loại bỏ.")
        
    # Lọc bỏ dòng không có nhãn hợp lệ hoặc thiếu comment
    df = df.dropna(subset=["label", "comment"]).copy()
    
    # Loại bỏ trùng lặp đánh giá (drop duplicates)
    initial_count = len(df)
    df = df.drop_duplicates(subset=["comment"]).copy()
    duplicate_count = initial_count - len(df)
    if duplicate_count > 0:
        print(f"CẢNH BÁO: Có {duplicate_count} đánh giá bị trùng lặp. Đã loại bỏ.")
    
    # Clean text
    print("Đang làm sạch văn bản (loại bỏ stopword, ký tự đặc biệt, tách từ)...")
    pre_clean_count = len(df)
    df["processed_text"] = df["comment"].apply(clean_text_for_train)
    df = df[df["processed_text"].str.len() > 0].reset_index(drop=True)
    post_clean_count = len(df)
    
    # Ghi log đánh giá rỗng sau làm sạch
    empty_comments_count = pre_clean_count - post_clean_count
    if empty_comments_count > 0:
        pct = (empty_comments_count / pre_clean_count) * 100
        print(f"LOG: Có {empty_comments_count} đánh giá trở thành chuỗi rỗng sau khi làm sạch ({pct:.2f}%). Các đánh giá này đã bị loại bỏ.")
        
    print(f"Tổng số mẫu sau khi làm sạch: {len(df)}")
    print("Phân phối nhãn:", df["label"].value_counts().to_dict())
    
    print("Trích xuất đặc trưng TF-IDF...")
    vectorizer = TfidfVectorizer(max_features=5000, min_df=2, ngram_range=(1, 2))
    X = vectorizer.fit_transform(df["processed_text"])
    y = df["label"]
    
    print("Huấn luyện mô hình Multinomial Naive Bayes...")
    model = MultinomialNB()
    model.fit(X, y)
    
    print("Đánh giá mô hình trên toàn bộ tập train:")
    y_pred = model.predict(X)
    print(classification_report(y, y_pred))
    
    print(f"Lưu model và vectorizer vào thư mục {MODEL_DIR}...")
    with open(MODEL_PATH, "wb") as f:
        pickle.dump(model, f)
    with open(VEC_PATH, "wb") as f:
        pickle.dump(vectorizer, f)
        
    print("Huấn luyện hoàn tất!")

if __name__ == "__main__":
    train()
